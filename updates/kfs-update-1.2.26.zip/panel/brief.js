(function(root){
 'use strict';
 function clean(text){return String(text||'').replace(/\\\s*\r?\n/g,'\n').replace(/[*`]/g,'').replace(/\u00a0/g,' ').replace(/&#x20;|&#32;|&nbsp;/gi,' ');}
 function removeDirections(text){var out='',depth=0;for(var i=0;i<text.length;i++){var c=text[i];if(c==='['){depth++;continue;}if(c===']'){if(!depth)throw Error('Close every bracketed direction in the brief.');depth--;continue;}if(!depth)out+=c;}if(depth)throw Error('Close every bracketed direction in the brief.');return out.replace(/https?:\/\/[^\s]+/g,'').replace(/\s+/g,' ').trim();}
 function bodyOnly(text){return !text.trim()||/^(?:\(?\s*(?:nothing(?: written)? here(?: it means it starts directly from the body)?|no hook\s*[-–—:]?\s*(?:straight to (?:the )?(?:(?:shared|universal|common|main|core|general|master|same) )?body)?|(?:start|starts|starting)\s+(?:straight |directly )?from (?:the )?(?:(?:shared|universal|common|main|core|general|master|same) )?body|straight to (?:the )?(?:(?:shared|universal|common|main|core|general|master|same) )?body|(?:(?:shared|universal|common|main|core|general|master|same) )?body only)\s*[.!]?\s*\)?)$/i.test(text.trim());}
 // Script labels. Returns null for a line that is not spoken (a label alone, or a direction in parentheses),
 // {heading,text} for a label line (the heading the parser understands, and the spoken text after the label),
 // or undefined for an ordinary line.
 var SECTION=/^(?:cta|call[ -]to[ -]action|intro|outro|closing|close|offer|problem|solution|agitation|agitate|proof|mechanism|benefits?|story|testimonials?|urgency|guarantee|transition|payoff|reveal|demo|p\.?\s?s\.?)\s*#?\s*\d*\s*(?:\([^)]*\))?\s*(?:(?::|\s[-\u2013\u2014])\s*(.*))?$/i;
 // Labels for things that are shown, not said.
 var VOICE=/^(?:VO|V\.O\.?|VOICE ?OVER|NARRATOR|NARRATION|SPEAKER|HOST|PRESENTER|CREATOR|TALENT|ACTOR|ACTRESS|DOCTOR)$/;
 var QUIET=/^(?:ON[- ]SCREEN(?: TEXT)?|TEXT ON SCREEN|OST|SUPERS?|VISUALS?|VISUAL NOTES?|B[- ]?ROLL|SHOT|SCENE|NOTES?|CAMERA|MUSIC|SFX|FX|GRAPHICS?|CAPTIONS?|TITLE|LOCATION|SETTING|ACTION|DIRECTIONS?|EDITOR NOTES?|FADE IN|FADE OUT|CUT TO)$/;
 function kandyLabel(line){
  var wrapped=/^[\[(]\s*([^\[\]()]{1,40}?)\s*[\])]\s*(?:[:.\-\u2013\u2014]\s*)?(.*)$/.exec(line);
  if(wrapped){var inner=wrapped[1].replace(/\s*[:.\-\u2013\u2014]\s*$/,'');
   if(/^(?:hook|h|v)\s*#?\s*\d*$/i.test(inner)&&!/^[hv]$/i.test(inner)||/^(?:(?:shared|universal|common|main|core|general|master|same)\s+)?body$/i.test(inner)){var rest=wrapped[2].trim();return {heading:inner+': '+rest,text:rest};}
   if(SECTION.test(inner)){return wrapped[2].trim()?{heading:wrapped[2].trim(),text:wrapped[2].trim()}:null;}}
  if(/^\([^()]*\)$/.test(line))return null;
  var section=SECTION.exec(line);if(section){var said=(section[1]||'').trim();return said?{heading:said,text:said}:null;}
  // Dialogue: an all-caps speaker label (MICHAEL:, DR. PATEL:, JASON (CONT'D):, VO:) is not spoken; the words after it are.
  var who=/^([A-Z][A-Z0-9.'’\- ]{0,28}[A-Z0-9.])\s*(?:\([^)]*\))?\s*:\s*(.*)$/.exec(line);
  if(who&&!/^(?:[HV]\d+|HOOK.*|.*BODY.*|REF|REFERENCE|IDEA|IDE|CONCEPT|TEXT|SCRIPT|AVATAR|CHARACTERS|HEADLINE.*)$/.test(who[1])){
   if(QUIET.test(who[1]))return null;
   var words=who[2].trim().replace(/^["“]+|["”]+$/g,'').trim();return words?{heading:words,text:words,speaker:who[1]}:null;}
  return undefined;
 }
 function parse(text,mode){
  text=clean(text);if(text.length>100000)throw Error('Keep the brief under 100,000 characters.');
  if(!text.trim())return {sections:{},hooks:[]};
  if(mode==='spoken')return {sections:{SINGLE:text.replace(/\s+/g,' ').trim()},hooks:[]};
  var sections={},current=null,buffer=[],seen=false,kept=[];
  // A dialogue script (two or more speakers, MICHAEL: / JASON:) keeps only what the speakers say; other lines are action.
  var talk=0,names={};text.split(/\r?\n/).forEach(function(l){var x=kandyLabel(l.trim().replace(/^#+\s*/,''));if(x&&x.speaker){talk++;names[x.speaker]=1;}});
  var screenplay=talk>=3&&Object.keys(names).length>=2;
  function commit(){if(!current)return;if(sections[current]!==undefined)throw Error('Duplicate brief section: '+current);sections[current]=buffer.join('\n');}
  text.split(/\r?\n/).forEach(function(line){
   var normalized=line.trim().replace(/^#+\s*/,'').replace(/^["“]|["”]$/g,'').replace(/\\$/,'').trim();
   var label=kandyLabel(normalized);if(label&&label.speaker&&!screenplay&&!VOICE.test(label.speaker))label=undefined;if(label===null)return;if(label!==undefined){normalized=label.heading;if(label.text!==undefined)line=label.text;}
   var version=/^(?:HOOK|H|V)\s*#?\s*(\d+)\s*(?:\([^)]*\))?\s*(?:[:.\-\u2013\u2014]\s*(.*))?$/i.exec(normalized),loose=!version&&/^HOOK\s*(?:\([^)]*\))?\s*(?:(?::|\s[-\u2013\u2014])\s*(.*))?$/i.exec(normalized);
   if(loose){var next=1;while(sections['H'+next]!==undefined||current==='H'+next)next++;version=[normalized,String(next),loose[1]];}
   if(version){var n=Number(version[1]);if(String(n)!==version[1]||n<1||n>50)throw Error('Use up to 50 hooks, H1–H50.');normalized='H'+n+': '+(version[2]||'');}
   else if(/^Headline(?:\s+on\s+screen)?\s*:/i.test(normalized)||/^Headline$/i.test(normalized))normalized='HEADLINE:';
   else{var body=/^(?:(?:shared|universal|common|main|core|general|master|same)\s+)?body(?:\s*\([^)]*\)|\s*[-\u2013\u2014]\s*(?:shared|universal|common|main|core|general|master|same)(?:\s+body)?)?\s*(?:(?::|\s[-\u2013\u2014]|\.\s*$)\s*(.*))?$/i.exec(normalized);if(body)normalized='BODY: '+(body[1]||'');}
   var m=/^(H(?:[1-9]|[1-4][0-9]|50)|BODY|REF|REFERENCE|IDEA|IDE|CONCEPT|TEXT|SCRIPT|AVATAR|CHARACTERS|HEADLINE)\s*(?::\s*(.*))?$/i.exec(normalized);
   if(m){commit();current=m[1].toUpperCase();buffer=m[2]?[m[2]]:[];seen=true;}else if(/^H[0-9]+(?:\s*:|$)/i.test(normalized)){throw Error('Use up to 50 hooks, H1–H50.');}else if(!screenplay||label&&label.speaker){kept.push(line);if(current)buffer.push(line);}
  });commit();
  if(!seen)return {sections:{SINGLE:removeDirections(kept.join('\n').replace(/^[ \t]*(?:H|HOOK[ \t]*)\d{1,2}[ \t]*[:.\-\u2013]?[ \t]+/gim,''))},hooks:[]};
  var spoken={},hooks=Object.keys(sections).filter(function(k){return /^H(?:[1-9]|[1-4][0-9]|50)$/.test(k);}).sort(function(a,b){return Number(a.slice(1))-Number(b.slice(1));});
  hooks.concat(['BODY']).forEach(function(k){if(sections[k]!==undefined){var value=removeDirections(sections[k]);if(k!=='BODY'&&bodyOnly(value))value='';else if(!value)throw Error(k+' has no spoken words.');spoken[k]=value;}});
  if(hooks.length&&!spoken.BODY)throw Error('Add a BODY heading after H1/H2/H3 (BODY, Shared body or Universal body).');
  if(!Object.keys(spoken).length){var value=sections.SCRIPT||sections.TEXT;if(!value)throw Error('Add TEXT/SCRIPT or H1/BODY headings.');spoken.SINGLE=removeDirections(value);}
  return {sections:spoken,hooks:hooks};
 }
 function select(brief,hook){if(brief.hooks.length&&(!hook||hook==='auto'))return '';if(brief.hooks.length){if(brief.hooks.indexOf(hook)<0)throw Error('Select the matching hook for this sequence.');return (brief.sections[hook]+' '+brief.sections.BODY).trim();}return brief.sections.BODY||brief.sections.SINGLE||'';}
 var api={parse:parse,select:select};if(typeof module!=='undefined'&&module.exports)module.exports=api;root.KandyBrief=api;
}(typeof window!=='undefined'?window:globalThis));
