/* Caption imports target the captured sequence. QE adds one video-only top track. */
var KandyForScaleCaptions = (function () {
 function serialize(value){
  if(typeof JSON!=='undefined'&&JSON.stringify)return JSON.stringify(value);
  function quote(text){return '"'+String(text).replace(/[\\"\x00-\x1f\u2028\u2029]/g,function(c){var hex=c.charCodeAt(0).toString(16);return c==='"'?'\\"':c==='\\'?'\\\\':'\\u'+('0000'+hex).slice(-4);})+'"';}
  function encode(v){if(v===null||typeof v==='undefined')return 'null';if(typeof v==='string')return quote(v);if(typeof v==='number')return isFinite(v)?String(v):'null';if(typeof v==='boolean')return String(v);var rows=[];if(v instanceof Array){for(var i=0;i<v.length;i++)rows.push(encode(v[i]));return '['+rows.join(',')+']';}for(var key in v)if(Object.prototype.hasOwnProperty.call(v,key)&&typeof v[key]!=='function'&&typeof v[key]!=='undefined')rows.push(quote(key)+':'+encode(v[key]));return '{'+rows.join(',')+'}';}
  return encode(value);
 }
 function fileFilter(extensions){return $.os.indexOf('Windows')>=0?'*.'+extensions.join(';*.'):function(f){return f instanceof Folder||new RegExp('\\.('+extensions.join('|')+')$','i').test(f.name);};}
 function result(value){return serialize(value);}
 function protect(fn){try{return result(fn());}catch(e){return result({error:e.message});}}
 function seq(id){var s=app.project.activeSequence;if(!s)throw Error('Open a sequence first.');if(id && s.sequenceID!==id)throw Error('The active sequence changed. Return to the original sequence before adding captions.');return s;}
 function find(item,path){if(item.getMediaPath && item.getMediaPath()===path)return item;if(item.children)for(var i=0;i<item.children.numItems;i++){var x=find(item.children[i],path);if(x)return x;}return null;}
 function sceneEvidence(s,duration){
  var clips=[],points=[0,duration],cuts=[],sources=[];
  for(var t=0;t<s.videoTracks.numTracks;t++){
   var track=s.videoTracks[t];if(track.isMuted&&track.isMuted())continue;
   for(var i=0;i<track.clips.numItems;i++){
    var c=track.clips[i],path=kandyMedia(c);
    // Escape literal slashes explicitly for ExtendScript's older regexp parser.
    if(c.disabled||/Kandy For Scale Captions\/|caption_\d+\.png$/i.test(path.replace(/\\/g,'/')))continue;
    try{if(c.isAdjustmentLayer&&c.isAdjustmentLayer())continue;}catch(e){}
    var a=0,b=0;try{a=Math.max(0,c.start.seconds);b=Math.min(duration,c.end.seconds);}catch(e){continue;}if(!(b>a))continue;
    clips.push({clip:c,path:path,track:t,key:t+':'+i,start:a,end:b});points.push(a);points.push(b);
   }
  }
  points.sort(function(a,b){return a-b;});var unique=[];for(var p=0;p<points.length;p++)if(!p||points[p]-points[p-1]>.00001)unique.push(points[p]);
  var previous=null,lastSourceKey='';
  for(var j=0;j+1<unique.length;j++){
   var start=unique[j],end=unique[j+1],middle=(start+end)/2,visible=null;
   for(var k=0;k<clips.length;k++)if(clips[k].start<=middle&&middle<clips[k].end&&(!visible||clips[k].track>visible.track))visible=clips[k];
   if(j&&((visible&&visible.key)!==(previous&&previous.key)))cuts.push(start);
   if(visible&&visible.path&&/\.(mp4|mov|mxf|avi|mkv|webm|m4v)$/i.test(visible.path)){
    var v=visible.clip;
    if(v.getSpeed&&v.isSpeedReversed&&v.getSpeed()===1&&!v.isSpeedReversed()){
     var last=sources.length?sources[sources.length-1]:null;
     if(last&&lastSourceKey===visible.key&&Math.abs(last.end-start)<.00001)last.end=end;
     else sources.push({path:visible.path,start:start,end:end,sourceStart:v.inPoint.seconds+start-v.start.seconds});
     lastSourceKey=visible.key;
    }
   }
   previous=visible;
  }
  return {cuts:cuts,sources:sources};
 }
 function playhead(s){try{var t=Number(s.getPlayerPosition().seconds);return isFinite(t)?t:null;}catch(e){return null;}}
 function inOut(s){var a=NaN,b=NaN;try{a=Number(s.getInPointAsTime().seconds);b=Number(s.getOutPointAsTime().seconds);}catch(e){try{a=Number(s.getInPoint());b=Number(s.getOutPoint());}catch(e2){}}return [a,b];}
 function info(){var s=seq(),settings=s.getSettings(),duration=Number(s.end)/254016000000,evidence=sceneEvidence(s,duration);return {id:s.sequenceID,name:s.name,duration:duration,width:settings.videoFrameWidth,height:settings.videoFrameHeight,fps:1/settings.videoFrameRate.seconds,tracks:s.videoTracks.numTracks,sceneCuts:evidence.cuts,sceneSources:evidence.sources,appPath:app.path,inPoint:inOut(s)[0],outPoint:inOut(s)[1],playhead:playhead(s)};}
 function trackSignature(track){var rows=[];for(var i=0;i<track.clips.numItems;i++){var c=track.clips[i];rows.push([kandyMedia(c),c.start.ticks,c.end.ticks]);}return serialize(rows);}
 function kandyLocked(track){try{return !!(track.isLocked&&track.isLocked());}catch(e){return false;}}
 function topContent(s){var top=-1;for(var t=0;t<s.videoTracks.numTracks;t++)if(s.videoTracks[t].clips.numItems)top=t;return top;}
 function signatures(list){var out=[];for(var i=0;i<list.numTracks;i++)out.push(trackSignature(list[i])+(kandyLocked(list[i])?'L':''));return out;}
 // Where did one new empty track land? Returns its index, or -1 if other tracks changed.
 function insertedAt(now,old){
  if(now.length!==old.length+1)return -1;
  for(var k=now.length-1;k>=0;k--){if(now[k]!=='[]')continue;var ok=true;for(var i=0,j=0;i<now.length;i++){if(i===k)continue;if(now[i]!==old[j++]){ok=false;break;}}if(ok)return k;}
  return -1;
 }
 function emptyTop(s){var top=topContent(s);for(var e=top+1;e<s.videoTracks.numTracks;e++)if(!kandyLocked(s.videoTracks[e]))return e;return -1;}
 // Short description of tracks that look different after Premiere added one, for support screenshots.
 function trackNote(now,old,k){if(insertedAt(now,old)>=0)return '';var d=[];for(var i=0,j=0;i<now.length&&d.length<3;i++){if(i===k)continue;if(now[i]!==old[j])d.push('V'+(i+1));j++;}if(now.length!==old.length+1)d=[];return ' (Premiere also reported a change on '+(d.join(', ')||'the track list')+' while adding the track. Check those tracks; Cmd+Z / Ctrl+Z undoes.)';}
 function newCaptionTrack(id){
  var s=seq(id);
  // An empty, unlocked track above every clip is already a top caption track.
  var e=emptyTop(s);if(e>=0)return {track:s.videoTracks[e],index:e,reused:true,note:''};
  var ids=signatures(s.videoTracks);
  app.enableQE();kandyActivate(id);var q=qe.project.getActiveSequence();for(var qw=0;qw<20&&q&&q.name!==s.name;qw++){$.sleep(100);q=qe.project.getActiveSequence();}if(!q||q.name!==s.name)throw Error('Premiere has another sequence active. Click on your timeline and try again.');
  if(!q||!q.addTracks)throw Error('This Premiere version cannot create a caption video track automatically. Add an empty video track at the top of the timeline, then click again.');
  var stray=-1;
  for(var attempt=0;attempt<2;attempt++){
   var count=seq(id).videoTracks.numTracks;
   q.addTracks(1,attempt?count:count-1,0);
   for(var w=0;w<20;w++){s=seq(id);if(s.videoTracks.numTracks>count)break;$.sleep(100);}
   var now=signatures(s.videoTracks),k=emptyTop(s);
   if(k>=0){
    try{s.videoTracks[k].name='Kandy For Scale Captions';}catch(ignore){}
    return {track:s.videoTracks[k],index:k,stray:stray,note:trackNote(now,ids,k)};
   }
   // Premiere put the new track under existing clips: leave it empty and try once more at the top.
   if(stray<0)stray=insertedAt(now,ids);ids=now;
  }
  throw Error('Premiere keeps adding the caption track below your clips, so no captions were placed. Delete the empty tracks it added (or press Cmd+Z / Ctrl+Z twice), add an empty video track at the top of the timeline (right-click a track name > Add Track), then click again.');
 }
 return {
  info:function(){return protect(info);},
  srt:function(){return protect(function(){var f=File.openDialog('Choose subtitle file',fileFilter(['srt']));return {path:f?f.fsName:''};});},
  audio:function(){return protect(function(){var f=File.openDialog('Choose full sequence audio or video',fileFilter(['wav','mp3','m4a','mp4','mov']));return {path:f?f.fsName:''};});},
  exportAudio:function(id,path,preset,workArea){return protect(function(){var s=seq(id);if(!(new File(preset)).exists)throw Error('WAV export preset not found.');var ok=s.exportAsMediaDirect((new File(path)).fsName,(new File(preset)).fsName,workArea===1?1:0);if(!(new File(path)).exists || (new File(path)).length<44)throw Error('Premiere audio export failed: '+ok+'. You can also import an exported sequence WAV.');return {path:path,sequence:info()};});},
  addNative:function(id,path){return protect(function(){var s=seq(id);if(!(new File(path)).exists)throw Error('Caption file is missing.');var bin=app.project.rootItem.createBin('Kandy Captions '+(new Date()).getTime());if(!app.project.importFiles([path],true,bin,false))throw Error('Premiere could not import SRT.');var item=find(bin,path);if(!item)throw Error('Imported caption item not found.');if(!s.createCaptionTrack(item,0))throw Error('Premiere could not create a caption track.');return {message:'Editable caption track added. Apply a Proxima Nova Track Style in Premiere.'};});},
  replaceStyled:function(id,path,name,range){return protect(function(){
   var s=seq(id);if(!(new File(path)).exists)throw Error('Styled overlay file is missing. Click Apply text or style edits & rebuild first.');
   function isCaption(clip){var mp='';try{mp=clip.projectItem&&clip.projectItem.getMediaPath?clip.projectItem.getMediaPath():'';}catch(e){}return mp.indexOf('Kandy For Scale Captions')>=0&&/caption_\d+\.png$/i.test(mp);}
   var target=null,ti=-1;
   for(var t=s.videoTracks.numTracks-1;t>=0&&!target;t--){var tr=s.videoTracks[t];if(!tr.clips.numItems)continue;var all=true;for(var c=0;c<tr.clips.numItems;c++){if(!isCaption(tr.clips[c])){all=false;break;}}if(all){target=tr;ti=t;}}
   if(!target)throw Error('No existing styled caption track found in this sequence. Use Add styled captions instead.');
   var overlay=kandyOverlay(path,name);
   if(!overlay||!overlay.videoTracks.numTracks||!overlay.videoTracks[0].clips.numItems)throw Error('Caption overlay sequence is empty or missing.');
   for(var m=0;m<overlay.videoTracks[0].clips.numItems;m++){var media=overlay.videoTracks[0].clips[m].projectItem;if(media.isOffline&&media.isOffline())throw Error('A caption image is offline. Regenerate captions and keep the output folder in place.');}
   s=kandyActivate(id);target=s.videoTracks[ti];
   if(range)return kandyReplaceRange(target,ti,overlay,range);
   var removed=target.clips.numItems;
   for(var r=target.clips.numItems-1;r>=0;r--)target.clips[r].remove(false,false);
   if(target.clips.numItems)throw Error('Could not clear the old caption clips on V'+(ti+1)+'.');
   var clips=overlay.videoTracks[0].clips;
   kandyPlace(target,clips);
   if(target.clips.numItems!==clips.numItems)throw Error('Some caption clips could not be placed. Review track V'+(ti+1)+'.');
   try{app.project.deleteSequence(overlay);}catch(ignore){}
   var cleaned=kandyCleanup();
   return {message:'Replaced '+removed+' old captions with '+clips.numItems+' new ones on V'+(ti+1)+'.'+(cleaned?' Removed '+cleaned+' unused old caption sets from the project.':''),track:ti+1};
  });},
  replaceSelected:function(id,path,name){return protect(function(){
   var s=seq(id);if(!(new File(path)).exists)throw Error('Styled overlay file is missing. Click Update preview first.');
   function isCaption(clip){var mp='';try{mp=clip.projectItem&&clip.projectItem.getMediaPath?clip.projectItem.getMediaPath():'';}catch(e){}return mp.indexOf('Kandy For Scale Captions')>=0&&/caption_\d+\.png$/i.test(mp);}
   var plan={},count=0;
   for(var t=0;t<s.videoTracks.numTracks;t++){var tr=s.videoTracks[t],rows=[],any=false;
    for(var c=0;c<tr.clips.numItems;c++){var k=tr.clips[c];var sel=false;try{sel=k.isSelected();}catch(e){}rows.push({item:k.projectItem,a:k.start.seconds,ticks:k.start.ticks,end:k.end,b:k.end.seconds,cap:isCaption(k),sel:sel&&isCaption(k)});if(sel&&isCaption(k)){any=true;count++;}}
    if(any)plan[t]=rows;}
   if(!count)throw Error('Select one or more caption clips on the timeline first.');
   var overlay=kandyOverlay(path,name);
   if(!overlay||!overlay.videoTracks.numTracks||!overlay.videoTracks[0].clips.numItems)throw Error('Caption overlay sequence is empty or missing.');
   var src=overlay.videoTracks[0].clips;
   for(var key in plan){var list=plan[key];for(var r=0;r<list.length;r++){if(!list[r].sel)continue;var best=null,score=0;for(var n=0;n<src.numItems;n++){var o=Math.min(list[r].b,src[n].end.seconds)-Math.max(list[r].a,src[n].start.seconds);if(o>score){score=o;best=src[n].projectItem;}}if(best)list[r].item=best;}}
   s=kandyActivate(id);
   for(var key2 in plan){var rows2=plan[key2],tr2=s.videoTracks[Number(key2)];
    for(var d=0;d<rows2.length;d++){if(!rows2[d].cap)throw Error('Track V'+(Number(key2)+1)+' has other clips besides captions. Nothing was changed.');}
    for(var q=tr2.clips.numItems-1;q>=0;q--)tr2.clips[q].remove(false,false);
    rows2.sort(function(u,v){return u.a-v.a;});
    for(var w=0;w<rows2.length;w++){tr2.overwriteClip(rows2[w].item,rows2[w].ticks);
     for(var z=0;z<tr2.clips.numItems;z++){var nc=tr2.clips[z];if(Math.abs(nc.start.seconds-rows2[w].a)<0.002){nc.end=rows2[w].end;break;}}}
    if(tr2.clips.numItems!==rows2.length)throw Error('Track V'+(Number(key2)+1)+' now has '+tr2.clips.numItems+' clips instead of '+rows2.length+'. Press Cmd+Z to undo.');}
   try{app.project.deleteSequence(overlay);}catch(ignore){}
   kandyCleanup();
   return {message:'Replaced '+count+' selected caption'+(count===1?'':'s')+'. All other captions were kept.'};
  });},
  addStyled:function(id,path,name){return protect(function(){
   seq(id);if(!(new File(path)).exists)throw Error('Styled overlay file is missing.');
   var overlay=kandyOverlay(path,name);
   if(!overlay||!overlay.videoTracks.numTracks||!overlay.videoTracks[0].clips.numItems)throw Error('Caption overlay sequence is empty or missing.');
   for(var m=0;m<overlay.videoTracks[0].clips.numItems;m++){var media=overlay.videoTracks[0].clips[m].projectItem;if(media.isOffline&&media.isOffline())throw Error('A caption image is offline. Regenerate captions and keep the output folder in place.');}
   kandyActivate(id);var created=newCaptionTrack(id),target=created.track;
   var clips=overlay.videoTracks[0].clips;
   kandyPlace(target,clips);
   if(target.clips.numItems!==clips.numItems)throw Error('Some caption clips could not be placed. Review the new caption track.');
   return {message:'Styled captions added to '+(created.reused?'the empty top track V':'new top track V')+(created.index+1)+'.'+(created.stray>=0?' Premiere also left an empty track V'+(created.stray+1)+'; you can delete it.':'')+' Keep the output folder with your project.'+(created.note||''),track:created.index+1,created_track:!created.reused};
  });}

 };
}());

function kandySeqByName(name){var found=null;for(var i=0;i<app.project.sequences.numSequences;i++){var x=app.project.sequences[i];if(x.name===name)found=x;}return found;}
function kandyOverlay(path,name){
 var overlay=kandySeqByName(name);
 if(!overlay||!overlay.videoTracks.numTracks||!overlay.videoTracks[0].clips.numItems){
  if(!app.project.importFiles([path],true,kandyJobBin(name),false))throw Error('Could not import overlay sequence.');
  for(var w=0;w<75;w++){overlay=kandySeqByName(name);if(overlay&&overlay.videoTracks.numTracks&&overlay.videoTracks[0].clips.numItems)break;$.sleep(200);}
 }
 if(!overlay||!overlay.videoTracks.numTracks||!overlay.videoTracks[0].clips.numItems)throw Error('Premiere is still importing the captions. Wait a moment and click the button again.');
 return overlay;
}
function kandyActivate(id){
 for(var w=0;w<50;w++){var a=app.project.activeSequence;if(a&&a.sequenceID===id)return a;
  if(w%10===0){try{app.project.openSequence(id);}catch(e){}}$.sleep(100);}
 throw Error('Could not switch back to your sequence. Click on its timeline and try again.');
}
function kandyMedia(c){try{var p=c&&c.projectItem;if(!p||!p.getMediaPath)return '';var m=p.getMediaPath();return m?String(m):'';}catch(e){return '';}}
// In-Out range replace: captions centred inside the range are swapped for the new ones; all others stay.
// Premiere drops a still in at its default length before it is trimmed, so the whole track is laid back in time order.
function kandyReplaceRange(target,ti,overlay,range){
 var rows=[],removed=0,src=overlay.videoTracks[0].clips,i;
 for(i=0;i<target.clips.numItems;i++){var c=target.clips[i],mid=(c.start.seconds+c.end.seconds)/2;if(mid>=range[0]&&mid<range[1])removed++;else rows.push({item:c.projectItem,a:c.start.seconds,ticks:c.start.ticks,end:c.end,b:c.end.seconds});}
 var kept=rows.length;
 for(i=0;i<src.numItems;i++)rows.push({item:src[i].projectItem,a:src[i].start.seconds,ticks:src[i].start.ticks,end:src[i].end,b:src[i].end.seconds});
 rows.sort(function(u,v){return u.a-v.a;});
 for(i=target.clips.numItems-1;i>=0;i--)target.clips[i].remove(false,false);
 if(target.clips.numItems)throw Error('Could not clear the caption clips on V'+(ti+1)+'. Press Cmd+Z (Ctrl+Z) to undo.');
 for(i=0;i<rows.length;i++){target.overwriteClip(rows[i].item,rows[i].ticks);var nc=kandyAt(target,rows[i].a);
  if(nc){try{nc.end=rows[i].end;}catch(e){}if(Math.abs(nc.end.seconds-rows[i].b)>0.02){try{var t=new Time();t.seconds=rows[i].b;nc.end=t;}catch(e2){}}}}
 var lost=0;for(i=0;i<rows.length;i++)if(!kandyAt(target,rows[i].a))lost++;
 if(lost)throw Error(lost+' captions could not be placed on V'+(ti+1)+'. Press Cmd+Z (Ctrl+Z) to undo.');
 try{app.project.deleteSequence(overlay);}catch(ignore){}
 var cleaned=kandyCleanup();
 return {message:'Replaced '+removed+' captions inside the In-Out range with '+src.numItems+' new ones on V'+(ti+1)+'. The other '+kept+' captions were kept.'+(cleaned?' Removed '+cleaned+' unused old caption sets from the project.':''),track:ti+1};
}
function kandyAt(track,t){for(var z=track.clips.numItems-1;z>=0;z--){var c=track.clips[z];if(Math.abs(c.start.seconds-t)<0.02)return c;}return null;}
function kandyPlace(target,clips){
 for(var pass=0;pass<3;pass++){var missing=0;
  for(var n=0;n<clips.numItems;n++){var source=clips[n],have=kandyAt(target,source.start.seconds);
   if(have&&Math.abs(have.end.seconds-source.end.seconds)<0.02)continue;
   if(!have){target.overwriteClip(source.projectItem,source.start.ticks);have=kandyAt(target,source.start.seconds);}
   if(have){try{have.end=source.end;}catch(e){}}else missing++;}
  if(!missing)break;}
}
function kandyJobBin(name){var root=kandyCaptionBin();for(var i=0;i<root.children.numItems;i++){var c=root.children[i];if(c&&c.type===2&&c.name===name)return c;}return root.createBin(name)||root;}
function kandyCleanup(){return kandyCleanupIn(kandyCaptionBin());}
function kandyCleanupIn(root){try{var used={},re=/Kandy For Scale Captions[\/\\]([^\/\\]+)[\/\\]caption_\d+\.png$/i;
 for(var s=0;s<app.project.sequences.numSequences;s++){var sq=app.project.sequences[s];for(var t=0;t<sq.videoTracks.numTracks;t++){var tr=sq.videoTracks[t];for(var c=0;c<tr.clips.numItems;c++){var mp='';try{mp=tr.clips[c].projectItem.getMediaPath();}catch(e){}var m=re.exec(mp);if(m)used[m[1]]=1;}}}
 var trash=null,moved=0,removed=0;
 for(var i=root.children.numItems-1;i>=0;i--){var it=root.children[i];if(!it)continue;
  if(it.type===2){if(it.name==='_old'){continue;}var job=it.name.replace(/^Kandy Captions /,'');if(!used[job]){try{it.deleteBin();removed++;}catch(e){}}}
  else{var mp2='';try{mp2=it.getMediaPath();}catch(e){}var m2=re.exec(mp2);if(m2&&!used[m2[1]]){if(!trash)trash=root.createBin('_old');try{it.moveBin(trash);moved++;}catch(e){}}}}
 if(trash){try{trash.deleteBin();}catch(e){}}
 return removed+moved;}catch(e){return 0;}}
function kandyCaptionBin(){var root=app.project.rootItem;for(var b=0;b<root.children.numItems;b++){var ch=root.children[b];if(ch&&ch.name==='Kandy For Scale Caption Files'&&ch.type===2)return ch;}return root.createBin('Kandy For Scale Caption Files')||root;}
