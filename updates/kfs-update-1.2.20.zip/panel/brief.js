(function(root){
 'use strict';
 function clean(text){return String(text||'').replace(/\\\s*\r?\n/g,'\n').replace(/[*`]/g,'').replace(/\u00a0/g,' ').replace(/&#x20;|&#32;|&nbsp;/gi,' ');}
 function removeDirections(text){var out='',depth=0;for(var i=0;i<text.length;i++){var c=text[i];if(c==='['){depth++;continue;}if(c===']'){if(!depth)throw Error('Close every bracketed direction in the brief.');depth--;continue;}if(!depth)out+=c;}if(depth)throw Error('Close every bracketed direction in the brief.');return out.replace(/https?:\/\/[^\s]+/g,'').replace(/\s+/g,' ').trim();}
 function bodyOnly(text){return !text.trim()||/^(?:\(?\s*(?:nothing(?: written)? here(?: it means it starts directly from the body)?|no hook\s*[-–—:]?\s*(?:straight to (?:the )?(?:(?:shared|universal|common|main|core|general|master|same) )?body)?|(?:start|starts|starting)\s+(?:straight |directly )?from (?:the )?(?:(?:shared|universal|common|main|core|general|master|same) )?body|straight to (?:the )?(?:(?:shared|universal|common|main|core|general|master|same) )?body|(?:(?:shared|universal|common|main|core|general|master|same) )?body only)\s*[.!]?\s*\)?)$/i.test(text.trim());}
 function parse(text,mode){
  text=clean(text);if(text.length>100000)throw Error('Keep the brief under 100,000 characters.');
  if(!text.trim())return {sections:{},hooks:[]};
  if(mode==='spoken')return {sections:{SINGLE:text.replace(/\s+/g,' ').trim()},hooks:[]};
  var sections={},current=null,buffer=[],seen=false;
  function commit(){if(!current)return;if(sections[current]!==undefined)throw Error('Duplicate brief section: '+current);sections[current]=buffer.join('\n');}
  text.split(/\r?\n/).forEach(function(line){
   var normalized=line.trim().replace(/^#+\s*/,'').replace(/^["“]|["”]$/g,'').replace(/\\$/,'').trim();
   var version=/^(?:H|V|HOOK\s*)(\d+)\s*(?:\([^)]*\))?\s*(?::\s*(.*))?$/i.exec(normalized);
   if(version){var n=Number(version[1]);if(String(n)!==version[1]||n<1||n>50)throw Error('Use up to 50 hooks, H1–H50.');normalized='H'+n+': '+(version[2]||'');}
   else if(/^Headline(?:\s+on\s+screen)?\s*:/i.test(normalized)||/^Headline$/i.test(normalized))normalized='HEADLINE:';
   else{var body=/^(?:(?:shared|universal|common|main|core|general|master|same)\s+)?body(?:\s*\([^)]*\)|\s*[-\u2013\u2014]\s*(?:shared|universal|common|main|core|general|master|same)(?:\s+body)?)?\s*(?::\s*(.*))?$/i.exec(normalized);if(body)normalized='BODY: '+(body[1]||'');}
   var m=/^(H(?:[1-9]|[1-4][0-9]|50)|BODY|REF|REFERENCE|IDEA|IDE|CONCEPT|TEXT|SCRIPT|AVATAR|CHARACTERS|HEADLINE)\s*(?::\s*(.*))?$/i.exec(normalized);
   if(m){commit();current=m[1].toUpperCase();buffer=m[2]?[m[2]]:[];seen=true;}else if(/^H[0-9]+(?:\s*:|$)/i.test(normalized)){throw Error('Use up to 50 hooks, H1–H50.');}else if(current)buffer.push(line);
  });commit();
  if(!seen)return {sections:{SINGLE:removeDirections(text.replace(/^[ \t]*(?:H|HOOK[ \t]*)\d{1,2}[ \t]*[:.\-\u2013]?[ \t]+/gim,''))},hooks:[]};
  var spoken={},hooks=Object.keys(sections).filter(function(k){return /^H(?:[1-9]|[1-4][0-9]|50)$/.test(k);}).sort(function(a,b){return Number(a.slice(1))-Number(b.slice(1));});
  hooks.concat(['BODY']).forEach(function(k){if(sections[k]!==undefined){var value=removeDirections(sections[k]);if(k!=='BODY'&&bodyOnly(value))value='';else if(!value)throw Error(k+' has no spoken words.');spoken[k]=value;}});
  if(hooks.length&&!spoken.BODY)throw Error('Add a BODY heading after H1/H2/H3 (BODY, Shared body or Universal body).');
  if(!Object.keys(spoken).length){var value=sections.SCRIPT||sections.TEXT;if(!value)throw Error('Add TEXT/SCRIPT or H1/BODY headings.');spoken.SINGLE=removeDirections(value);}
  return {sections:spoken,hooks:hooks};
 }
 function select(brief,hook){if(brief.hooks.length&&(!hook||hook==='auto'))return '';if(brief.hooks.length){if(brief.hooks.indexOf(hook)<0)throw Error('Select the matching hook for this sequence.');return (brief.sections[hook]+' '+brief.sections.BODY).trim();}return brief.sections.BODY||brief.sections.SINGLE||'';}
 var api={parse:parse,select:select};if(typeof module!=='undefined'&&module.exports)module.exports=api;root.KandyBrief=api;
}(typeof window!=='undefined'?window:globalThis));
