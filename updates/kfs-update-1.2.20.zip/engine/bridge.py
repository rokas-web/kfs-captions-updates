"""File-based local worker. Uses the installed caption engine and its license."""
import sys,os,json,threading,re,copy,xml.etree.ElementTree as ET
from pathlib import Path
from urllib.parse import quote

def media_url(path):
 native=Path(path).resolve().as_posix()
 if re.match(r'^[A-Za-z]:/',native):
  return 'file://localhost/'+quote(native,safe='/').replace('%3A','%3a',1)
 return Path(path).resolve().as_uri()

def emit(message,progress=0):
 print(json.dumps(dict(message=message,progress=progress)),flush=True)

def srt_cues(path):
 text=Path(path).read_text(encoding='utf-8-sig');result=[]
 def seconds(s):
  h,m,t=s.replace(',','.').split(':');return int(h)*3600+int(m)*60+float(t)
 for block in re.split(r'\n\s*\n',text.replace('\r','').strip()):
  lines=block.splitlines();i=next((i for i,s in enumerate(lines) if '-->' in s),None)
  if i is None:continue
  a,b=lines[i].split('-->');start,end=seconds(a.strip()),seconds(b.strip().split()[0])
  value=re.sub('<[^>]+>','',' '.join(lines[i+1:])).strip()
  if value and end>start:result.append(dict(start=start,end=end,text=value))
 if not result:raise ValueError('No valid captions found in SRT.')
 return result

def overlay_xml(states,dest,width,height,fps,duration,name):
 # Caption images are rendered at the exact host canvas; timeline frame rate
 # is taken from Premiere, including NTSC 23.976/29.97/59.94 sequences.
 base=round(fps);ntsc=abs(fps-base)>.001
 root=ET.Element('xmeml',version='5');s=ET.SubElement(root,'sequence',id='kandy-captions')
 def node(parent,key,value):ET.SubElement(parent,key).text=str(value)
 def rate(parent):
  r=ET.SubElement(parent,'rate');node(r,'timebase',base);node(r,'ntsc','TRUE' if ntsc else 'FALSE')
 node(s,'name',name);node(s,'duration',round(duration*fps));rate(s)
 media=ET.SubElement(s,'media');video=ET.SubElement(media,'video');fmt=ET.SubElement(video,'format');sc=ET.SubElement(fmt,'samplecharacteristics');rate(sc)
 for key,val in [('width',width),('height',height),('pixelaspectratio','square'),('fielddominance','none')]:node(sc,key,val)
 track=ET.SubElement(video,'track')
 prev=0
 for i,state in enumerate(states):
  a,b=round(state['start']*fps),round(state['end']*fps)
  a=max(a,prev);b=max(b,a+1);prev=b
  c=ET.SubElement(track,'clipitem',id='caption-'+str(i));node(c,'name','Caption '+str(i+1));rate(c)
  for key,val in [('duration',b-a),('start',a),('end',b),('in',0),('out',b-a),('stillframe','TRUE')]:node(c,key,val)
  f=ET.SubElement(c,'file',id='file-'+str(i));node(f,'name',Path(state['path']).name);node(f,'pathurl',media_url(state['path']));rate(f);node(f,'duration',b-a);node(f,'stillframe','TRUE')
  v=ET.SubElement(ET.SubElement(f,'media'),'video');node(v,'alphatype','straight');fc=ET.SubElement(v,'samplecharacteristics');rate(fc)
  for key,val in [('width',width),('height',height),('pixelaspectratio','square')]:node(fc,key,val)
  st=ET.SubElement(c,'sourcetrack');node(st,'mediatype','video');node(st,'trackindex',1)
 ET.ElementTree(root).write(dest,encoding='utf-8',xml_declaration=True)

def _retime_rows(rows,speech,duration):
 """Give edited captions the measured speech timing of their words (edits keep sync)."""
 import difflib,re
 norm=lambda t:re.sub(r"[^a-z0-9%]","",str(t).lower().replace("\u2019","'"))
 flat=[(i,j) for i,r in enumerate(rows) for j in range(len(r['words']))]
 a=[norm(rows[i]['words'][j]['text']) for i,j in flat];b=[norm(w.get('text','')) for w in speech]
 hit={}
 for m in difflib.SequenceMatcher(None,a,b,autojunk=False).get_matching_blocks():
  for k in range(m.size):
   if a[m.a+k]:hit[flat[m.a+k]]=speech[m.b+k]
 for i,r in enumerate(rows):
  got=[(j,hit[(i,j)]) for j in range(len(r['words'])) if (i,j) in hit]
  if not got or len(got)*2<len(r['words']):continue
  for j,w in got:r['words'][j]=dict(r['words'][j],start=float(w['start']),end=float(w['end']))
  a0=float(got[0][1]['start']);b0=float(got[-1][1]['end'])
  if b0-a0<.05:b0=a0+.05
  b0=max(b0,min(float(r['end']),b0+.4))
  r['start'],r['end']=max(0.0,min(a0,duration-.05)),min(duration,b0)
  ws=r['words']
  for j,w in enumerate(ws):
   if (i,j) in hit:continue
   lo=max([ws[k]['end'] for k in range(j) if (i,k) in hit]+[r['start']]);hi=min([ws[k]['start'] for k in range(j+1,len(ws)) if (i,k) in hit]+[r['end']])
   ws[j]=dict(w,start=lo,end=max(lo,hi))
 for x,y in zip(rows,rows[1:]):
  if y['start']<x['end']:x['end']=max(x['start']+.05,y['start'])
 return rows

def process(request,app,folder):
 from ugc import captions,media
 from ugc.caption_timeline import prepare,ENGINE
 from ugc.caption_limits import limit_groups
 from ugc.caption_fonts import font_description
 if ENGINE!='captions-1.9-readable-previews':raise ValueError('The installed caption engine is incompatible. Reinstall the current extension.')
 captions.PRESETS['client_box']={**captions.PRESETS['white_box'],'file':'@proxima','font':'Proxima Nova','size':100}
 stop=threading.Event();cancel=folder/'cancel'
 def watch():
  while not stop.wait(.2):
   if cancel.exists():stop.set()
 threading.Thread(target=watch,daemon=True).start()
 sequence=request['sequence'];width,height=int(sequence['width']),int(sequence['height'])
 if not (64<=width<=8192 and 64<=height<=8192):raise ValueError('Unsupported sequence dimensions.')
 duration=float(sequence['duration'])
 if duration<=0:raise ValueError('The sequence is empty.')
 rng=request.get('range')
 if rng is not None:
  try:rng=[float(rng[0]),float(rng[1])]
  except (TypeError,ValueError,IndexError,KeyError):raise ValueError('Invalid In-Out range. Set the In and Out points again.')
  if not (0<=rng[0]<rng[1]<=duration+.05):raise ValueError('The In-Out range is outside this sequence. Set the In and Out points again.')
 try:
  p=dict(name=sequence['name'],duration=duration,source=request.get('audio',''),cues=[],scenes=[],hooks=[],caption=request.get('style','client_box'),caption_size=float(request.get('size',72)),caption_y=float(request.get('position',933)),caption_grouping='smart',original_script=request.get('script',''),workflow='captions',caption_flow='connected',montage_format='9:16' if height>width else '16:9')
  p['_caption_canvas']=(width,height)
  from scene_policy import collect
  policy=request.get('cut_policy','shot')
  p['caption_style_colors']=request.get('caption_style_colors',{})
  from ugc.caption_colors import validate,style as colored_style
  p['caption_style_colors']=validate(p['caption_style_colors'],captions.PRESETS)
  p['caption_style_effects']=request.get('caption_style_effects') if isinstance(request.get('caption_style_effects'),dict) else {}
  captions.PROXIMA_WEIGHT=(lambda w:w if w in ('Thin','Light','Regular','Medium','Semibold','Bold','Extrabold','Black') else '')(str((p['caption_style_effects'].get(p['caption']) or {}).get('weight','')))
  scene_analysis={};hook_choice=None
  p['caption_cut_policy']=policy
  p['caption_max_lines']=int(request.get('caption_max_lines',2))
  if p['caption_max_lines'] not in (1,2):raise ValueError('Choose one or two caption lines.')
  p['caption_punctuation']=request.get('caption_punctuation',False) is True
  if p['caption'] not in captions.PRESETS:raise ValueError('Choose a supported caption style.')
  sw0=request.get('speech_words') or []
  if request.get('edit_groups') and not request.get('manually_edited') and sw0:
   # Results saved by 1.2.3 and older could repeat words at shot cuts. When the
   # editor has not changed any text, re-make the captions from the measured words.
   from speech_follow import _wkey
   sw,seen=[],set()
   for w in sw0:
    if _wkey(w) not in seen:seen.add(_wkey(w));sw.append(w)
   if len(sw)<len(sw0):
    words,t=[],0.
    for w in sw: # keep the spoken order; keep times moving forward
     a=max(t,float(w['start']));b=max(a+.01,float(w['end']));words.append(dict(text=str(w['text']),start=round(a,3),end=round(b,3)));t=a
    request['cues']=[dict(start=words[0]['start'],end=max(x['end'] for x in words),text=' '.join(x['text'] for x in words),words=words)]
    request.pop('edit_groups',None);request.pop('speech_words',None)
  if request.get('edit_groups'):
   rows=[]
   from ugc.sentences import transcript_words
   from speech_follow import merge_copies,_wkey
   repeated=False
   if request.get('speech_words'):
    sw,seen=[],set()
    for w in request['speech_words']:
     if _wkey(w) not in seen:seen.add(_wkey(w));sw.append(w)
    repeated=len(sw)<len(request['speech_words']);request['speech_words']=sw
   # An emptied caption means "delete it"; captions past a shortened sequence end are trimmed or dropped.
   kept=[r for r in request['edit_groups'] if str(r.get('text','')).strip()]
   if not kept:raise ValueError('Every caption is empty. Type caption text, or click Generate captions again.')
   for row in merge_copies(kept,repeated):
    a,b=max(0.,float(row['start'])),min(duration,float(row['end']));text=str(row['text']).strip()
    if not b-a>=1/60:continue
    rows.append(dict(start=a,end=b,text=text,words=transcript_words([dict(start=a,end=b,text=text)]),sentence_id=0))
   if not rows:raise ValueError('None of these captions are inside the sequence any more. Click Generate captions again.')
   if request.get('speech_words'):rows=_retime_rows(rows,request['speech_words'],duration)
   p['cues']=rows
   if request.get('reflow_policy'):
    p['caption_scene_cuts'],scene_analysis=collect(sequence,policy,stop,lambda m,n=0:emit(m,70+int(n*.1)))
    p=prepare(p,stop,lambda message,n:emit(message,82+n*.03));groups=p['_caption_flow_groups']
   else:groups=limit_groups(rows)
  else:
   if request.get('srt'):p['cues']=srt_cues(request['srt']);emit('Reflowing SRT; word timing is estimated within each subtitle.',25)
   elif request.get('cues'):p['cues']=request['cues']
   else:
    from ugc.speech import recognize
    # An In-Out export starts at the In point: place its words at their timeline times.
    if rng:p['media_segments']=[dict(start=rng[0],end=rng[1],prepared_path=p['source'],name='In-Out range')]
    p['cues']=recognize(p,'small.en','cpu',stop,lambda m,n=0:emit(m,5+int(n*.65)),folder)['cues']
    p.pop('media_segments',None)
   if any(c['end']>duration+.1 for c in p['cues']):raise ValueError('Captions extend beyond this sequence. Choose matching audio or SRT.')
   if rng:
    # Only part of the video: use the part of the script that was spoken there.
    from script_words import script_window,range_scripts
    p['original_script']=script_window(p['cues'],range_scripts(request))
   elif request.get('brief_sections'):
    from hook_choice import choose
    hook_choice=choose(request['brief_sections'],p['cues'],request.get('hook','auto'))
    p['original_script']=hook_choice['script']
   if str(p.get('original_script','')).strip() and request.get('script_words',True) is not False:
    from script_words import use_script;p['cues']=use_script(p['cues'],p['original_script'])
   # Numbers: digits unless the editor chose 'As written'. The cues kept for rebuilds stay unconverted so the setting can change.
   import caption_digits;p['_kandy_heard_cues']=p['cues'];p['cues']=caption_digits.apply(p['cues'],digits=request.get('caption_numbers')!='words')
   p['caption_scene_cuts'],scene_analysis=collect(sequence,policy,stop,lambda m,n=0:emit(m,70+int(n*.1)))
   emit('Preparing natural phrases with measured speech timing',82)
   p=prepare(p,stop,lambda message,n:emit(message,82+n*.03));groups=p['_caption_flow_groups']
  if request.get('edit_groups'):
   p['caption_scene_cuts'],scene_analysis=collect(sequence,policy,stop,lambda m,n=0:emit(m,70+int(n*.1)))
  if not groups:raise ValueError('No speech found.')
  from ugc.caption_timeline import connected_groups,split_at_scene_cuts
  from speech_follow import speech_groups,char_limit,snap_to_cuts
  groups=char_limit(p,groups,manual=bool(request.get("edit_groups")))
  groups=captions.fit_groups(p,groups,stop)
  groups=speech_groups(p,groups,manual=bool(request.get("edit_groups")))
  if policy=='shot':groups=snap_to_cuts(groups,p.get('caption_scene_cuts',[]))
  try:fill=max(0.,min(3600.,float(request.get('caption_fill_gap',0) or 0)))
  except (TypeError,ValueError):fill=0.
  if fill:
   from speech_follow import fill_gaps
   groups=fill_gaps(groups,fill,p.get('caption_scene_cuts',[]) if policy=='shot' else ())
  if rng:
   # Range captions stay between In and Out so they never cover captions outside it.
   for row in groups:row['start'],row['end']=max(float(row['start']),rng[0]),min(float(row['end']),rng[1])
   groups=[row for row in groups if row['end']-row['start']>=1/30]
   if not groups:raise ValueError('No speech found between the In and Out points.')
  # Use exact host dimensions in the existing renderer, without changing its
  # shared application defaults or source project files.
  style=colored_style(p,captions.PRESETS);states=[];srtrows=[]
  y=height-p['caption_y']*height/1920
  from ugc.caption_timeline import caption_text
  for row in groups:row['text']=caption_text(p,row['words'])
  # Every caption uses the selected size; fitting changes timed groups/lines.
  for row in groups:
   words=row['text'].split();layout=captions.layout(row["text"],{**style,"line_break":row.get("line_break",0)},p['caption_size'],y,0 if style.get('active') else None,width=width-200,canvas=(width,height))
   # Shadow rows repeat the text under it (they carry a fill alpha, \1a); keep them out of the SRT.
   lines=[re.sub(r'\{[^}]*\}','',text) for _,kind,text in layout if kind=='Main' and '\\1a' not in text]
   srtrows.append({**row,'text':'\n'.join(lines)})
   points=[(row['start'],None)]
   if style.get('active'):points=[(row['start'],0)]+[(max(row['start'],min(row['end'],w['start'])),i) for i,w in enumerate(row['words'][1:],1)]
   for i,(a,active) in enumerate(points):
    b=points[i+1][0] if i+1<len(points) else row['end']
    if b>a:states.append(dict(start=a,end=b,text=row['text'],rows=captions.layout(row["text"],{**style,"line_break":row.get("line_break",0)},p['caption_size'],y,active,width=width-200,canvas=(width,height))))
  captions.srt(folder/'captions.srt',srtrows)
  emit('Rendering styled caption overlays',86)
  import shutil
  fonts=folder/'fonts';shutil.copytree(app/'fonts',fonts,dirs_exist_ok=True)
  # Local licensed font stays on this computer and is never included in ZIPs.
  if style.get('file')=='@proxima':shutil.copy2(captions.font_path('@proxima'),fonts/__import__('ugc.caption_fonts',fromlist=['x']).caption_copy_name(captions.font_path('@proxima')))
  captions.write_ass(folder/'overlay.ass',[{**state,'start':i,'end':i+.9} for i,state in enumerate(states)],width,height)
  media.run(['ffmpeg','-y','-v','error','-f','lavfi','-i',f'color=c=black@0:s={width}x{height}:r=1,format=rgba','-vf','subtitles=overlay.ass:fontsdir=fonts:alpha=1','-frames:v',len(states),'-threads','1','-pix_fmt','rgba','caption_%05d.png'],stop,folder)
  for i,state in enumerate(states):state['path']=str(folder/f'caption_{i+1:05d}.png')
  # Show the actual caption at a readable scale instead of a tiny full-frame swatch.
  from PIL import Image
  with Image.open(folder/'caption_00001.png') as first:
   bounds=first.getchannel('A').getbbox()
   if bounds:
    left,top,right,bottom=bounds
    first.crop((max(0,left-24),max(0,top-20),min(width,right+24),min(height,bottom+20))).save(folder/'preview.png')
   else:first.save(folder/'preview.png')
  name='Kandy Captions '+folder.name
  overlay_xml(states,folder/'overlay.xml',width,height,float(sequence['fps']),duration,name)
  result=dict(sequence=sequence,default_size=72,default_position=933,style=p['caption'],size=p['caption_size'],position=p['caption_y'],preview=str(folder/'preview.png'),groups=[{k:r[k] for k in ('start','end','text')} for r in groups],srt=str(folder/'captions.srt'),xml=str(folder/'overlay.xml'),overlay_name=name,folder=str(folder),font=font_description(app) if style.get('file')=='@proxima' else style['font'],engine=ENGINE)
  from script_review import compare
  import caption_digits
  result['script_review']=compare(caption_digits.text(p.get('original_script',''),digits=request.get('caption_numbers')!='words'),groups)
  result['hook_choice']=hook_choice
  result['range']=rng
  result['caption_style_colors']=p['caption_style_colors']
  result.update(caption_max_lines=p['caption_max_lines'],caption_punctuation=p['caption_punctuation'],cut_policy=policy,caption_fill_gap=fill,caption_numbers='words' if request.get('caption_numbers')=='words' else 'digits',cues=p.get('_kandy_heard_cues',p['cues']),scene_analysis={**scene_analysis,'used_cuts':p.get('caption_scene_cuts',[]),'ignored_cuts':p.get('caption_ignored_scene_cuts',[])})
  result['speech_words']=request.get('speech_words') or ([] if request.get('edit_groups') else [dict(text=w.get('text',''),start=round(float(w['start']),3),end=round(float(w['end']),3)) for w in {_k:_w for r in groups for _w in r.get('words',[]) if 'start' in _w and 'end' in _w for _k in [(_w.get('text',''),round(float(_w['start']),3))]}.values()])
  (folder/'result.json').write_text(json.dumps(result,indent=2),encoding='utf-8');emit('Ready to review and add to Premiere',100)
  return result
 finally:stop.set()


def preview(request,app,folder):
 """One caption drawn exactly like the final render, over the sequence frame at the playhead."""
 from ugc import captions,media
 from ugc.caption_colors import validate,style as colored_style
 from ugc.caption_fonts import caption_copy_name
 from PIL import Image
 import shutil,hashlib
 stop=threading.Event()
 captions.PRESETS['client_box']={**captions.PRESETS['white_box'],'file':'@proxima','font':'Proxima Nova','size':100}
 sequence=request['sequence'];width,height=int(sequence['width']),int(sequence['height'])
 if not (64<=width<=8192 and 64<=height<=8192):raise ValueError('Unsupported sequence dimensions.')
 p=dict(caption=request.get('style','client_box'),caption_size=float(request.get('size',72)),caption_y=float(request.get('position',933)),
        caption_max_lines=int(request.get('caption_max_lines',1)),caption_punctuation=request.get('caption_punctuation',False) is True)
 if p['caption'] not in captions.PRESETS:raise ValueError('Choose a supported caption style.')
 if p['caption_max_lines'] not in (1,2):p['caption_max_lines']=1
 p['caption_style_colors']=validate(request.get('caption_style_colors',{}),captions.PRESETS)
 p['caption_style_effects']=request.get('caption_style_effects') if isinstance(request.get('caption_style_effects'),dict) else {}
 captions.PROXIMA_WEIGHT=(lambda w:w if w in ('Thin','Light','Regular','Medium','Semibold','Bold','Extrabold','Black') else '')(str((p['caption_style_effects'].get(p['caption']) or {}).get('weight','')))
 style=colored_style(p,captions.PRESETS);y=height-p['caption_y']*height/1920
 text=captions.clean_text(str(request.get('preview_text') or 'Your caption looks like this'),punctuation=p['caption_punctuation']) or 'Your caption looks like this'
 fonts=folder/'fonts';shutil.copytree(app/'fonts',fonts,dirs_exist_ok=True)
 if style.get('file')=='@proxima':shutil.copy2(captions.font_path('@proxima'),fonts/caption_copy_name(captions.font_path('@proxima')))
 rows=captions.layout(text,{**style,'line_break':0},p['caption_size'],y,0 if style.get('active') else None,width=width-200,canvas=(width,height))
 for old in folder.glob('caption_*.png'):old.unlink()
 captions.write_ass(folder/'overlay.ass',[dict(start=0,end=.9,text=text,rows=rows)],width,height)
 media.run(['ffmpeg','-y','-v','error','-f','lavfi','-i',f'color=c=black@0:s={width}x{height}:r=1,format=rgba','-vf','subtitles=overlay.ass:fontsdir=fonts:alpha=1','-frames:v',1,'-threads','1','-pix_fmt','rgba','caption_%05d.png'],stop,folder)
 # background: the visible video frame at the playhead (or the middle of the longest clip)
 at=request.get('at');at=float(at) if isinstance(at,(int,float)) else None
 pieces=[x for x in sequence.get('sceneSources',[]) if Path(str(x.get('path',''))).is_file()]
 bg=None;shown=None
 if pieces:
  pick=next((x for x in pieces if at is not None and float(x['start'])<=at<float(x['end'])),None)
  if pick:shown=at
  else:pick=max(pieces,key=lambda x:float(x['end'])-float(x['start']));shown=(float(pick['start'])+float(pick['end']))/2
  src=max(0.,float(pick['sourceStart'])+shown-float(pick['start']))
  frame=folder/('frame_'+hashlib.sha1(json.dumps([str(pick['path']),round(src,2),width,height]).encode()).hexdigest()[:16]+'.png')
  try:
   if not frame.exists():
    old=sorted(folder.glob('frame_*.png'),key=lambda x:x.stat().st_mtime)
    for x in old[:-8]:x.unlink()
    media.run(['ffmpeg','-y','-v','error','-ss',round(src,3),'-i',str(pick['path']),'-frames:v',1,'-vf',f'scale={width}:{height}:force_original_aspect_ratio=increase,crop={width}:{height}',frame.name],stop,folder)
   bg=Image.open(frame).convert('RGBA')
   if bg.size!=(width,height):bg=bg.resize((width,height))
  except Exception:bg=None;shown=None
 if bg is None:bg=Image.new('RGBA',(width,height),(46,52,58,255))
 with Image.open(folder/'caption_00001.png') as cap:bg.alpha_composite(cap.convert('RGBA'))
 scale=min(1.,960/height);out=bg.resize((max(1,round(width*scale)),max(1,round(height*scale))),Image.LANCZOS).convert('RGB')
 out.save(folder/'live_preview.jpg',quality=90)
 (folder/'preview.json').write_text(json.dumps(dict(path=str(folder/'live_preview.jpg'),frame=shown is not None,at=shown,width=width,height=height,text=text)),encoding='utf-8')
 return True
