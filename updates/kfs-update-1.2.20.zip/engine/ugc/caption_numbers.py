"""Deterministic number/unit boundaries; never rewrite measured numbers."""
import re

NUMBER_WORDS=set('zero one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen seventeen eighteen nineteen twenty thirty forty fifty sixty seventy eighty ninety hundred thousand million billion first second third fourth fifth sixth seventh eighth ninth tenth eleventh twelfth thirteenth fourteenth fifteenth sixteenth seventeenth eighteenth nineteenth twentieth thirtieth half quarter a an'.split())
UNITS=set('second seconds sec secs minute minutes min mins hour hours hr hrs day days week weeks wk wks month months year years yr yrs decade decades millisecond milliseconds ms percent percentage capsule capsules tablet tablets pill pills dose doses mg mcg gram grams milligram milligrams kilogram kilograms kg pound pounds lb lbs ounce ounces oz liter liters litre litres ml milliliter milliliters study studies adult adults question questions ingredient ingredients herb herbs'.split())
LABELS=set('second minute hour day week month year stage grade type class phase level question step'.split())
def norm(value):return str(value).casefold().strip(' ,.!?;:"“”()[]')
def number(value):
 text=norm(value)
 return text in NUMBER_WORDS or bool(re.fullmatch(r'\d[\d,.]*(?:st|nd|rd|th|%|[-–—/]\d[\d,.]*)?',text)) or ('-' in text and all(part in NUMBER_WORDS for part in text.split('-')))

def boundaries(raw):
 """Indices inside 72 hours / hour 72 / two to three years are atomic."""
 values=[norm(x) for x in raw];protected=set()
 for i,value in enumerate(values):
  if value in UNITS and i and number(values[i-1]):
   a=i-1
   while a>0 and number(values[a-1]) and i-a<6:a-=1
   if a>=2 and values[a-1] in {'to','through','and','-','–'} and number(values[a-2]):
    a-=2
    while a>0 and number(values[a-1]) and i-a<8:a-=1
   protected.update(range(a+1,i+1))
  if value in LABELS and i+1<len(values) and number(values[i+1]):
   end=i+1
   while end+1<len(values) and number(values[end+1]) and end-i<5:end+=1
   protected.update(range(i+1,end+1))
  # A percentage range carries its own unit. Do not treat the pronoun I
  # after a question number as a continuation of that number.
  if value.endswith('%') and i>=2 and values[i-1] in {'to','through','and'} and number(values[i-2]):
   protected.update((i-1,i))
  if value in {'stage','grade','class','phase','level'} and i+1<len(values) and values[i+1] in {'i','ii','iii','iv','v','vi','vii','viii','ix','x'}:
   protected.add(i+1)
 return protected
