"""Numbers in captions.
Always: tokens the speech recogniser splits are joined again (4 + ,000 -> 4,000; 24 + -7 -> 24/7).
Digits mode (the default): number words from the script or the recording become digits (three -> 3,
twenty-four -> 24, one hundred and fifty -> 150, fifty percent -> 50%, seven-day -> 7-day, twenty four seven -> 24/7). Thousands get a comma, like the recogniser writes them (4,000).
A lone "one" stays a word (this one, one day) unless it sits in a range (one or two, one to three).
Runs that are not one clear number (twenty twenty four, two three) are left as words."""
import re

ONES = {w: i for i, w in enumerate('zero one two three four five six seven eight nine ten eleven twelve thirteen fourteen '
                                     'fifteen sixteen seventeen eighteen nineteen'.split())}
TENS = {w: 10 * i for i, w in enumerate('_ _ twenty thirty forty fifty sixty seventy eighty ninety'.split()) if i > 1}
SCALES = {'thousand': 1000, 'million': 1000000, 'billion': 1000000000}
WORDS = set(ONES) | set(TENS) | set(SCALES) | {'hundred'}
RANGE = {'or', 'to', 'and', '-', '–'}

def _parts(text):
    """lead punctuation, core, trailing punctuation"""
    m = re.match(r'^([^\w$£€]*)(.*?)([^\w%]*)$', str(text), re.S)
    return m.group(1), m.group(2), m.group(3)

def _expand(core):
    """number words inside one token: twenty-four -> [twenty, four]; returns None if it is not all number words"""
    parts = core.lower().split('-')
    return parts if parts and all(p in WORDS for p in parts) else None

def _value(ws):
    """value of a list of number words, or None unless they form exactly one number"""
    n = len(ws)
    def below100(i):
        if i < n and ws[i] in TENS:
            if i + 1 < n and ws[i + 1] in ONES and 1 <= ONES[ws[i + 1]] <= 9: return TENS[ws[i]] + ONES[ws[i + 1]], i + 2
            return TENS[ws[i]], i + 1
        if i < n and ws[i] in ONES: return ONES[ws[i]], i + 1
        return None
    def below1000(i):
        r = below100(i)
        if not r: return None
        v, j = r
        if j < n and ws[j] == 'hundred' and 1 <= v <= 99:
            v *= 100; j += 1; k = j + 1 if j < n and ws[j] == 'and' else j
            r2 = below100(k)
            if r2 and r2[0] > 0: v, j = v + r2[0], r2[1]
        return v, j
    r = below1000(0)
    if not r: return None
    v, j = r; total = 0; last = None
    while j < n and ws[j] in SCALES and v > 0 and (last is None or SCALES[ws[j]] < last):
        last = SCALES[ws[j]]; total += v * last; j += 1; v = 0
        k = j + 1 if j < n and ws[j] == 'and' else j
        r = below1000(k)
        if r and r[0] > 0: v, j = r
    return total + v if j == n else None

def _fmt(v):
    return f'{v:,}'

def _merge(words, i, j, text):
    """words[i:j] -> one word with the timing of all of them"""
    w = dict(words[i]); w['text'] = text; w['end'] = words[j - 1]['end']
    w['raw'] = ' '.join(str(x.get('raw', x['text'])) for x in words[i:j])
    return words[:i] + [w] + words[j:]

def _join_splits(words):
    i = 0
    while i + 1 < len(words):
        a, b = str(words[i]['text']), str(words[i + 1]['text']).strip()
        la, ca, ta = _parts(a)
        if re.fullmatch(r'\d[\d,]*', ca) and not ta and re.match(r',\d{3}(?!\d)', b):          # 4 + ,000
            words = _merge(words, i, i + 2, a + b); continue
        if ca == '24' and not ta and re.match(r'[-–/]?7(?!\d)', b):                            # 24 + -7 / 7
            words = _merge(words, i, i + 2, la + '24/7' + _parts(b)[2]); continue
        i += 1
    return words

def _to_digits(words):
    out = []; i = 0; n = len(words)
    def core(k): return _parts(words[k]['text'])[1].lower() if 0 <= k < n else ''
    def numeric(k): return bool(re.fullmatch(r'\d[\d,.]*%?', core(k))) or bool(_expand(core(k)))
    while i < n:
        lead, c, trail = _parts(words[i]['text'])
        if _expand(c) is None:
            # seven-day -> 7-day: number words, then plain words, inside one hyphenated token
            bits = c.split('-')
            if len(bits) > 1:
                k = max((k for k in range(1, len(bits)) if _value([b.lower() for b in bits[:k]]) is not None), default=0)
                rest = bits[k:]
                if k and rest and all(re.fullmatch(r'[A-Za-z]+', r) and r.lower() not in WORDS for r in rest) and [b.lower() for b in bits[:k]] != ['one']:
                    out.append(dict(words[i], text=lead + str(_value([b.lower() for b in bits[:k]])) + '-' + '-'.join(rest) + trail)); i += 1; continue
            out.append(words[i]); i += 1; continue
        # longest run of number words (with "and" after hundred/thousand), ending at punctuation
        j, ws = i, []
        while j < n:
            l2, c2, t2 = _parts(words[j]['text'])
            parts = _expand(c2)
            if j > i and l2: break
            if parts is None:
                if c2.lower() == 'and' and ws and ws[-1] in ('hundred', 'thousand', 'million') and not t2 and j + 1 < n and _expand(_parts(words[j + 1]['text'])[1]):
                    ws.append('and'); j += 1; continue
                break
            ws += parts; j += 1
            if t2: break
        if ws and ws[-1] == 'and': ws.pop(); j -= 1
        last_trail = _parts(words[j - 1]['text'])[2]
        if ws == ['twenty', 'four', 'seven']:                                                             # twenty four seven
            out.append(_merge(words, i, j, lead + '24/7' + last_trail)[i]); i = j; continue
        v = _value(ws)
        lone_one = ws == ['one'] and not ((core(j) in RANGE and numeric(j + 1)) or (core(i - 1) in RANGE and numeric(i - 2)))
        if v is None or lone_one:
            out.extend(words[i:j]); i = j; continue
        text = lead + _fmt(v)
        if not last_trail and core(j) == 'percent':                                                       # fifty percent
            text += '%' + _parts(words[j]['text'])[2]; j += 1
        else:
            text += last_trail
        out.append(_merge(words, i, j, text)[i]); i = j
    # digits followed by the word percent
    k = 0
    while k + 1 < len(out):
        l, c, t = _parts(out[k]['text'])
        if re.fullmatch(r'\d[\d,.]*', c) and not t and _parts(out[k + 1]['text'])[1].lower() == 'percent':
            out = _merge(out, k, k + 2, l + c + '%' + _parts(out[k + 1]['text'])[2])
        k += 1
    return out

def apply(cues, digits=True):
    """New cues with joined number tokens (and digits for number words when digits=True). Input is not changed."""
    res = []
    for c in cues:
        ws = [dict(w) for w in (c.get('words') or [])]
        if not ws: res.append(dict(c)); continue
        ws = _join_splits(ws)
        if digits: ws = _to_digits(ws)
        res.append(dict(c, words=ws, text=' '.join(str(w['text']) for w in ws)))
    return res

def text(value, digits=True):
    """The same conversion for a plain text (a script), so the script review compares like with like."""
    ws = [dict(text=t, start=0.0, end=0.0) for t in str(value or '').split()]
    if not ws: return str(value or '')
    ws = _join_splits(ws)
    if digits: ws = _to_digits(ws)
    return ' '.join(w['text'] for w in ws)
