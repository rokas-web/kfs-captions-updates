"""After install: align the latest generated captions and show what changes."""
import sys, json
from pathlib import Path
engine = Path(sys.argv[1]); sys.path.insert(0, str(engine))
import speech_align as A
root = Path.home() / 'Documents' / 'Kandy For Scale Captions'
jobs = sorted([d for d in root.iterdir() if (d / 'result.json').is_file()], reverse=True) if root.is_dir() else []
job = next((d for d in jobs if (d / 'sequence.wav').is_file()), None)
if not job: print('No generated captions with audio found yet; generate once in Premiere.'); sys.exit()
r = json.loads((job / 'result.json').read_text(encoding='utf-8'))
p = dict(source=str(job / 'sequence.wav'), duration=r['sequence']['duration'], cues=r.get('cues', []))
print('Aligning', job.name, '(this can take a minute)...', flush=True)
amap = A.align_starts(p)
print('Alignment status:', A.STATUS)
words = {round(w['start'], 3): w['text'] for c in r.get('cues', []) for w in c.get('words', [])}
print('\nTiming check for the first 40 captions (a sample; captions are not missing):')
print(' caption                  | before  | aligned | change')
for g in r.get('groups', [])[:40]:
    k = round(g['start'], 3)
    near = min(words, key=lambda t: abs(t - k)) if words else None
    if near is None or abs(near - k) > .15: continue
    new = amap.get(near)
    if new is None: continue
    d = (new - near) * 30
    print(f" {g['text']:24} | {near:6.2f}s | {new:6.2f}s | {d:+.0f} frames")
