"""Timeline edits plus embedded visual cuts for normal-speed visible video."""
import hashlib
import json
import math
import os
import re
import sys
from pathlib import Path


def collect(sequence, policy, stop, update):
    if policy not in ('shot', 'continuous'):
        raise ValueError('Choose scene-aware captions or follow speech naturally.')
    if policy == 'continuous':
        return [], dict(policy=policy, timeline_cuts=0, embedded_cuts=0, notes=[])
    from ugc import media
    duration = float(sequence['duration'])
    cuts = {float(t) for t in sequence.get('sceneCuts', [])
            if math.isfinite(float(t)) and 0 < float(t) < duration}
    timeline_count = len(cuts)
    embedded = set()
    notes = []
    root = ((Path.home() / 'Library/Application Support') if sys.platform == 'darwin' else Path(os.environ.get('LOCALAPPDATA', str(Path.home())))) / 'KandyForScaleCaptions' / 'scene-cache'
    for piece in sequence.get('sceneSources', []):
        if stop.is_set():
            raise InterruptedError('Cancelled')
        start, end, source = (float(piece[k]) for k in ('start', 'end', 'sourceStart'))
        if not all(math.isfinite(v) for v in (start, end, source)) or not 0 <= start < end <= duration + .05 or source < 0:
            raise ValueError('Invalid sequence scene timing. Refresh the sequence.')
        path = Path(piece['path'])
        if not path.is_file():
            notes.append('A source video is offline; its timeline edit points were used.')
            continue
        length = end - start
        if length < .4:
            continue
        stat = path.stat()
        key = hashlib.sha256(json.dumps([str(path.resolve()), stat.st_size, stat.st_mtime_ns, source, length, 1]).encode()).hexdigest()
        root.mkdir(parents=True, exist_ok=True)
        cache = root / (key + '.json')
        try:
            try:
                values = json.loads(cache.read_text(encoding='utf-8'))
            except (OSError, ValueError):
                update('Checking scene cuts in ' + path.name, 35)
                output = media.run(['ffmpeg', '-hide_banner', '-ss', source, '-t', length, '-i', path, '-an',
                    '-vf', "scale=320:-2,fps=30,select='gt(scene,0.18)',metadata=mode=print:key=lavfi.scene_score,showinfo",
                    '-fps_mode', 'vfr', '-f', 'null', '-'], stop,
                    timeout=max(30, min(600, length * 3 + 10)), update=update,
                    label='Checking scene cuts in ' + path.name, total=length, progress_range=(35, 55))
                scores = [(float(t), float(score)) for t, score in re.findall(
                    r'Parsed_metadata[^\n]*pts_time:([\d.]+)\s*\n[^\n]*lavfi.scene_score=([\d.]+)', output)]
                clusters = []
                for record in scores:
                    if not clusters or record[0] - clusters[-1][-1][0] > .4:
                        clusters.append([])
                    clusters[-1].append(record)
                values = [max(c, key=lambda r: r[1])[0] for c in clusters
                          if len(c) < 3 or max(s for _, s in c) >= .35]
                cache.write_text(json.dumps(values), encoding='utf-8')
            embedded.update(start + t for t in values if math.isfinite(t) and .02 < t < length - .02)
        except InterruptedError:
            raise
        except (OSError, RuntimeError, ValueError, TypeError):
            notes.append('Scene analysis was unavailable for a source; its timeline edit points were used.')
    cuts.update(embedded)
    return sorted(cuts), dict(policy=policy, timeline_cuts=timeline_count,
                              embedded_cuts=len(embedded), notes=sorted(set(notes)))
