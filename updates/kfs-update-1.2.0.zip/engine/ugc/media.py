import json, subprocess, shutil, sys, time, tempfile, re
from pathlib import Path
from .core import word_units
from .geometry import frame_size
BASE=Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parents[1]))
def exe(name):
 from .media_tools import resolve
 return resolve(name,BASE)

def run(args,stop=None,cwd=None,timeout=None,update=None,label='Processing media',total=None,progress_range=(0,100)):
 if stop and stop.is_set():raise InterruptedError('Cancelled')
 with tempfile.TemporaryDirectory(prefix='media_log_') as logs, (Path(logs)/'output.log').open('w+b') as log:
  # pythonw/PyInstaller --windowed does not hide consoles started by FFmpeg.
  # CREATE_NO_WINDOW applies to every subprocess, including FFprobe.
  flags=subprocess.CREATE_NO_WINDOW if sys.platform=='win32' else 0
  try:p=subprocess.Popen([exe(args[0]),*map(str,args[1:])],stdout=log,stderr=log,cwd=cwd,creationflags=flags)
  except OSError as exc:raise RuntimeError(f'{args[0]} could not start. Close Premiere and rerun INSTALL_MAC.command to repair the Mac media tools. ({exc})') from exc
  born=last=time.monotonic()
  try:
   while p.poll() is None:
    if (stop and stop.is_set()) or (timeout and time.monotonic()-born>timeout):
     p.terminate()
     try:p.wait(3)
     except subprocess.TimeoutExpired:p.kill();p.wait()
     if stop and stop.is_set():raise InterruptedError('Cancelled')
     raise RuntimeError(f'{args[0]} did not respond within {timeout} seconds. Check the media file and retry.')
    now=time.monotonic()
    if update and now-last>=1:
     # FFmpeg's standard stats include the processed timestamp; read only the tail.
     with (Path(logs)/'output.log').open('rb') as reader:
      size=reader.seek(0,2);reader.seek(max(0,size-4096));tail=reader.read().decode('utf8','replace')
     matches=re.findall(r'time=(\d+):(\d+):(\d+(?:\.\d+)?)',tail)
     done=sum(float(v)*factor for v,factor in zip(matches[-1],(3600,60,1))) if matches else 0
     lo,hi=progress_range;n=lo+(hi-lo)*min(.99,done/total) if total and done else lo
     update(f'{label} · {int(now-born)}s elapsed'+(f' · {done:.0f}/{total:.0f}s processed' if total and done else ''),n);last=now
    if stop:stop.wait(.1)
    else:time.sleep(.1)
  finally:
   if p.poll() is None:
    p.terminate()
    try:p.wait(3)
    except subprocess.TimeoutExpired:p.kill();p.wait()
  log.seek(0);result=log.read().decode('utf8','replace')
  if p.returncode:raise RuntimeError(result[-3000:])
  return result

def probe(path,stop=None):
 d=json.loads(run(['ffprobe','-v','error','-show_format','-show_streams','-of','json',path],stop,timeout=30));return d

def duration(path):return float(probe(path)['format']['duration'])
def stamp(t):
 n=round(t*100);h,n=divmod(n,360000);m,n=divmod(n,6000);s,c=divmod(n,100);return f'{h}:{m:02}:{s:02}.{c:02}'
from .captions import PRESETS

def ass(p,path,limit=None,stop=None,update=None):
 from .captions import caption_states,headline_states,write_ass
 write_ass(path,caption_states(p,limit,stop,update)+headline_states(p),*frame_size(p))

def picture_filter(w=1080,h=1920):
 return f'[0:v]split=2[bg][fg];[bg]scale={w}:{h}:force_original_aspect_ratio=increase,crop={w}:{h},boxblur=20:2[b];[fg]scale={w}:{h}:force_original_aspect_ratio=decrease[f];[b][f]overlay=(W-w)/2:(H-h)/2,setsar=1,fps=30,format=yuv420p[v]'

def montage_filter(p,s,w,h,frames,still):
 """Normalize without stretching, then animate with subpixel cubic sampling (no integer crop jitter)."""
 fit=s.get('fit',p.get('montage_fit','crop'));fx=float(s.get('focal_x',.5));fy=float(s.get('focal_y',.5))
 motion=s.get('motion','auto')
 if motion=='auto':motion=p.get('montage_motion','auto');motion='in' if motion=='auto' else motion
 strength=float(s.get('motion_strength',p.get('montage_strength',.12)))
 animate=still and motion!='none' and strength>0 and frames>1
 bw,bh=w,h
 if fit=='blur':base=picture_filter(bw,bh).replace('[v]','[base]')
 elif fit=='fit':base=f'[0:v]scale={bw}:{bh}:force_original_aspect_ratio=decrease,pad={bw}:{bh}:(ow-iw)/2:(oh-ih)/2:color=black,setsar=1,fps=30,format=yuv420p[base]'
 else:base=f'[0:v]scale={bw}:{bh}:force_original_aspect_ratio=increase,crop={bw}:{bh}:x=(iw-ow)*{fx}:y=(ih-oh)*{fy},setsar=1,fps=30,format=yuv420p[base]'
 if not animate:return base.replace('[base]','[v]')
 t=f'min(1,on/{max(1,frames-1)})';ease=f'({t})*({t})*(3-2*({t}))'
 zoom=f'1+{strength}*({ease})' if motion=='in' else f'1+{strength}*(1-({ease}))' if motion=='out' else str(1+strength)
 if motion in ('left','right'):fx=f'(1-({ease}))' if motion=='left' else f'({ease})'
 if motion in ('up','down'):fy=f'(1-({ease}))' if motion=='up' else f'({ease})'
 # Transform the four corners instead of rounding the crop position each
 # frame. RGB sampling also avoids half-resolution chroma crop steps.
 x=f'(1-({zoom}))*W*({fx})';y=f'(1-({zoom}))*H*({fy})'
 right=f'({x})+W*({zoom})';bottom=f'({y})+H*({zoom})'
 return base+f";[base]format=gbrp,perspective=x0='{x}':y0='{y}':x1='{right}':y1='{y}':x2='{x}':y2='{bottom}':x3='{right}':y3='{bottom}':sense=destination:eval=frame:interpolation=cubic,setsar=1,format=yuv420p[v]"


def render(p,folder,stop,update,preview=False):
 from .encoding import select,CPU,GPUEncodeError
 encoder=select(stop,update,*frame_size(p,preview))
 fallback=False
 try:output=_render(p,folder,stop,lambda m,n:update(encoder.label+' · '+m,n),preview,encoder)
 except GPUEncodeError:
  # Restart ALL shots, so concat never mixes hardware and CPU bitstreams.
  update('GPU encoding failed · restarting this version on CPU',0)
  encoder=CPU;fallback=True
  output=_render(p,folder,stop,lambda m,n:update(encoder.label+' · '+m,n),preview,encoder)
 p['render_encoding']={'codec':encoder.codec,'label':encoder.label,'gpu':encoder.gpu,'cpu_fallback':fallback}
 return output

def _render(p,folder,stop,update,preview,encoder):
 from .encoding import cpu_threads
 from .caption_timeline import prepare
 update('Preparing caption phrases and layout',0)
 p=prepare(p)
 if p.get('workflow')=='captions':p.update(music='',music_volume=0)
 folder=Path(folder); work=folder/('preview_work' if preview else 'render_work');work.mkdir(exist_ok=True)
 scenes=p['scenes'];length=min(p['duration'],10) if preview else p['duration'];w,h=frame_size(p,preview)
 if p.get('workflow')=='montage':
  from .montage import validate
  validate(p,check_lengths=not bool(p.get('caption_picture_alignment')))
 ass(p,work/'captions.ass',length if preview else None,stop,lambda message,n:update(message,.04*n));shutil.copytree(BASE/'fonts',work/'fonts',dirs_exist_ok=True)
 from .caption_fonts import copy_caption_font
 copy_caption_font(p,BASE,work/'fonts')
 # A completed recording is already edited. Encode it once with captions,
 # avoiding a silent intermediate and a second full video encode.
 if p.get('workflow')=='captions' and p.get('export_mode')!='premiere' and p.get('silence_mode','off')=='off' and len(scenes)==1 and scenes[0].get('offset',0)==0 and Path(scenes[0]['path']).suffix.lower() in ('.mp4','.mov','.mkv','.webm','.avi'):
  source=scenes[0]['path'];info=probe(source,stop);vs=next(s for s in info['streams'] if s['codec_type']=='video')
  vf=f'[0:v]scale={w}:{h},setsar=1,fps=30,format=yuv420p[v]' if abs(vs['width']/vs['height']-w/h)<.001 else picture_filter(w,h)
  overlays=p.get('caption')!='none' or any(h.get('enabled',True) and h.get('headline') for h in p.get('hooks',[]))
  if overlays:vf=vf.replace('[v]','[base];[base]subtitles=captions.ass:fontsdir=fonts[v]')
  update('Preparing audio',4);audio_stems(p,work,stop,length)
  args=['ffmpeg','-y','-v','error','-stats','-threads',str(cpu_threads()),'-i',source,'-i','mix.wav','-filter_complex_threads','1','-filter_complex',vf,'-map','[v]','-map','1:a']
  tmp=work/'final.mp4';output=folder/('preview.mp4' if preview else 'UGC_Final.mp4')
  update('Encoding original recording with captions',5)
  encoder.encode(args,['-c:a','aac','-b:a','192k','-t',str(length),'-frames:v',str(round(length*30)),'-movflags','+faststart',tmp],stop,work,quality=19,preview=preview,update=update,label='Encoding original recording with captions',total=length,progress_range=(5,95))
  if abs(duration(tmp)-length)>.15:raise RuntimeError('Output duration verification failed')
  import license_client
  license_client.require(force=True)
  if stop.is_set():raise InterruptedError('Cancelled')
  shutil.move(tmp,output);return str(output)
 parts=[]
 for i,s in enumerate(scenes):
  if s['start']>=length:break
  if not s['path'] or not Path(s['path']).is_file():raise ValueError(f'Shot {i+1} needs footage. Assign a clip in the storyboard.')
  # Quantize cumulative boundaries, avoiding a rounding error on every shot.
  frames=round(min(s['end'],length)*30)-round(s['start']*30)
  if frames<=0:continue
  d=frames/30;dest=work/f'part{i:04}.mp4';off=max(0,float(s.get('offset',0)))
  from .actions import coverage_error
  error=coverage_error(s,d)
  if error and not preview:raise ValueError(f'Shot {i+1}: '+error)
  ext=Path(s['path']).suffix.lower();args=['ffmpeg','-y','-v','error','-threads',str(cpu_threads())]
  if ext in ('.jpg','.png','.jpeg','.webp'):args+=['-loop','1']
  else:
   available=duration(s['path'])-off
   if available+.08<d:raise ValueError(f'Shot {i+1}: clip has {max(0,available):.1f}s available but needs {d:.1f}s. Choose a longer clip or use shorter visual cuts. Automatic looping is disabled.')
   args+=['-ss',str(off)]
  args+=['-i',s['path']]
  # Keep all source content, filling unused space with its blurred copy.
  still=ext in ('.jpg','.png','.jpeg','.webp')
  motion_frames=round(s['end']*30)-round(s['start']*30)
  if p.get('workflow')=='montage':vf=montage_filter(p,s,w,h,motion_frames,still)
  elif still:vf=montage_filter({**p,'montage_fit':'blur'},s,w,h,motion_frames,True)
  else:vf=picture_filter(w,h)
  update(f'Rendering shot {i+1}/{len(scenes)}',int(i/max(1,len(scenes))*80))
  encoder.encode(args+['-filter_complex_threads','1','-filter_complex',vf,'-map','[v]','-an','-frames:v',str(frames)],[dest],stop,quality=22,preview=preview)
  parts.append(dest)
 (work/'concat.txt').write_text(''.join(f"file '{x.name}'\n" for x in parts),encoding='utf8')
 run(['ffmpeg','-y','-v','error','-f','concat','-safe','0','-i','concat.txt','-c','copy','silent.mp4'],stop,work)
 audio_stems(p,work,stop,length)
 args=['ffmpeg','-y','-v','error','-i','silent.mp4','-i','mix.wav','-map','0:v','-map','1:a']
 overlays=p.get('caption')!='none' or any(h.get('enabled',True) and h.get('headline') for h in p.get('hooks',[]))
 if overlays:args+=['-vf','subtitles=captions.ass:fontsdir=fonts']
 output=folder/('preview.mp4' if preview else 'UGC_Final.mp4');tmp=work/'final.mp4'
 update('Combining recording audio and captions' if p.get('workflow')=='captions' else 'Mixing voice, music and captions',88)
 tail=['-c:a','aac','-b:a','192k','-t',str(length),'-movflags','+faststart',tmp]
 if overlays:encoder.encode(args,tail,stop,work,quality=19,preview=preview)
 else:run(args+['-c:v','copy']+tail,stop,work)
 if abs(duration(tmp)-length)>.15:raise RuntimeError('Output duration verification failed')
 if p.get('workflow')=='captions':
  import license_client
  license_client.require(force=True)
  if stop.is_set():raise InterruptedError('Cancelled')
 shutil.move(tmp,output);return str(output)


def audio_stems(p,work,stop,length):
 work=Path(work);source=p.get('audio_source') or p['source']
 music='' if p.get('workflow')=='captions' else p.get('music','')
 args=['ffmpeg','-y','-v','error','-i',source]
 if music:
  args+=['-stream_loop','-1','-i',music]
  mix=f'[0:a]loudnorm=I=-16:TP=-1.5:LRA=11,aresample=48000,aformat=channel_layouts=stereo,asplit=3[v][side][voice];[1:a]aresample=48000,aformat=channel_layouts=stereo,volume={float(p.get("music_volume",.12))},afade=t=in:d=0.4,afade=t=out:st={max(0,length-1)}:d=1[bed];[bed][side]sidechaincompress=threshold=0.03:ratio=8:attack=15:release=350,asplit=2[duck][music];[v][duck]amix=inputs=2:duration=first:normalize=0,alimiter=limit=0.95[mix]'
  media_outputs=['-map','[mix]','-t',str(length),'-ar','48000','-ac','2',work/'mix.wav','-map','[voice]','-t',str(length),'-ar','48000','-ac','2',work/'voice.wav','-map','[music]','-t',str(length),'-ar','48000','-ac','2',work/'music.wav']
 else:
  mix='[0:a]loudnorm=I=-16:TP=-1.5:LRA=11,aresample=48000,aformat=channel_layouts=stereo,alimiter=limit=0.95,asplit=2[mix][voice]'
  media_outputs=['-map','[mix]','-t',str(length),'-ar','48000','-ac','2',work/'mix.wav','-map','[voice]','-t',str(length),'-ar','48000','-ac','2',work/'voice.wav']
 run(args+['-filter_complex',mix]+media_outputs,stop)

def style_preview(p,folder,stop=None):
 if p.get('workflow')=='captions':
  from .style_preview import render as caption_style_preview
  return caption_style_preview(p,folder,stop)
 from .captions import caption_states,headline_states,write_ass
 import copy
 folder=Path(folder);work=folder/'style_preview';work.mkdir(exist_ok=True)
 sample=copy.deepcopy(p);sample.pop('caption_phrase_edits',None);sample['cues']=[{'start':0,'end':3,'text':'Your everyday story'}];sample.pop('sentence_analysis',None);sample['media_segments']=[];sample['scenes']=[];sample['caption_scene_cuts']=[];sample['duration']=3
 sample['hooks']=[dict(start=0,end=3,headline=next((h['headline'] for h in p.get('hooks',[]) if h.get('headline')),'Your hook headline'),emphasis=next((h.get('emphasis','') for h in p.get('hooks',[]) if h.get('headline')),''),enabled=True)] if p.get('hooks') else []
 write_ass(work/'style.ass',caption_states(sample)+headline_states(sample),*frame_size(p));shutil.copytree(BASE/'fonts',work/'fonts',dirs_exist_ok=True)
 from .caption_fonts import copy_caption_font
 copy_caption_font(p,BASE,work/'fonts')
 w,h=frame_size(p,True)
 shot=next((s for s in p.get('scenes',[]) if s.get('path') and Path(s['path']).is_file()),None)
 if shot:
  args=['ffmpeg','-y','-v','error','-ss',str(shot.get('offset',0)),'-i',shot['path']]
  vf=(montage_filter(p,shot,w,h,1,Path(shot['path']).suffix.lower() in ('.jpg','.png','.jpeg','.webp')) if p.get('workflow')=='montage' else picture_filter(w,h)).replace('[v]',"[base];[base]subtitles=style.ass:fontsdir=fonts[v]")
  args+=['-filter_complex_threads','1','-filter_complex',vf,'-map','[v]']
 else:args=['ffmpeg','-y','-v','error','-f','lavfi','-i',f'color=c=0x344044:s={w}x{h}:r=1','-vf','subtitles=style.ass:fontsdir=fonts']
 output=work/'sample.png';run(args+['-frames:v','1','-threads','1',output.name],stop,work)
 return str(output)
