"""Correct recognized speech from a supplied recording script using measured word times."""
import re,copy,json,hashlib
from difflib import SequenceMatcher
from .core import word_units,tokens

def key(word):return ''.join(sorted(tokens(word)))

# Standalone writing marks have no spoken duration. Keep symbols such as $, %,
# + and /, which can carry spoken meaning and must still pass alignment checks.
UNSPOKEN_PUNCTUATION=frozenset(".,;:!?—–-…()[]{}\"'“”‘’«»•·")
def punctuation_only(text):
 text=str(text).strip()
 return bool(text) and all(c in UNSPOKEN_PUNCTUATION for c in text)

class AlignmentError(ValueError):
 def __init__(self,message,issue):
  super().__init__(message);self.issue=issue

def script_inputs(p):
 pieces=p.get('media_segments') or [dict(id='single',start=0,end=p['duration'],name='Narration')]
 scripts=p.get('segment_scripts',{}) if p.get('media_segments') else {'single':p.get('original_script','')}
 if any(not str(scripts.get(piece['id'],'')).strip() for piece in pieces):raise ValueError('Paste the exact script for every recording. For completed videos, choose each file’s brief hook or paste its script.')
 return pieces,scripts

def audio_signature(p):
 from pathlib import Path
 paths=[p.get('source','')]+[s.get('prepared_path','') for s in p.get('media_segments',[])]
 stamps=[]
 for path in paths:
  if not path:stamps.append([path,None,None]);continue
  try:stat=Path(path).stat();stamps.append([path,stat.st_size,stat.st_mtime_ns])
  except OSError:stamps.append([path,None,None])
 return hashlib.sha256(json.dumps([stamps,p.get('duration'),p.get('media_segments',[])],sort_keys=True).encode()).hexdigest()

def review_signature(p):
 return hashlib.sha256(json.dumps([audio_signature(p),p.get('original_script',''),p.get('segment_scripts',{})],sort_keys=True).encode()).hexdigest()

def align(cues,script):
 original=[w for w in word_units(cues) if not punctuation_only(w['text'])]
 raw_expected=str(script).split()
 expected_indices=[i for i,text in enumerate(raw_expected) if not punctuation_only(text)]
 expected=[raw_expected[i] for i in expected_indices]
 if not original or not expected:raise ValueError('Paste the spoken script and transcribe the audio first.')
 if len(expected)>6000:raise ValueError('Script alignment supports up to 6,000 words per input.')
 from .currency_alignment import equivalent_words
 original,currency_spans,currency_mismatch=equivalent_words(original,expected,key)
 matcher=SequenceMatcher(None,[key(w['text']) for w in original],[key(w) for w in expected],autojunk=False)
 operations=matcher.get_opcodes()
 def fail(message,reason,a,b,c,d):
  left=original[a]['start'] if a<len(original) else original[-1]['end']
  right=original[b-1]['end'] if b>a else left
  raw_c=expected_indices[c] if c<len(expected_indices) else len(raw_expected)
  raw_d=expected_indices[d-1]+1 if d>c else raw_c
  issue=dict(reason=reason,expected=' '.join(expected[c:d]),heard=' '.join(w['text'] for w in original[a:b]),expected_context=' '.join(raw_expected[max(0,raw_c-5):min(len(raw_expected),raw_d+5)]),heard_context=' '.join(w['text'] for w in original[max(0,a-5):min(len(original),max(a,b)+5)]),start=left,end=right,expected_word_start=raw_c,expected_word_end=raw_d,agreement=round(matcher.ratio(),3))
  raise AlignmentError(message,issue)
 if currency_mismatch:
  fail('The recorded amount or currency differs from the script. Check this passage before aligning.','currency_mismatch',*currency_mismatch)
 if matcher.ratio()<.58:
  tag,a,b,c,d=next((op for op in operations if op[0]!='equal'),operations[0])
  fail('The script differs too much from this recording. Use the exact spoken version; existing timing is preserved.','different_script',a,b,c,d)
 aligned=[];corrections=0
 for tag,a,b,c,d in operations:
  if tag=='equal':
   aligned.extend({**copy.deepcopy(w),'text':text} for w,text in zip(original[a:b],expected[c:d]));continue
  if max(b-a,d-c)>12:fail('A long script passage does not match the recording. Correct the script and try again; existing timing is preserved.','long_passage',a,b,c,d)
  corrections+=max(b-a,d-c)
  if tag=='delete':continue
  if a==b:
   left=original[a-1]['end'] if a else original[0]['start'];right=original[a]['start'] if a<len(original) else original[-1]['end']
   if right-left<.08*(d-c):fail('The script contains words with no detected speech interval. Check that the script matches the recording.','missing_interval',a,b,c,d)
  else:left=original[a]['start'];right=original[b-1]['end']
  if right<=left:fail('Invalid speech timing. Transcribe again before applying the script.','invalid_timing',a,b,c,d)
  for j,text in enumerate(expected[c:d]):aligned.append(dict(text=text,start=left+(right-left)*j/(d-c),end=left+(right-left)*(j+1)/(d-c)))
 rows=[];sentence=[]
 for w in aligned:
  sentence.append(w)
  if re.search(r'[.!?]["”’]*$',w['text']):
   rows.append(dict(start=sentence[0]['start'],end=sentence[-1]['end'],text=' '.join(v['text'] for v in sentence),words=sentence));sentence=[]
 if sentence:rows.append(dict(start=sentence[0]['start'],end=sentence[-1]['end'],text=' '.join(v['text'] for v in sentence),words=sentence))
 report=dict(words=len(aligned),corrected_words=corrections,agreement=round(matcher.ratio(),3))
 ignored=len(raw_expected)-len(expected)
 if ignored:report['ignored_punctuation_tokens']=ignored
 if currency_spans:report['normalized_currency_spans']=currency_spans
 return rows,report

def apply(p):
 pieces,scripts=script_inputs(p)
 results=[];reports=[]
 hook=0
 for piece in pieces:
  if piece.get('kind')=='hook':hook+=1
  label=f'H{hook}' if piece.get('kind')=='hook' else 'BODY' if piece.get('kind')=='body' else 'Narration'
  words=[w for w in word_units(p.get('speech_cues') or p['cues']) if piece['start']<=(w['start']+w['end'])/2<piece['end']]
  try:
   if not words:
    expected=scripts[piece['id']].split()
    raise AlignmentError('No speech detected in this recording.',dict(reason='no_speech',expected=' '.join(expected[:12]),heard='',expected_context=' '.join(expected[:18]),heard_context='',start=piece['start'],end=piece['start'],expected_word_start=0,expected_word_end=min(12,len(expected)),agreement=0))
   rows,report=align([dict(start=piece['start'],end=piece['end'],text='',words=words)],scripts[piece['id']])
  except AlignmentError as exc:
   issue=exc.issue;issue.update(segment_id=piece['id'],section=label,name=piece['name'],file=piece.get('input_path') or p.get('source',''),local_start=max(0,issue['start']-piece['start']),local_end=max(0,issue['end']-piece['start']),listen_start=max(piece['start'],issue['start']-2),listen_end=min(piece['end'],issue['end']+3))
   excerpt=issue['expected'][:180] or issue['heard'][:180]
   message=f'{label} · {piece["name"]}: cannot align “{excerpt}” near {issue["local_start"]:.1f}s in this recording. Open Speech timing to review the mismatch.'
   raise AlignmentError(message,issue) from exc
  results.extend(rows);reports.append({**report,'name':piece['name']})
 return results,reports
