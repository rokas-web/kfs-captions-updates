"""Shared hook limits for script import, matching and project inputs."""
MAX_HOOKS=50
HOOK_PATTERN=r'H(?:[1-9]|[1-4][0-9]|50)'

def hook_number(label):
 return int(label[1:])
