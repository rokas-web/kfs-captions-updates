"""Sparse, measured story inserts over externally produced presenter audio."""
import copy, hashlib, html, json, math, re, shutil
from pathlib import Path
from .core import word_units
from .hook_limits import HOOK_PATTERN


def clean(text):
 text=html.unescape(text).replace('\xa0',' ')
 text=re.sub(r'\\\s*\n','\n',text)
 return re.sub(r'[*`]', '',text).strip()


def parse_brief(text):
 text=clean(text)
 # The brief/idea is not part of the spoken script.
 lines=text.splitlines();sections={};current=None;buffer=[]
 def commit():
  if current:sections[current]='\n'.join(buffer).strip()
 for line in lines:
  label=re.sub(r'^#+\s*','',line.strip()).rstrip(':').upper()
  if re.fullmatch(HOOK_PATTERN+r'|BODY',label):
   commit();current=label;buffer=[]
  elif re.fullmatch(r'H[0-9]+',label):raise ValueError('Use up to 50 hooks, H1–H50')
  elif current:buffer.append(line)
 commit()
 if not sections:sections={'SINGLE':text}
 result={}
 for key,raw in sections.items():
  from .brief_directions import mark_directions
  raw=mark_directions(raw)
  if raw.count('[')!=raw.count(']'):raise ValueError(f'{key}: close every bracketed visual direction before importing.')
  # Balanced brackets also allow nested editorial notes.
  pieces=[];directions=[];cursor=0;i=0
  while i<len(raw):
   if raw[i]!='[':i+=1;continue
   pieces.append(raw[cursor:i]);depth=1;j=i+1
   while j<len(raw) and depth:
    depth+=(raw[j]=='[')-(raw[j]==']');j+=1
   if depth:raise ValueError(f'{key}: unclosed visual direction.')
   spoken_before=' '.join(' '.join(pieces).split());index=len(spoken_before.split())
   directions.append(dict(after_word=index,visual=' '.join(raw[i+1:j-1].split())))
   i=j;cursor=j
  pieces.append(raw[cursor:]);spoken=' '.join(' '.join(pieces).split())
  if not spoken:
   if key.startswith('H'):result[key]=dict(spoken='',directions=directions,body_only=True);continue
   raise ValueError(f'{key}: no spoken words.')
  # A direction describes the passage immediately before it.
  previous=0
  for d in directions:
   d['first_word']=previous;previous=d['after_word']
  result[key]=dict(spoken=spoken,directions=directions)
 return result


def attach_scripts(p):
 if p.get('workflow')=='captions':
  from .caption_only import attach_scripts as attach_captions
  attach_captions(p);return
 if p.get('workflow')=='montage' and p.get('visual_brief'):
  from .montage_brief import attach_scripts as attach_montage
  attach_montage(p);return
 brief=p.get('story_brief',{})
 if not brief:return
 pieces=p.get('media_segments',[])
 if not pieces:
  if len(brief)==1:p['original_script']=next(iter(brief.values()))['spoken']
  return
 hooks=[s for s in pieces if s['kind']=='hook']
 expected={f'H{i+1}' for i in range(len(hooks))}|{'BODY'}
 if set(brief)!=expected:raise ValueError('Import the same number of hook videos as H sections in the brief, plus one BODY video.')
 scripts={}
 for i,piece in enumerate(hooks):scripts[piece['id']]=brief[f'H{i+1}']['spoken']
 body=next(s for s in pieces if s['kind']=='body');scripts[body['id']]=brief['BODY']['spoken'];p['segment_scripts']=scripts


def category(visual):
 t=visual.lower()
 for name,pattern in [('leave',r'suitcase|door closes|he leaves'),('dana',r'porch|dana.*wine|dining table'),('product',r'sculptique bottle|capsules|bottle.*counter'),('improve',r'jeans|smaller.*belly|sharper jaw|ankle bone'),('payoff',r'burgundy dress|stage|diploma'),('body',r'bloat|puffy|swollen|belly|ankle'),('mechanism',r'3d|animation|vessel')]:
  if re.search(pattern,t):return name
 return 'story'


def sparse_plan(p):
 if p.get('story_edit_style')=='reference':
  from .story_style import reference_plan
  return reference_plan(p)
 from adstudio.shot_direction import camera_shots
 if p.get('alignment_review'):raise ValueError('Resolve the speech mismatch in Media before planning story inserts.')
 if p.get('source_type')!='talking' or not p.get('source'):raise ValueError('Import HeyGen talking-head video hooks/body first.')
 if not p.get('script_alignment'):raise ValueError('Use script + align to audio first. Story inserts use measured speech timing, never word-count estimates.')
 brief=p.get('story_brief')
 if not brief:raise ValueError('Import the client brief first.')
 words=word_units(p['cues']);pieces=p.get('media_segments') or [dict(id='single',kind='single',start=0,end=p['duration'])]
 hooks=[s for s in pieces if s['kind']=='hook'];body=next((s for s in pieces if s['kind']=='body'),pieces[0])
 max_count=int(p.get('story_max_inserts',8));coverage=float(p.get('story_coverage',.2));length=float(p.get('story_insert_seconds',6))
 groups=[]
 for n,piece in enumerate(pieces):
  key='BODY' if piece['kind']=='body' else f'H{n+1}' if piece['kind']=='hook' else next(iter(brief))
  if key not in brief:raise ValueError('Brief sections and presenter inputs differ. Import matching hooks/body.')
  units=[w for w in words if piece['start']<=(w['start']+w['end'])/2<piece['end']]
  from .script import key as word_key
  if [word_key(w['text']) for w in units]!=[word_key(t) for t in brief[key]['spoken'].split()]:raise ValueError('Script timing changed. Align the exact brief to the recording again.')
  candidates=[]
  for index,d in enumerate(brief[key]['directions']):
   first=d['first_word'];last=d['after_word']
   if last<=first or first>=len(units):continue
   # Use one coherent first action; car returns are already provided by HeyGen.
   visual,omitted=camera_shots(d['visual'])
   if not visual or re.match(r'^(?:Car selfie|Car,? selfie|Same car)',visual,re.I):continue
   a=max(piece['start'],units[first]['start']);b=min(piece['end'],a+length,units[min(last,len(units))-1]['end']+.25)
   a=max(math.ceil(piece['start']*30)/30,round(a*30)/30);b=min(math.floor(piece['end']*30)/30,round(b*30)/30)
   if b-a<1:continue
   # Prefer the central story turns, then add variety if budget permits.
   cat=category(visual);score={'leave':100,'dana':95,'product':90,'body':85,'improve':80,'payoff':75,'story':45,'mechanism':35}[cat]
   candidates.append(dict(id=hashlib.sha256(f'{piece["id"]}:{index}:{a}:{b}'.encode()).hexdigest()[:12],start=a,end=b,text=' '.join(w['text'] for w in units[first:last]),visual=visual,omitted_shots=omitted,section=key,category=cat,score=score,enabled=True))
  groups.append((piece,candidates))
 # One opening per hook. The shared body's budget is safe for every final variant.
 openings=[]
 for piece,candidates in groups:
  if piece['kind']=='hook' and candidates:
   s=copy.deepcopy(candidates[0]);s['end']=min(s['end'],s['start']+4,round((piece['end']-piece['start'])*coverage*30)/30+s['start'])
   if s['end']-s['start']>=1:openings.append(s)
 if hooks:
  body_budget=min(coverage*((h['end']-h['start'])+(body['end']-body['start']))-next((s['end']-s['start'] for s in openings if s['section']==f'H{i+1}'),0) for i,h in enumerate(hooks))
 else:body_budget=coverage*p['duration']
 pool=next(rows for piece,rows in groups if piece['id']==body['id']);selected=[];used=set();remaining=max(0,body_budget)
 max_body=max(0,max_count-(1 if openings else 0))
 while pool and len(selected)<max_body and remaining>=1:
  pool.sort(key=lambda s:(s['category'] not in used,s['score']),reverse=True);s=pool.pop(0)
  if any(not(s['end']+5<=t['start'] or s['start']>=t['end']+5) for t in selected):continue
  s['end']=min(s['end'],s['start']+math.floor(remaining*30)/30)
  selected.append(s);used.add(s['category']);remaining-=s['end']-s['start']
 p['story_slots']=sorted(openings+selected,key=lambda s:s['start']);rebuild(p)
 p.update(planner_version=8,needs_rebuild=False)
 return p


def validate_slots(p):
 slots=p.get('story_slots',[])
 if not isinstance(slots,list) or len(slots)>400:raise ValueError('Invalid story insert list.')
 seen=set();last=0
 pieces=p.get('media_segments') or [dict(start=0,end=p.get('duration',0),kind='single')]
 for s in sorted((s for s in slots if s.get('enabled',True)),key=lambda s:float(s['start'])):
  a=float(s['start']);b=float(s['end'])
  if s['id'] in seen or not 0<=a<b<=p.get('duration',0)+.01 or a<last-.001:raise ValueError('Story inserts must be distinct, nonoverlapping, positive intervals inside the narration.')
  if not any(a>=v['start']-.001 and b<=v['end']+.001 for v in pieces):raise ValueError('A story insert cannot cross a hook/body boundary.')
  if b-a>15:raise ValueError('Story inserts must be 15 seconds or shorter.')
  seen.add(s['id']);last=b
 body=p.get('body_range');hooks=p.get('hooks',[]) if p.get('media_mode')=='hooks' else []
 ranges=[[(h['start'],h['end']),(body['start'],body['end'])] for h in hooks] if hooks and body else [[(0,p.get('duration',0))]]
 for rangeset in ranges:
  active=[s for s in slots if s.get('enabled',True) and any(s['start']>=a-.001 and s['end']<=b+.001 for a,b in rangeset)]
  length=sum(b-a for a,b in rangeset);amount=sum(s['end']-s['start'] for s in active)
  if len(active)>int(p.get('story_max_inserts',8)) or amount>float(p.get('story_coverage',.2))*length+.034:raise ValueError('Story inserts exceed the maximum count or coverage for a final version. Disable/shorten inserts or raise the limits.')


def rebuild(p):
 validate_slots(p);scenes=[];cursor=0
 for s in sorted((s for s in p.get('story_slots',[]) if s.get('enabled',True)),key=lambda s:s['start']):
  if s['start']>cursor:scenes.append(presenter(p,cursor,s['start']))
  path=s.get('path','');scenes.append(dict(id=s['id'],start=s['start'],end=s['end'],text=s['text'],context=s['text'],visual=s['visual'],kind='ugc' if path else 'presenter',path=path or p['source'],offset=float(s.get('offset',0)) if path else s['start'],review=bool(path and s.get('review',True)),reason='Story insert · review imported clip' if path else 'Presenter until this insert is approved',prompt=s['visual'],story_slot=s['id']))
  cursor=s['end']
 if cursor<p['duration']:scenes.append(presenter(p,cursor,p['duration']))
 # The hook/body boundary must remain explicit for export trimming.
 boundaries=[v['end'] for v in p.get('media_segments',[])][:-1]
 from .versions import retime_rows
 for cut in boundaries:
  split=[]
  for s in scenes:
   if s['start']<cut<s['end']:
    a=copy.deepcopy(s);b=copy.deepcopy(s);a['end']=cut;b['start']=cut;b['offset']+=cut-s['start'];b['id']+='b';split.extend([a,b])
   else:split.append(s)
  scenes=split
 p['scenes']=scenes
 for key in ('render_file','preview_file','package_file','exports'):p.pop(key,None)


def presenter(p,a,b):
 return dict(id=hashlib.sha256(f'presenter:{a}:{b}'.encode()).hexdigest()[:12],start=a,end=b,text=' '.join(w['text'] for w in word_units(p['cues']) if a<=(w['start']+w['end'])/2<b),kind='presenter',path=p['source'],offset=a,review=False,reason='Original HeyGen presenter',prompt='')


def slot_signature(s):
 return hashlib.sha256(json.dumps({k:s.get(k) for k in ('id','start','end','text','visual')},sort_keys=True).encode()).hexdigest()


def cast_preset():
 return [dict(id='lead',name='Lead / HeyGen presenter',identity='Fictional 50-year-old Black woman. Use the exact approved HeyGen identity reference, same face, age, skin tone and hairstyle throughout.',states=[dict(id='before',description='Before: same face and age; body concerns only as described in script. Wear exactly the wardrobe stated in the scene, with no outfit substitution.'),dict(id='after',description='After: same face and age, modest reduction in puffiness only as described in the script. Wear the exact scene wardrobe: jeans for jeans scenes, burgundy dress only when requested. Do not de-age or replace her.')]),dict(id='ex',name='David / ex-husband',identity='Fictional Black man in his 50s, fixed approved face and hairstyle.',states=[]),dict(id='girlfriend',name='Girlfriend',identity='Fictional 28-year-old Black woman, long dark hair, fixed approved face.',states=[]),dict(id='dana',name='Dana',identity='Fictional Black woman in her 50s, best friend, distinct from lead.',states=[]),dict(id='daughter',name='Daughter',identity='Fictional adult Black woman, graduation daughter, distinct from girlfriend.',states=[])]


def scene_cast(s,preset):
 if not preset:return []
 t=s['visual'].lower();roles=[]
 if re.search(r'\blead\b|\bshe\b|\bher\b|\bwoman\b',t):roles.append('lead')
 if re.search(r'\bex\b|\bhusband\b|\bhe\b|suitcase',t):roles.append('ex')
 if re.search(r'28.year.old|girlfriend|young woman',t):roles.append('girlfriend')
 if 'dana' in t:roles.append('dana')
 if 'daughter' in t and re.search(r'daughter.*(?:diploma|gown|stage)|her daughter',t):roles.append('daughter')
 if s['category']=='mechanism':roles=[]
 after=s['category']=='improve' or 'burgundy' in t or (s['section'].startswith('H') and bool(re.search(r'graduation|school gym|auditorium',t)))
 return [dict(role=r,state='after' if r=='lead' and after else 'before' if r=='lead' else '') for r in list(dict.fromkeys(roles))[:2 if 'sculptique' in t else 3]]


def bridge(studio,id,animation):
 studio.idle(id);p=studio.load(id);validate_slots(p)
 if p.get('alignment_review'):raise ValueError('Resolve the speech mismatch in Media before opening B-roll generation.')
 slots=[s for s in p.get('story_slots',[]) if s.get('enabled',True)]
 if p.get('workflow')!='presenter' or not p.get('script_alignment'):raise ValueError('Align a presenter story before preparing generation.')
 if not slots:raise ValueError('Plan and enable at least one story insert first.')
 mode=p.get('story_cast_mode','legacy' if p.get('story_cast_preset',True) else 'custom')
 ai_cast=mode=='ai';approved_roles=None;assigned=None;reference_job=None
 if ai_cast:
  from .cast import roles,assignments_current,character_signature,workspace_reference_signature,copy_references
  approved_roles=roles(p)
  if not assignments_current(p):raise ValueError('Assign the approved cast to the selected inserts with AI, then review the scene assignments.')
  assigned=p['cast_assignments']['slots']
  if p.get('cast_workspace',{}).get('id'):
   try:reference_job=animation.store.load(p['cast_workspace']['id'])
   except FileNotFoundError:pass
   if reference_job and animation.studio.jobs.get(reference_job['id']) and animation.studio.jobs[reference_job['id']].is_alive():raise ValueError('Finish/pause character reference generation before preparing scene generation.')
 old=p.get('story_generation',{});previous_job=None
 if old.get('id'):
  try:previous_job=animation.store.load(old['id'])
  except FileNotFoundError:pass
  if previous_job and animation.studio.jobs.get(old['id']) and animation.studio.jobs[old['id']].is_alive():raise ValueError('Pause the current generation batch before preparing another one.')
 signature=hashlib.sha256((mode+str(p.get('story_cast_preset',True))+''.join(slot_signature(s) for s in slots)).encode()).hexdigest()
 if ai_cast:
  from .cast import digest
  refsource=reference_job or previous_job or {'roles':[]}
  signature=digest({'slots':signature,'characters':approved_roles,'assignments':assigned,'references':workspace_reference_signature(refsource)})
 if old.get('signature')==signature:
  try:
   job=animation.store.load(old['id'])
   if animation.studio.jobs.get(job['id']) and animation.studio.jobs[job['id']].is_alive():return old
   job['story_review_required']=p.get('story_edit_style')=='reference'
   for scene in job['scenes']:scene['story_edit_style']=p.get('story_edit_style','sparse')
   job['story_workers']=int(p.get('story_workers',2));job['story_context']=p.get('story_brief_text') or p.get('original_script','');job['local_clip_candidates']=copy.deepcopy(p.get('assets',[]));
   if p.get('story_hybrid_mode')=='auto':
    from adstudio.hybrid import apply
    job['story_product_name']=p.get('product_name','');job['story_source_paths']=[p.get('source')]+[v.get('input_path') for v in p.get('media_segments',[])];apply(job)
   animation.store.save(job);return old
  except FileNotFoundError:pass
 job=animation.store.create(dict(name=p['name']+' · Story inserts',script=' '.join(s['text'] for s in slots),style='Natural phone footage, real ordinary people, consistent identities, everyday light, vertical 9:16; no beauty filter or baked captions.'))
 from adstudio.shot_direction import camera_shots,initial_frame
 preset=mode=='legacy' and p.get('story_cast_preset',True);scenes=[]
 for s in slots:
  scenes.append(dict(id='scene_'+s['id'],text=s['text'],duration=max(4,math.ceil(s['end']-s['start'])),insert_seconds=s['end']-s['start'],omitted_shots=s.get('omitted_shots',[]),visual=s['visual'],location='Use the setting stated in this scene; keep matching rooms consistent.',story_edit_style=p.get('story_edit_style','sparse'),image_prompt=initial_frame(s['visual'],anticipate=p.get('story_edit_style')=='reference'),video_prompt=camera_shots(s['visual'])[0],uses_product=bool(re.search(r'\bsculptique\b|product bottle',s['visual'],re.I)),uses_character=False,cast=scene_cast(s,preset),source='ai',status='pending',story_action_context=s['text'],story_slot=s['id'],story_signature=slot_signature(s)))
 if ai_cast:
  for scene in scenes:
   assignment=assigned[scene['story_slot']];scene.update(cast=assignment['cast'],uses_product=assignment['uses_product'],cast_reason=assignment['reason'],story_needs_character=assignment['needs_character'])
 job.update(story_review_required=p.get('story_edit_style')=='reference',story_context=p.get('story_brief_text') or p.get('original_script',''),local_clip_candidates=copy.deepcopy(p.get('assets',[])),scenes=scenes,roles=cast_preset() if preset else [],story_bridge=dict(editor_id=id,signature=signature,cast_preset=preset),story_workers=int(p.get('story_workers',2)),approved=False,review_scene_images=True,status='review',captions=False)
 if ai_cast:job['roles']=approved_roles
 job['story_bridge']['cast_mode']=mode
 if ai_cast:job['story_bridge']['approved_cast_signature']=character_signature(approved_roles);job['story_bridge']['assignment_signature']=p['cast_assignments']['signature'];job['story_bridge']['reference_signature']=workspace_reference_signature(reference_job or previous_job or {'roles':[]})
 # Carry approved cast/product and unchanged insert work into a changed batch.
 if previous_job and previous_job.get('story_bridge',{}).get('cast_preset',True)==preset:
  folder=animation.store.folder(job['id']);old_folder=animation.store.folder(previous_job['id'])
  def carry(source,subfolder):
   source=Path(source)
   if not source.is_file():return ''
   target=folder/subfolder/source.name;shutil.copy2(source,target);return str(target)
  if not ai_cast:job['roles']=copy.deepcopy(previous_job.get('roles',job['roles']))
  for role in ([] if ai_cast else job['roles']):
   for target in [role]+role.get('states',[]):
    if target.get('image_path'):
     target['image_path']=carry(target['image_path'],'assets')
     for key in ('ref_task','ref_url','ref_file'):target.pop(key,None)
  if previous_job.get('product_path'):job['product_path']=carry(previous_job['product_path'],'assets')
  if ai_cast:
   copy_references(previous_job,job,animation.store)
   if reference_job:copy_references(reference_job,job,animation.store)
  same_references=(not ai_cast or (character_signature(previous_job.get('roles',[]))==character_signature(job['roles']) and workspace_reference_signature(previous_job)==workspace_reference_signature(job)))
  previous={s.get('story_signature'):s for s in previous_job.get('scenes',[])}
  for scene in job['scenes']:
   prior=previous.get(scene['story_signature'])
   if not prior or not same_references or prior.get('cast',[])!=scene.get('cast',[]) or prior.get('uses_product')!=scene.get('uses_product'):continue
   for key in ('cast','image_prompt','video_prompt','uses_product','uses_character','visual','location','duration','shot_mode','source','broll_file','local_offset','generation_enabled','image_review','video_review','route_manual','hybrid_route'):
    if key in prior:scene[key]=copy.deepcopy(prior[key])
   for kind in ('image','video'):
    for suffix in ('task','url','approved','generation'):
     if kind+'_'+suffix in prior:scene[kind+'_'+suffix]=prior[kind+'_'+suffix]
    if prior.get(kind+'_file'):
     path=carry(old_folder/prior[kind+'_file'],'generated')
     if path:scene[kind+'_file']=str(Path(path).relative_to(folder))
  job['images_batch_complete']=all(s.get('image_file') for s in job['scenes'])
 if ai_cast and reference_job:copy_references(reference_job,job,animation.store)
 style_source=next((j for j in (reference_job,previous_job) if j and j.get('ugc_style_path')),None)
 if style_source:
  source=Path(style_source['ugc_style_path'])
  if source.is_file():
   dest=animation.store.folder(job['id'])/'assets'/('ugc_style'+source.suffix.lower())
   shutil.copy2(source,dest);job['ugc_style_path']=str(dest)
 if p.get('story_hybrid_mode')=='auto':
  from adstudio.hybrid import apply
  job['story_product_name']=p.get('product_name','');job['story_source_paths']=[p.get('source')]+[v.get('input_path') for v in p.get('media_segments',[])];apply(job)
 animation.store.save(job);p['story_generation']=dict(id=job['id'],signature=signature);studio.save(p);return p['story_generation']


def sync(studio,id,animation):
 studio.idle(id);p=studio.load(id);ref=p.get('story_generation',{});job=animation.store.load(ref.get('id',''))
 if job.get('story_bridge',{}).get('cast_mode')=='ai':
  from .cast import roles,character_signature,assignments_current,workspace_reference_signature
  if character_signature(roles(p))!=job['story_bridge'].get('approved_cast_signature') or not assignments_current(p) or p['cast_assignments']['signature']!=job['story_bridge'].get('assignment_signature'):raise ValueError('Approved cast or insert assignments changed. Prepare the updated generation batch before attaching clips.')
  if p.get('cast_workspace',{}).get('id'):
   try:references=animation.store.load(p['cast_workspace']['id'])
   except FileNotFoundError:references=None
   if references and workspace_reference_signature(references)!=job['story_bridge'].get('reference_signature'):raise ValueError('Character or product reference images changed. Prepare the updated generation batch before attaching clips.')
 if job.get('story_bridge',{}).get('editor_id')!=id:raise ValueError('This generation project belongs to another editor project.')
 if animation.studio.jobs.get(job['id']) and animation.studio.jobs[job['id']].is_alive():raise ValueError('Finish or pause generation before importing approved clips.')
 byid={s['id']:s for s in p.get('story_slots',[])};imported=0;pending=0
 from . import media
 for scene in job['scenes']:
  s=byid.get(scene.get('story_slot'))
  if not s or not s.get('enabled',True):continue
  if scene.get('story_signature')!=slot_signature(s):raise ValueError('An insert changed after generation planning. Prepare a new generation batch before importing; previous assets remain saved.')
  if scene.get('generation_enabled',True) is False:
   s.pop('path',None);s.pop('offset',None);pending+=1;continue
  if not scene.get('video_approved') or not scene.get('video_file'):pending+=1;continue
  path=(animation.store.folder(job['id'])/scene['video_file']).resolve()
  if animation.store.folder(job['id']) not in path.parents:raise ValueError('Invalid generated clip path.')
  need=s['end']-s['start'];available=media.duration(path)
  if available+.02<need:raise ValueError('Approved clip is shorter than its assigned story insert. Shorten the insert or regenerate.')
  s.update(path=str(path),offset=0,review=True);imported+=1
  asset=dict(id=s['id'],path=str(path),label=s['visual'],kind='ugc',tags=s['text'],person='lead',cleanliness='clean')
  p['assets']=[a for a in p['assets'] if a['id']!=asset['id']]+[asset]
 rebuild(p);p['story_sync_note']=f'{imported} approved clips attached; {pending} slots retain the presenter. Review insert timing in the storyboard before export.';studio.save(p);return p
