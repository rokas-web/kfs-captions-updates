"""Durable phrase edits on each exported recording's own clock."""
import copy, hashlib, json, math, re

def signature(p):
 return hashlib.sha256(json.dumps(dict(cues=p.get('cues',[]),duration=p.get('duration',0),original_script=p.get('original_script',''),segment_scripts=p.get('segment_scripts',{})),sort_keys=True).encode()).hexdigest()

def key(p):return p.get('_caption_edit_key','timeline')

def parse_time(value,fps=30):
 if fps not in (24,25,30,60):raise ValueError('Choose 24, 25, 30 or 60 fps for timecode input.')
 text=str(value).strip()
 if re.fullmatch(r'\d+:\d{2}:\d{2}:\d{2}',text):
  h,m,s,f=map(int,text.split(':'))
  if m>=60 or s>=60 or f>=fps:raise ValueError('Invalid timecode for the selected frame rate.')
  value=h*3600+m*60+s+f/fps
 else:
  try:value=float(text)
  except ValueError:raise ValueError('Use seconds or HH:MM:SS:FF timecode.')
 if not math.isfinite(value):raise ValueError('Enter a finite start time.')
 return round(value*30)/30

def apply(p,groups):
 edit=p.get('caption_phrase_edits',{}).get(key(p))
 if not edit:return groups
 if edit['signature']!=signature(p):
  raise ValueError('Speech changed after manual caption edits. Open Edit caption breaks and reset this version before exporting.')
 return copy.deepcopy(edit['groups'])

def retime(p,out,ranges=None):
 """Carry intentional edits through the export's verified silence map."""
 edit=p.get('caption_phrase_edits',{}).get(key(p))
 if not edit:return out
 if edit['signature']!=signature(p):raise ValueError('Speech changed after manual caption edits. Reset this version before exporting.')
 from .versions import retime_rows
 rows=retime_rows(edit['groups'],ranges,True) if ranges else copy.deepcopy(edit['groups'])
 out.setdefault('caption_phrase_edits',{})[key(p)]=dict(signature=signature(out),groups=rows)
 return out

def view(p,selected):
 if p.get('media_mode')=='completed':
  from .caption_batch import timeline
  item=next((s for s in p.get('media_segments',[]) if s['id']==selected),None)
  if not item:raise ValueError('Choose an imported completed video.')
  return timeline(p,item)
 if selected!='timeline':
  from .caption_only import reviews
  from .versions import retime_rows
  hook=next((h for h in p.get('hooks',[]) if h['id']==selected),None)
  if not hook or not p.get('body_range'):raise ValueError('Choose a caption version.')
  body=p['body_range'];ranges=[(hook['start'],hook['end']),(body['start'],body['end'])]
  q=copy.deepcopy(p);q['duration']=sum(b-a for a,b in ranges)
  q['cues']=retime_rows(p['cues'],ranges,True);q['scenes']=retime_rows(p.get('scenes',[]),ranges)
  q['hooks']=[{**hook,'start':0,'end':hook['end']-hook['start']}]
  q['media_segments']=[dict(kind='hook',start=0,end=q['hooks'][0]['end']),dict(kind='body',start=q['hooks'][0]['end'],end=q['duration'])]
  q['_caption_edit_key']=selected
  return q
 return copy.deepcopy(p)

def versions(p):
 if p.get('media_mode')=='completed':return [dict(id=s['id'],name=s['name']) for s in p.get('media_segments',[])]
 if p.get('media_mode')=='hooks' and p.get('variant_mode')=='per_hook':return [dict(id=h['id'],name=h['name']) for h in p.get('hooks',[])]
 return [dict(id='timeline',name='Current timeline')]

def action(studio,id,data):
 studio.idle(id);p=studio.load(id);selected=data.get('version','timeline');q=view(p,selected)
 op=data.get('operation','review')
 if op=='reset':
  p.setdefault('caption_phrase_edits',{}).pop(selected,None);q=view(p,selected)
 from .caption_timeline import prepare
 groups=copy.deepcopy(prepare(q).get('_caption_flow_groups',[]))
 if op not in ('review','reset'):
  index=data.get('index')
  if type(index)!=int or not 0<=index<len(groups):raise ValueError('Choose a caption phrase.')
  row=groups[index]
  if op=='split':
   at=data.get('word')
   if type(at)!=int or not 0<at<len(row['words']):raise ValueError('Choose a word inside this phrase.')
   t=parse_time(data.get('start',row['words'][at]['start']),int(data.get('fps',30)))
   if not row['start']<t<row['end']:raise ValueError('The split time must fall inside this phrase.')
   left={**row,'words':row['words'][:at],'end':t};right={**row,'words':row['words'][at:],'start':t}
   left.pop('line_break',None);right.pop('line_break',None);groups[index:index+1]=[left,right]
  elif op=='merge':
   if index+1>=len(groups):raise ValueError('There is no following phrase to merge.')
   nxt=groups.pop(index+1);row['words']+=nxt['words'];row['end']=nxt['end'];row.pop('line_break',None)
  elif op=='start':
   t=parse_time(data.get('start'),int(data.get('fps',30)))
   if index==0:
    if not 0<=t<row['end']:raise ValueError('The first caption must start inside the video.')
   elif not groups[index-1]['start']<t<row['end']:raise ValueError('Start must fall after the previous phrase starts and before this phrase ends.')
   if index:groups[index-1]['end']=t
   row['start']=t
  elif op=='line':
   at=data.get('word',0)
   if type(at)!=int or not 0<=at<len(row['words']):raise ValueError('Choose a line break inside this phrase.')
   row['line_break']=at
  else:raise ValueError('Choose split, merge, start, line or reset.')
  from .captions import clean_text
  for row in groups:row['text']=clean_text(' '.join(w['text'] for w in row['words']))
  p.setdefault('caption_phrase_edits',{})[selected]=dict(signature=signature(q),groups=groups)
 if op!='review':
  for field in ('preview_file','render_file','exports','package_file','saved_package_file'):p.pop(field,None)
  from .caption_timeline import ENGINE
  report=dict(engine=ENGINE,duration=q['duration'],groups=[dict(start=g['start'],end=g['end'],text=g['text']) for g in groups])
  label=next(v['name'] for v in versions(p) if v['id']==selected)
  p['caption_reviews']=[v for v in p.get('caption_reviews',[]) if v['id']!=selected]+[dict(id=selected,name=label,report=report)]
  if selected=='timeline':p['caption_review']=report
  studio.save(p)
 return dict(project=p,versions=versions(p),version=selected,groups=[dict(start=g['start'],end=g['end'],text=g['text'],words=[w['text'] for w in g['words']],word_starts=[w['start'] for w in g['words']],line_break=g.get('line_break',0)) for g in groups])
