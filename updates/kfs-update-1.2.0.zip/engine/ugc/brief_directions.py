"""Recognize explicit editorial lines without guessing away spoken sentences."""
import re

LABEL=re.compile(r'^\s*(?:LEFT|RIGHT|VISUAL(?:S)?|B[- ]?ROLL|CAMERA|ON[- ]SCREEN(?:\s+TEXT)?|TEXT\s+ON\s+TOP|SCREEN\s+TEXT)\s*:',re.I)
HOOK_NOTE=re.compile(r"^\s*(?:on|for|in)\s+(?:the\s+)?(?:[1-9][0-9]*(?:st|nd|rd|th)?|first|second|third|fourth|fifth)\s+hook\b.*?\b(?:let['’]s|please|put|show|add|use|make)\b",re.I)
VOICE=re.compile(r'^\s*(?:VO|V\.?O\.?|VOICEOVER|VOICE[- ]OVER|NARRATION)\s*:\s*',re.I)

def mark_directions(raw):
 """Reuse balanced-note parsing, preserving visual prose in directions metadata.

 Only labelled visual paragraphs and explicit hook editing requests are notes.
 Unlabelled prose remains narration, including script passages missing in audio.
 """
 lines=[];depth=0
 for line in raw.splitlines():
  if not depth and (LABEL.match(line) or HOOK_NOTE.match(line)):
   lines.append('['+line.strip()+']')
  elif not depth:lines.append(VOICE.sub('',line))
  else:lines.append(line)
  depth+=line.count('[')-line.count(']')
 return '\n'.join(lines)
