"""Local English syntax, mapped onto measured words without rewriting them."""
import sys, threading, re
from bisect import bisect_right
from functools import lru_cache
from pathlib import Path

BASE=Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parents[1]))
LOCK=threading.RLock()

@lru_cache(maxsize=1)
def pipeline():
 try:
  import spacy
  return spacy.load(BASE/'caption_model'/'en_core_web_sm',exclude=['lemmatizer'])
 except (ImportError,OSError,ValueError) as exc:
  raise RuntimeError('The local caption language engine is missing. Close Premiere and run INSTALL_MAC.command from this version, then launch it again. No API key is needed.') from exc

@lru_cache(maxsize=512)
def edges(raw):
 """Return protected boundaries and useful phrase starts in word indices."""
 starts=[];cursor=0
 for word in raw:starts.append(cursor);cursor+=len(word)+1
 with LOCK:doc=pipeline()(' '.join(raw))
 owner=lambda t:max(0,min(len(raw)-1,bisect_right(starts,t.idx)-1))
 protected=set();preferred={}
 def protect(first,last):
  a,b=owner(first),owner(last)
  if b-a<12:protected.update(range(a+1,b+1))
 for chunk in doc.noun_chunks:protect(chunk[0],chunk[-1])
 nominal_heads={t.head.i for t in doc if t.dep_=='compound' and t.head.dep_ in {'dobj','pobj','attr','nsubj','nsubjpass'} and t.head.pos_=='VERB'}
 for i in range(len(raw)-1):
  # ASR sometimes emits U + .S. as separate tokens. Initials are one unit.
  if all(re.fullmatch(r'[A-Z]',re.sub(r'[^A-Za-z]','',part)) for part in raw[i:i+2]):protected.add(i+1)
 # Discount amounts and their particle are one unit, including ASR's
 # alternate "70 percent off" spelling. The particle must not lead "off sale".
 normalized=[str(part).lower().strip(' ,.!?;:"“”') for part in raw]
 for i,value in enumerate(normalized):
  end=i
  if re.fullmatch(r'\d+(?:[.,]\d+)?%',value):pass
  elif re.fullmatch(r'\d+(?:[.,]\d+)?',value) and i+1<len(raw) and normalized[i+1] in {'percent','percentage'}:end=i+1
  else:continue
  if end+1<len(raw) and normalized[end+1]=='off':
   end+=1
   if end+1<len(raw) and normalized[end+1] in {'sale','deal','offer','discount'}:end+=1
   protected.update(range(i+1,end+1))
 # Numbered classifications belong to the noun they qualify. The small
 # parser can attach "stage" to a preposition but parse "3 kidney disease"
 # as a separate object. Repair this syntactic span before considering
 # short verb/preposition complements, rather than memorizing diagnoses.
 unit_ends={}
 labels={'stage','grade','type','class','phase','level'}
 number=lambda t:t.pos_=='NUM' or bool(re.fullmatch(r'\d+[a-zA-Z]?',t.text)) or t.text in {'I','II','III','IV','V','VI','VII','VIII','IX','X'}
 for t in doc:
  if t.lower_ not in labels or t.i+1>=len(doc) or not number(doc[t.i+1]):continue
  last=t.i+1
  if last+2<len(doc) and doc[last+1].lower_ in {'and','to','through','-','–'} and number(doc[last+2]):last+=2
  while last+1<len(doc) and doc[last+1].pos_ in {'NOUN','PROPN','ADJ'} and owner(doc[last+1])-owner(t)<7:last+=1
  unit_ends[owner(t)]=doc[last]
  protect(t,doc[last])
  if t.i and doc[t.i-1].pos_=='ADP':protect(doc[t.i-1],doc[last])
 # Common particles can be mis-tagged in dates and advertising copy.
 pairs={('set','aside'),('got','hold'),('get','hold'),('gets','hold'),('pulled','off'),('hooked','on'),('wake','up'),('work','out'),('paid','off'),('take','care'),('took','care')}
 for a,b in zip(doc,doc[1:]):
  if (a.text.casefold(),b.text.casefold()) in pairs:protect(a,b)
  # A trailing particle belongs to its phrase, even when the parser tags
  # "head up" as an adverb rather than a phrasal verb.
  if b.text.casefold() in {'up','out','off','away','back','down'} and b.dep_ in {'prt','advmod'}:protect(a,b)
  # Stranded prepositions close the preceding clause: "left me for, who".
  if a.pos_=='ADP' and b.text.casefold() in {'who','which','that'} and a.i:
   protect(doc[a.i-1],a)
 # Keep named entities, dates and amounts together (including 1950s and '60s).
 for ent in doc.ents:protect(ent[0],ent[-1])
 for t in doc:
  i=owner(t)
  if t.pos_=='ADP':preferred[i]=-3.
  if t.pos_=='VERB' and t.i not in nominal_heads:preferred[i]=min(preferred.get(i,0),-2.)
  if t.dep_ in {'nsubj','nsubjpass'} and t.pos_ in {'NOUN','PRON'} and t.head.pos_=='VERB':
   last=max((x for x in t.subtree if x.idx<t.head.idx),key=lambda x:x.idx,default=t)
   first=min(t.subtree,key=lambda x:x.idx)
   if owner(last)-owner(first)>=2:preferred[owner(last)+1]=-9.
  if t.dep_=='npadvmod':
   first=min(t.subtree,key=lambda x:x.idx)
   preferred[owner(first)]=-6.
  if t.pos_=='AUX':preferred[i]=-3.
  # A short noun subject needs its predicate: "your doctor is already
  # talking", rather than a card ending at the subject. Pronoun subjects
  # and long subjects retain the existing, more flexible rules below.
  if t.dep_ in {'nsubj','nsubjpass'} and t.pos_ in {'NOUN','PROPN'} and t.head.pos_ in {'VERB','AUX'}:
   first=min(t.subtree,key=lambda x:x.idx)
   if 0<owner(t.head)-owner(first)<=5:protect(first,t.head)
  # A sentence-final adverb completes the preceding phrase even when its
  # grammatical head is an earlier auxiliary: "on dialysis yet". A scene
  # cut inside that unit must hold the full phrase instead of stranding it.
  if t.dep_=='advmod' and t.head.pos_ in {'VERB','AUX'} and t.i and (t.i+1==len(doc) or doc[t.i+1].text in {'.','!','?'}):
   before=doc[t.i-1]
   if not before.is_punct and owner(t)-owner(before)<=1:protect(before,t)
  if t.dep_ in {'nsubj','nsubjpass'} and t.pos_=='PRON' and i and t.head.dep_ in {'ROOT','conj'} and t.head.pos_ in {'VERB','AUX'} and doc[t.i-1].pos_ not in {'SCONJ','CCONJ','ADP'}:
   preferred[i]=min(preferred.get(i,0),-8.)
  # In "the answers your doctor didn't have", the relative clause's noun
  # subject belongs with its verb rather than dangling on the prior caption.
  if t.dep_ in {'nsubj','nsubjpass'} and t.pos_ in {'NOUN','PROPN'} and t.head.dep_=='relcl':
   first=min(t.subtree,key=lambda x:x.idx)
   if 0<owner(t.head)-owner(first)<=5:protect(first,t.head)
  if t.dep_ in {'nsubj','nsubjpass'} and t.text.casefold() in {'i','we','you','he','she','it','they'} and 0<owner(t.head)-i<=4:protect(t,t.head)
  if t.dep_=='advmod' and t.head.pos_=='VERB' and abs(owner(t.head)-i)==1:
   a,b=sorted((t,t.head),key=lambda x:x.idx);protect(a,b)
  # Short verb complements form one useful phrase: sit in your pharmacy.
  if t.dep_=='prep' and t.head.pos_=='VERB' and 0<i-owner(t.head)<=2:
   objects=[c for c in t.children if c.dep_=='pobj']
   if objects:
    last=max([*objects[0].subtree,unit_ends.get(owner(objects[0]),objects[0])],key=lambda x:x.idx)
    if not (t.lower_=='with' and owner(objects[0]) in unit_ends) and 0<owner(last)-owner(t.head)<=4:protect(t.head,last)
   elif not any(c.dep_=='pcomp' for c in t.children) and t.i+1<len(doc) and doc[t.i+1].lower_ in {'not','but','and'}:
    protect(t.head,t)
    # A completed stranded preposition can end its phrase: "act on / not
    # serious enough to panic". -16 also certifies this otherwise weak edge.
    preferred[i+1]=min(preferred.get(i+1,0),-16.)
  # Keep a preposition with its nominal object. This also covers less common
  # prepositions, rather than allowing "sliding towards / stage 4 and 5".
  if t.pos_=='ADP':
   objects=[c for c in t.children if c.dep_=='pobj']
   if objects:
    last=max([objects[0],unit_ends.get(owner(objects[0]),objects[0])],key=lambda x:x.idx)
    if 0<owner(last)-i<=7:protect(t,last)
  # Dependency relations still identify compounds when a nominal object is
  # mistagged as a verb, e.g. "the root cause" in a longer relative clause.
  if t.dep_=='compound' and t.head.dep_ in {'dobj','pobj','attr','nsubj','nsubjpass'} and 0<owner(t.head)-i<=4:
   first=min(t.subtree,key=lambda x:x.idx);protect(first,t.head)
  # A short contrast is one thought: "not just the numbers". Its opening
  # is a useful break after the preceding complete phrase, even without
  # a correctly transcribed dash or comma.
  if t.lower_=='not' and t.i+2<len(doc) and doc[t.i+1].lower_ in {'just','only'}:
   last=t.i+1
   while last+1<len(doc) and doc[last+1].pos_ in {'DET','PRON','ADJ','NOUN','PROPN','NUM'} and owner(doc[last+1])-i<=6:last+=1
   if last>t.i+1:protect(t,doc[last]);preferred[i]=min(preferred.get(i,0),-8.)
  # Partitives are noun phrases too: none of those pills / millions of women.
  if t.text.casefold()=='of' and t.head.pos_ in {'NOUN','PRON','NUM'} and i==owner(t.head)+1:
   objects=[c for c in t.children if c.dep_=='pobj']
   if objects and (t.head.text.casefold() in {'none','some','all','one','millions','billions','most','many','lots','lot'} or t.head.pos_ in {'PRON','NUM'}):
    last=max(objects[0].subtree,key=lambda x:x.idx)
    if owner(last)-owner(t.head)<=7:
     first=min((c for c in t.head.subtree if c.idx<=t.head.idx),key=lambda x:x.idx)
     protect(first,last)
  if t.dep_ in {'aux','auxpass','neg','prt'} and abs(owner(t.head)-i)<=4:
   if not (t.dep_=='neg' and t.head.i in nominal_heads and t.idx>t.head.idx):
    a,b=sorted((t,t.head),key=lambda x:x.idx);protect(a,b)
  if t.dep_=='prt' and t.head.pos_=='VERB' and t.i+1<len(doc) and doc[t.i+1].pos_ in {'SCONJ','CCONJ'}:
   preferred[i+1]=min(preferred.get(i+1,0),-16.)
  # Compound verbs and particles must not become 'set / aside' or 'kept / growing'.
  if t.dep_=='xcomp' and t.head.pos_=='VERB' and abs(owner(t.head)-i)==1:
   # 'I started / using this product' is a useful cadence in the SOP.
   if t.head.lemma_ not in {'start','begin'} or t.text.casefold() in {'dying','growing'}:
    a,b=sorted((t,t.head),key=lambda x:x.idx);protect(a,b)
  if t.dep_ in {'acomp','attr'} and t.head.pos_=='AUX' and abs(owner(t.head)-i)<=2:
   a,b=sorted((t,t.head),key=lambda x:x.idx);protect(a,b)
  if t.dep_ in {'dobj','dative'} and t.pos_=='PRON' and abs(owner(t.head)-i)==1:
   a,b=sorted((t,t.head),key=lambda x:x.idx);protect(a,b)
  # A short nominal object completes its verb: reach the lymph / flatten
  # that belly. Shot matching must not treat the edge after the verb as
  # grammatical merely because the noun chunk itself remains intact.
  if t.dep_=='dobj' and (t.pos_ in {'NOUN','PROPN'} or t.i in nominal_heads) and t.head.pos_=='VERB':
   last=max(t.subtree,key=lambda x:x.idx)
   coordinated=any(c.dep_=='conj' and c.pos_ in {'NOUN','PROPN','PRON'} for c in t.children)
   if 0<owner(last)-owner(t.head)<=(5 if coordinated else 3):protect(t.head,last)
  # Short coordinated objects form a single unit: salt and protein,
  # the pressure and the sugar. Do not combine independent "but" clauses
  # when the small language model mistags the next verb as a noun.
  if t.dep_=='conj' and t.pos_ in {'NOUN','PROPN','PRON'} and t.head.pos_ in {'NOUN','PROPN','PRON'}:
   between=list(doc[t.head.i+1:t.i])
   if 0<owner(t)-owner(t.head)<=5 and any(x.lower_ in {'and','or'} for x in between) and not any(x.lower_ in {'but','because','while'} or x.text in {'.','!','?',';'} for x in between):protect(t.head,t)
  # Keep short defining clauses with their noun: every diet you've ever
  # tried / the one thing I built. Longer explanations still allow breaks.
  if t.dep_=='relcl' and t.head.pos_ in {'NOUN','PROPN'}:
   last=max(t.subtree,key=lambda x:x.idx)
   if 0<owner(last)-owner(t.head)<=6:protect(t.head,last)
 from .caption_numbers import boundaries as number_boundaries
 protected.update(number_boundaries(raw))
 return frozenset(protected),tuple(sorted(preferred.items()))

def boundaries(words):
 return edges(tuple(str(w.get('raw',w['text'])).replace('’',"'") for w in words))
