"""Use the user's installed Proxima Nova; never redistribute commercial fonts."""
import os
from pathlib import Path
from functools import lru_cache
from PIL import ImageFont

def _sfnt(path):
 try:
  with open(path,'rb') as f:return f.read(4) in (b'OTTO',b'\x00\x01\x00\x00',b'true')
 except OSError:return False

def caption_copy_name(path):
 path=Path(path);name='caption-'+path.name.lstrip('.')
 if path.suffix.lower() in ('.ttf','.otf'):return name
 try:
  with open(path,'rb') as f:return name+('.otf' if f.read(4)==b'OTTO' else '.ttf')
 except OSError:return name+'.otf'

@lru_cache(maxsize=8)
def proxima_font(base,weight=None):
 roots=[Path(base)/'fonts',Path(os.environ.get('LOCALAPPDATA',''))/'Microsoft/Windows/Fonts',Path(os.environ.get('WINDIR','C:/Windows'))/'Fonts',Path.home()/'Library/Fonts',Path('/Library/Fonts'),Path('/System/Library/Fonts/Supplemental')]
 candidates=[]
 adobes=[Path.home()/'Library/Application Support/Adobe/CoreSync/plugins/livetype']+([Path(os.environ['APPDATA'])/'Adobe/CoreSync/plugins/livetype'] if os.environ.get('APPDATA') else [])
 def files():
  for root in roots:
   if not root.is_dir():continue
   for path in root.rglob('*'):
    if path.suffix.lower() in ('.ttf','.otf') and 'proxima' in path.name.lower():yield path
  for adobe in adobes:
   if not adobe.is_dir():continue
   for path in adobe.rglob('*'):
    if path.suffix.lower() in ('.ttf','.otf') or (path.suffix=='' and _sfnt(path)):yield path
 for path in files():
  if True:
   try:
    family,weight_name=ImageFont.truetype(str(path),32).getname()
    if 'proxima' not in family.lower():continue
    desc=(family+' '+weight_name).lower()
    score=(0 if weight and weight.lower()==weight_name.lower() else 10 if weight else 0)+(0 if 'semibold' in desc or 'semi bold' in desc else 1 if 'bold' in desc else 2)+(20 if 'it' in weight_name.lower().split() or 'italic' in weight_name.lower() else 0)
    candidates.append((score,str(path),path))
   except (OSError,ValueError):continue
 if candidates:return min(candidates)[2]
 return Path(base)/'fonts/Montserrat-Bold.ttf'

def font_description(base):
 from . import captions as _c
 path=proxima_font(base,getattr(_c,'PROXIMA_WEIGHT','') or None);family,weight=ImageFont.truetype(str(path),32).getname()
 return family+' '+weight+(' (fallback: install Proxima Nova and restart)' if 'proxima' not in family.lower() else '')

def copy_caption_font(project,base,destination):
 from .captions import PRESETS
 if PRESETS.get(project.get('caption'),{}).get('file')!='@proxima':return
 import shutil
 source=proxima_font(base);target=Path(destination)/caption_copy_name(source)
 if source.resolve()!=target.resolve():shutil.copy2(source,target)
