"""A hook is one headline interval, even after export-only pause removal."""
import copy
FPS=30

def mode(value):
 # The old opening-scene default is superseded by hook-only display.
 return 'video' if value=='video' else 'hook'

def retime_hooks(hooks,ranges):
 from .versions import retime_rows
 result=[]
 for hook in hooks:
  parts=retime_rows([hook],ranges)
  if parts:result.append({**parts[0],'end':parts[-1]['end']})
 return sorted(result,key=lambda h:h['start'])

def intervals(p):
 """Half-open frame ranges shared by libass and Premiere overlays."""
 hooks=[]
 for original in sorted(p.get('hooks',[]),key=lambda h:h['start']):
  h=copy.deepcopy(original)
  if float(h['end'])<=float(h['start']):continue
  prev=hooks[-1] if hooks else None
  # Also accept old, already-fragmented export timelines. Never join distinct
  # hook IDs, differing titles, or an actual gap between independent hooks.
  keys=('id','name','headline','enabled','emphasis','input_path')
  if prev and all(prev.get(k)==h.get(k) for k in keys) and abs(prev['end']-h['start'])<1e-7:
   prev['end']=h['end']
  else:hooks.append(h)
 total=round(float(p.get('duration') or max((h['end'] for h in hooks),default=0))*FPS)
 for i,h in enumerate(hooks):
  if not h.get('enabled',True) or not str(h.get('headline','')).strip():continue
  start=max(0,min(total,round(float(h['start'])*FPS)))
  end=round(float(h['end'])*FPS)
  if mode(p.get('headline_duration'))=='video':
   end=round(float(hooks[i+1]['start'])*FPS) if i+1<len(hooks) else total
  else:
   body=p.get('body_range') or {}
   if float(body.get('start',-1))>=float(h['start']):end=min(end,round(float(body['start'])*FPS))
   for segment in p.get('media_segments',[]):
    if segment.get('kind')=='body' and float(segment['start'])>=float(h['start']):
     end=min(end,round(float(segment['start'])*FPS))
  end=max(0,min(total,end))
  if end>start:yield h,start/FPS,end/FPS

