"""AI provider features are not part of Kandy For Scale Captions (no network access)."""
class OpenAIClient:
 def __init__(self,*a,**k):raise ValueError("AI features are not available in Kandy For Scale Captions.")
