"""Only-captions workflow inside the original UGC Studio."""
import copy,hashlib,json,re,sys
from pathlib import Path
from .core import atomic,word_units,VIDEO
from . import media
BASE=Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parents[1]))

def attach_scripts(p,remap_invalid=False):
 brief=p.get('caption_brief')
 if not brief:return
 if p.get('media_mode')=='completed' and p.get('media_segments'):
  from .caption_batch import attach_scripts as attach_batch
  attach_batch(p,remap_invalid=remap_invalid);return
 from .montage_brief import all_speech,selection
 pieces=p.get('media_segments',[])
 if not pieces:
  chosen=p.get('caption_brief_hook') or (brief['hooks'] or ['BODY' if 'BODY' in brief['sections'] else 'SINGLE'])[0]
  p['caption_brief_hook']=chosen;p['original_script']=selection(brief,chosen);return
 hooks=[s for s in pieces if s['kind']=='hook'];body=[s for s in pieces if s['kind']=='body']
 if len(hooks)!=len(brief['hooks']) or len(body)!=1:raise ValueError('Choose one file per brief hook in H1/H2 order and one shared BODY.')
 p['segment_scripts']={piece['id']:brief['sections'][key]['spoken'] for piece,key in zip(hooks,brief['hooks'])}
 p['segment_scripts'][body[0]['id']]=brief['sections']['BODY']['spoken'];p['original_script']=all_speech(brief)
 for piece,key in zip(hooks,brief['hooks']):
  piece['name']=key
  for hook in p['hooks']:
   if hook['id']==piece['id']:hook['name']=key
 body[0]['name']='BODY'

def import_brief(studio,id,data):
 from .montage_brief import parse
 p=studio.load(id)
 if 'text' in data:
  p['caption_brief']=parse(data['text'],data.get('input_mode','brief'),data.get('hook_count'));p['caption_brief_text']=data['text']
 choices=p['caption_brief']['hooks'] or ['BODY' if 'BODY' in p['caption_brief']['sections'] else 'SINGLE']
 if data.get('hook'):
  if data['hook'] not in choices:raise ValueError('Choose a hook from this brief.')
  p['caption_brief_hook']=data['hook']
 elif p.get('caption_brief_hook') not in choices:p['caption_brief_hook']=choices[0]
 attach_scripts(p,remap_invalid='text' in data);p.pop('script_alignment',None);p['needs_rebuild']=bool(p.get('scenes'))
 for key in ('preview_file','render_file','exports','package_file','caption_review','caption_reviews','caption_ready_signature'):p.pop(key,None)
 studio.save(p);return p

def cut_key(path):
 path=Path(path);stat=path.stat()
 return hashlib.sha256(json.dumps([str(path.resolve()),stat.st_size,stat.st_mtime_ns]).encode()).hexdigest()[:20]

def cuts_for(studio,id,path,stop,update):
 key=cut_key(path);p=studio.load(id)
 if key in p.get('caption_cut_overrides',{}):return p['caption_cut_overrides'][key]
 cache=studio.folder(id)/'caption_cuts';cache.mkdir(exist_ok=True);dest=cache/(key+'_frames_v4.json')
 if dest.is_file():return json.loads(dest.read_text())
 update('Checking scene cuts in '+Path(path).name,15)
 output=media.run(['ffmpeg','-hide_banner','-i',path,'-an','-vf',"scale=320:-2,fps=30,select='gt(scene,0.18)',metadata=mode=print:key=lavfi.scene_score,showinfo",'-fps_mode','vfr','-f','null','-'],stop,update=update,label='Checking scene cuts in '+Path(path).name)
 scores=[(round(float(t)*30)/30,float(score)) for t,score in re.findall(r'Parsed_metadata[^\n]*pts_time:([\d.]+)\s*\n[^\n]*lavfi.scene_score=([\d.]+)',output)]
 clusters=[]
 for record in scores:
  if not clusters or record[0]-clusters[-1][-1][0]>.4:clusters.append([])
  clusters[-1].append(record)
 # Continuous movement in animations can trigger a burst of low scores.
 # It is one moving shot, not a sequence of two-frame picture edits.
 cuts=sorted({max(cluster,key=lambda item:item[1])[0] for cluster in clusters if len(cluster)<3 or max(score for _,score in cluster)>=.35})
 atomic(dest,cuts);return cuts

def save_cuts(studio,id,data):
 studio.idle(id);p=studio.load(id);key=data.get('key','')
 item=next((x for x in p.get('caption_inputs',[]) if x['key']==key),None)
 if not item:raise ValueError('Choose an imported video from the scene-cut review.')
 values=data.get('cuts')
 if not isinstance(values,list):raise ValueError('Enter scene cut times in seconds.')
 cuts=sorted(set(round(float(x)*30)/30 for x in values))
 if any(not 0<x<item['duration'] for x in cuts):raise ValueError('Cuts must fall inside this recording.')
 p.setdefault('caption_cut_overrides',{})[key]=cuts;p['needs_rebuild']=True
 for key in ('preview_file','render_file','exports','package_file','caption_review','caption_reviews','caption_ready_signature'):p.pop(key,None)
 studio.save(p);return p

def plan(studio,id,stop,update):
 p=studio.load(id)
 if not p.get('source') or not p.get('cues'):raise ValueError('Import media, then match speech or import SRT first.')
 pieces=p.get('media_segments') or [dict(id='single',kind='single',input_path=p['source'],start=0,end=p['duration'],name='Recording')]
 scenes=[];inputs=[];words=word_units(p['cues'])
 for n,piece in enumerate(pieces):
  if stop.is_set():raise InterruptedError('Cancelled')
  path=Path(piece['input_path']);info=media.probe(path);video=any(s['codec_type']=='video' for s in info['streams'])
  natural=p.get('caption_cut_policy','shot')=='continuous'
  length=piece['end']-piece['start'];cuts=cuts_for(studio,id,path,stop,update) if video and not natural else []
  cuts=[x for x in cuts if 0<x<length]
  continuous=natural or p.get('media_mode')=='completed' and p.get('caption_cut_policy','shot')!='strict'
  # Finished recordings have embedded edits which the owner cannot move.
  # Keep footage intact; the caption clock handles its embedded shot changes.
  edges=[0.]+([] if continuous else cuts)+[length]
  if video:
   vs=next(s for s in info['streams'] if s['codec_type']=='video')
   if n==0 and not p.get('caption_format_manual'):p['montage_format']='16:9' if vs['width']>vs['height'] else '9:16'
  inputs.append(dict(key=cut_key(path),name=piece.get('name',path.stem),path=str(path),duration=length,cuts=cuts,video=video))
  for j,(a,b) in enumerate(zip(edges,edges[1:])):
   start=piece['start']+a;end=piece['start']+b
   scenes.append(dict(id=hashlib.sha256(f'{piece["id"]}:{a}:{b}'.encode()).hexdigest()[:12],start=start,end=end,
    path=str(path) if video else str(BASE/'assets'/'caption_black.png'),offset=a if video else 0,
    kind='presenter' if video else 'caption_background',motion='none',review=False,reason='Original recording; captions only',
    text=' '.join(w['text'] for w in words if start<=w['start']<end)))
 p.update(scenes=scenes,caption_inputs=inputs,needs_rebuild=True,planner_version=8,caption_flow='connected')
 p['caption_scene_cuts']=sorted({piece['start']+t for piece,item in zip(pieces,inputs) for t in item['cuts']}) if p.get('caption_cut_policy','shot')=='shot' else []
 # Save cut evidence even when a phrase conflicts, so it can be reviewed.
 for key in ('caption_review','caption_reviews','caption_ready_signature'):p.pop(key,None)
 studio.save(p)
 from .caption_timeline import CaptionCutConflict
 measured=[w for c in p['cues'] for w in c.get('words',[]) if not c.get('pacing_words_estimated')]
 for scene in scenes[1:] if p.get('caption_cut_policy')=='strict' else ():
  cut=scene['start']
  crossing=next((w for w in measured if w['start']+.025<cut<w['end']-.025),None)
  if crossing:raise CaptionCutConflict(f'Visual cut at {cut:.2f}s crosses the spoken word {crossing["text"]}. Review this cut before exporting.')
 from .caption_timeline import prepare,report,fingerprint,ENGINE
 if p.get('media_mode')=='completed':
  p['caption_reviews']=reviews(p)
  starts={s['id']:s['start'] for s in pieces}
  combined=[{**g,'start':g['start']+starts[v['id']],'end':g['end']+starts[v['id']]} for v in p['caption_reviews'] for g in v['report']['groups']]
  p['caption_review']=dict(engine=ENGINE,duration=p['duration'],groups=combined)
  p['caption_ready_signature']=fingerprint(p)
 else:
  prepared=prepare(p);p['caption_review']=report(prepared)
  p['caption_ready_signature']=prepared.get('_caption_flow_signature','none')
  p['caption_reviews']=reviews(p)
 p.pop('caption_reviews_stale',None)
 p['needs_rebuild']=False
 for key in ('preview_file','render_file','exports','package_file'):p.pop(key,None)
 studio.save(p);update('Captions ready to review',100);return p


def reviews(p):
 if p.get('media_mode')=='completed':
  from .caption_batch import reviews as batch_reviews
  return batch_reviews(p)
 from .caption_timeline import report
 from .versions import retime_rows
 body=p.get('body_range')
 if p.get('variant_mode')!='per_hook' or not body:return [dict(id='timeline',name='Current timeline',report=report(p))]
 out=[]
 for hook in p.get('hooks',[]):
  ranges=[(hook['start'],hook['end']),(body['start'],body['end'])]
  q=copy.deepcopy(p);q['_caption_edit_key']=hook['id'];q['duration']=sum(b-a for a,b in ranges)
  q['scenes']=retime_rows(p['scenes'],ranges);q['cues']=retime_rows(p['cues'],ranges,True)
  q['hooks']=[{**hook,'start':0,'end':hook['end']-hook['start']}]
  q['media_segments']=[dict(kind='hook',start=0,end=q['hooks'][0]['end']),dict(kind='body',start=q['hooks'][0]['end'],end=q['duration'])]
  out.append(dict(id=hook['id'],name=hook['name'],report=report(q)))
 return out
