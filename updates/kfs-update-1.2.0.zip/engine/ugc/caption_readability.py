"""Repair short speech fragments without moving or inventing spoken words."""
import copy,re
from .caption_phrases import WEAK,token

def compact(word):return re.sub('[^a-z]','',token(word))

def repair(p,rows):
 from .captions import clean_text
 from .caption_timeline import audio_context_edges
 rows=copy.deepcopy(rows);hard=audio_context_edges(p)
 def can_join(left,right):
  boundary=right['words'][0]['start']
  return (not any(left['start']+1e-7<t<=boundary+1e-7 for t in hard)
          and len(left['words'])+len(right['words'])<=10)
 def join(index):
  left,right=rows[index:index+2]
  left['words'].extend(right['words']);left['end']=right['end']
  left['text']=clean_text(' '.join(w['text'] for w in left['words']))
  left['readability_merged']=True;rows.pop(index+1)
 # A named choice and its short answer are one readable unit: Salmon? Do!
 i=0
 while i+1<len(rows):
  left,right=rows[i:i+2];gap=right['words'][0]['start']-left['words'][-1]['end']
  first=right['words'][0]
  answer=compact(first) in {'do','dont','yes','no'} and (len(right['words'])==1 or re.search(r'[.!?]["”]*$',first.get('raw','')))
  question=len(left['words'])<=4 and re.search(r'\?["”]*$',left['words'][-1].get('raw',''))
  if answer and question and gap<=1.6:
   if len(right['words'])>1:
    boundary=round(right['words'][1]['start']*30)/30
    head={**copy.deepcopy(right),'words':copy.deepcopy(right['words'][:1]),'end':boundary,'text':clean_text(first['text'])}
    tail={**copy.deepcopy(right),'words':copy.deepcopy(right['words'][1:]),'start':boundary,'text':clean_text(' '.join(w['text'] for w in right['words'][1:]))}
    if can_join(left,head):rows[i+1:i+2]=[head,tail];join(i)
   elif can_join(left,right):join(i)
  i+=1
 # A function word is not a meaningful caption on its own. Keep it with
 # the following clause even if an imported transcript row ends there.
 i=0
 while i+1<len(rows):
  left,right=rows[i:i+2];word=left['words'][0]
  gap=right['words'][0]['start']-left['words'][-1]['end']
  weak=len(left['words'])==1 and token(word) in WEAK|{'do','does','did','can','will','would','should','could','must'}
  if weak and gap<=.8 and can_join(left,right):join(i);continue
  i+=1
 return rows
