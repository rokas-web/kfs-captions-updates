"""Per-style colors shared by style samples, video and Premiere overlays."""
import re
PARTS={'text':'color','background':'box','outline':'outline_color','highlight':'highlight'}

def validate(value,presets):
 if not isinstance(value,dict):raise ValueError('Caption style colors must be an object.')
 result={}
 for key,parts in value.items():
  if key not in presets or not isinstance(parts,dict):raise ValueError('Choose a supported caption style.')
  result[key]={}
  for part,color in parts.items():
   if part not in PARTS or not re.fullmatch('#[0-9a-fA-F]{6}',str(color)):raise ValueError('Choose a valid caption color.')
   result[key][part]=color.upper()
 return result

def style(project,presets):
 key=project.get('caption','classic');out=presets.get(key,presets['classic']).copy()
 out['max_lines']=int(project.get('caption_max_lines',2))
 out['punctuation']=bool(project.get('caption_punctuation',False))
 if out.get('active') and not out.get('reaction_word_box'):
  out['highlight']=project.get('caption_highlight_color',out.get('highlight','#FFE800'))
 for part,value in project.get('caption_style_colors',{}).get(key,{}).items():
  if part in PARTS and re.fullmatch('#[0-9a-fA-F]{6}',str(value)):
   if part=='background' and not out.get('box') or part=='highlight' and not out.get('highlight'):continue
   out[PARTS[part]]=value.upper()
 fx=project.get('caption_style_effects',{})
 fx=fx.get(key,{}) if isinstance(fx,dict) else {}
 if not isinstance(fx,dict):fx={}
 def num(k,lo,hi):
  try:return max(lo,min(hi,float(fx[k])))
  except Exception:return None
 v=num('stroke',0,12)
 if v is not None:out['outline']=int(round(v))
 v=num('shadow',0,15)
 if v is not None:out['shadow']=v
 v=num('blur',0,15)
 if v is not None:out['shadow_blur']=v
 v=num('shadow_opacity',0,100)
 if v is not None:out['shadow_opacity']=v
 c=str(fx.get('shadow_color',''))
 if re.fullmatch('#[0-9a-fA-F]{6}',c):out['shadow_color']=c.upper()
 return out
