"""Independent completed videos in one captions project; no shared BODY edit."""
import copy,hashlib,json,re
from pathlib import Path
from . import media
from .core import atomic
from .versions import retime_rows

OUTPUTS=('preview_file','render_file','exports','package_file','saved_package_file','caption_review','caption_reviews','caption_ready_signature')
def clear(p):
 for key in OUTPUTS:p.pop(key,None)

def attach_scripts(p,remap_invalid=False):
 from .montage_brief import selection
 brief=p.get('caption_brief')
 if not brief:return
 choices=brief['hooks'] or ['BODY' if 'BODY' in brief['sections'] else 'SINGLE']
 scripts={}
 for i,piece in enumerate(p.get('media_segments',[])):
  if 'brief_hook' not in piece or remap_invalid and piece['brief_hook'] not in choices:
   found=re.search(r'(?:^|[^a-z0-9])([HV][1-9][0-9]*)(?:$|[^a-z0-9])',Path(piece['input_path']).stem,re.I)
   key='H'+found.group(1)[1:] if found else ''
   piece['brief_hook']=key if key in choices else choices[i] if i<len(choices) else choices[0] if len(choices)==1 else ''
  if piece['brief_hook'] not in choices:piece['brief_hook']=''
  scripts[piece['id']]=selection(brief,piece['brief_hook']) if piece['brief_hook'] else ''
 p['segment_scripts']=scripts;p['original_script']=' '.join(scripts.values()).strip()

def mapping(studio,id,data):
 studio.idle(id);p=studio.load(id)
 if p.get('media_mode')!='completed':raise ValueError('Import completed videos first.')
 brief=p.get('caption_brief')
 if not brief:raise ValueError('Read your brief first.')
 choices=brief['hooks'] or ['BODY' if 'BODY' in brief['sections'] else 'SINGLE']
 assignments=data.get('assignments')
 if not isinstance(assignments,list) or not assignments:raise ValueError('Choose a hook for an imported video.')
 items={s['id']:s for s in p['media_segments']}
 for item in assignments:
  if not isinstance(item,dict) or item.get('id') not in items or item.get('hook') not in ['',*choices]:raise ValueError('Choose a brief hook for an imported video.')
 for item in assignments:items[item['id']]['brief_hook']=item['hook']
 attach_scripts(p);p.pop('script_alignment',None);clear(p);p['needs_rebuild']=bool(p.get('scenes'));studio.save(p);return p

def import_files(studio,id,data,stop,update):
 paths=data.get('paths')
 if not isinstance(paths,list) or not 1<=len(paths)<=50 or any(not isinstance(x,str) or not x.strip() for x in paths):raise ValueError('Choose 1–50 completed video files.')
 p=studio.load(id);inputs=[]
 for n,value in enumerate(paths):
  if stop.is_set():raise InterruptedError('Cancelled')
  update(f'Checking completed video {n+1}/{len(paths)}',n/len(paths)*15)
  path=studio.resolve(id,value,stop,update);info=media.probe(path,stop)
  if not any(s.get('codec_type')=='audio' for s in info['streams']) or not any(s.get('codec_type')=='video' for s in info['streams']):raise ValueError(path.name+' needs both video and audio.')
  if any(path==x[0] for x in inputs):raise ValueError('Each completed video must be a different file.')
  length=float(info['format']['duration'])
  if length<=0:raise ValueError(path.name+' has no usable duration.')
  inputs.append((path,info,length))
 identity=hashlib.sha256(json.dumps(['completed-1',[(str(f),f.stat().st_size,f.stat().st_mtime_ns) for f,_,_ in inputs]]).encode()).hexdigest()[:14]
 work=studio.folder(id)/('completed_'+identity);work.mkdir(exist_ok=True)
 prior={s['input_path']:s for s in p.get('media_segments',[]) if s.get('kind')=='completed'}
 segments=[];cursor=0
 for i,(path,info,length) in enumerate(inputs):
  if stop.is_set():raise InterruptedError('Cancelled')
  update(f'Preparing speech for video {i+1}/{len(inputs)} · '+path.name,15+i/len(inputs)*75)
  dest=work/f'{i:03}_speech.wav';ready=dest.with_suffix('.ready.json');tmp=dest.with_suffix('.preparing.wav')
  if not dest.is_file() or not ready.is_file():
   media.run(['ffmpeg','-y','-v','error','-stats','-i',path,'-vn','-af','apad','-t',str(length),'-ar','48000','-ac','2','-c:a','pcm_s16le',tmp],stop,update=update,label=f'Preparing speech for video {i+1}/{len(inputs)}',total=length,progress_range=(15+i/len(inputs)*75,15+(i+1)/len(inputs)*75))
   if stop.is_set():raise InterruptedError('Cancelled')
   tmp.replace(dest);atomic(ready,dict(duration=media.duration(dest)))
  length=media.duration(dest);vs=next(s for s in info['streams'] if s['codec_type']=='video')
  item=dict(id=hashlib.sha256(str(path).encode()).hexdigest()[:12],kind='completed',name=path.stem,input_path=str(path),prepared_path=str(dest),start=cursor,end=cursor+length,format='16:9' if vs['width']>vs['height'] else '9:16')
  if 'brief_hook' in prior.get(str(path),{}):item['brief_hook']=prior[str(path)]['brief_hook']
  segments.append(item);cursor+=length
 (work/'concat.txt').write_text(''.join("file '"+Path(s['prepared_path']).name+"'\n" for s in segments),encoding='utf8')
 master=work/'speech_timing.wav';temporary=work/'speech_timing.preparing.wav'
 media.run(['ffmpeg','-y','-v','error','-f','concat','-safe','0','-i','concat.txt','-c','copy',temporary.name],stop,work)
 if stop.is_set():raise InterruptedError('Cancelled')
 measured=media.duration(temporary)
 if abs(measured-cursor)>.03:raise ValueError('Batch speech timing verification failed. Existing inputs were kept.')
 temporary.replace(master);segments[-1]['end']=measured
 p.update(source=str(master),source_type='talking',duration=measured,media_mode='completed',variant_mode='per_hook',media_segments=segments,hooks=[],body_range={},cues=[],scenes=[],segment_scripts={},original_script='',needs_rebuild=False)
 if not p.get('caption_format_manual'):p['montage_format']=segments[0]['format']
 for key in ('speech_cues','speech_source','speech_version','speech_model','script_alignment','sentence_analysis','sentence_signature','audio_source'):p.pop(key,None)
 clear(p);attach_scripts(p);studio.save(p);update(f'{len(segments)} completed video(s) imported',100);return p

def timeline(p,item):
 """Return one complete original recording on its own zero-based clock."""
 ranges=[(item['start'],item['end'])];q=copy.deepcopy(p);q['duration']=item['end']-item['start'];q['name']=p['name']+' · '+item['name']
 q['source']=item['input_path'];q['audio_source']=item['prepared_path']
 q['scenes']=retime_rows(p.get('scenes',[]),ranges);q['cues']=retime_rows(p['cues'],ranges,True)
 q['hooks']=retime_rows(p.get('hooks',[]),ranges)
 q['media_segments']=[{**item,'start':0,'end':q['duration']}]
 q['segment_scripts']={item['id']:p.get('segment_scripts',{}).get(item['id'],'')};q['original_script']=q['segment_scripts'][item['id']]
 evidence=next((x for x in p.get('caption_inputs',[]) if x.get('path')==item['input_path']),{})
 q['caption_scene_cuts']=evidence.get('cuts',[]) if p.get('caption_cut_policy','shot')=='shot' else []
 q['_caption_edit_key']=item['id']
 q['media_mode']='single';q['variant_mode']='timeline';q['body_range']={}
 if not p.get('caption_format_manual'):q['montage_format']=item['format']
 for key in ('sentence_analysis','sentence_signature','caption_review','caption_reviews','caption_inputs','speech_cues','source_ranges'):q.pop(key,None)
 return q

def reviews(p):
 from .caption_timeline import report
 return [dict(id=s['id'],name=s['name'],report=report(timeline(p,s))) for s in p.get('media_segments',[]) if s.get('kind')=='completed']
