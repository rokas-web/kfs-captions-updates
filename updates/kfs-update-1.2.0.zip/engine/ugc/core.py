import json, re, uuid, os, unicodedata, hashlib, errno, time
from pathlib import Path

VIDEO={'.mp4','.mov','.mkv','.webm','.avi','.m4v'}
AUDIO={'.mp3','.wav','.m4a','.aac','.flac','.ogg'}
IMAGE={'.jpg','.jpeg','.png','.webp'}
GROUPS={
 'anatomy':'liver figado lymph lymphatic linfa kidney rins gut intestine intestino bloodstream blood sangue organ anatomy anatomia inflammation inflamacao hormone hormonio cell bacteria digestion digestao kidneys organs cells hormones protein enzyme enzymes sludge inflammation lymphatic',
 'ingredient':'bromelain bromelina pineapple abacaxi dandelion cleavers turmeric curcuma ingredient ingrediente vitamin vitamina magnesium magnesio',
 'tired':'tired fatigue exhausted cansado cansada fadiga sleepy sono slump heavy heaviness sluggish',
 'happy':'happy feliz energy energia energetic relief alivio smiling sorriso active walking',
 'product':'product produto bottle frasco capsule capsula supplement suplemento taking scoop using dose',
 'bloating':'bloated bloating swelling swollen inchado inchada belly barriga stomach abdomen',
}
def tokens(s):
 s=unicodedata.normalize('NFKD',s.lower());s=''.join(c for c in s if not unicodedata.combining(c))
 return set(re.findall(r'[a-z0-9]+',s))
GROUP_TOKENS={k:tokens(v) for k,v in GROUPS.items()}
def concepts(s):
 t=tokens(s); return {k for k,v in GROUP_TOKENS.items() if t & v}
def treatment(text):
 c=concepts(text)
 if 'anatomy' in c:return 'animation'
 if 'ingredient' in c:return 'ingredient'
 if 'product' in c:return 'product'
 return 'ugc'
def prompt(text,kind,person):
 prefix='Natural phone video, soft compressed detail, ordinary person, natural window light, no beauty filter, no cinematic grade. ' if kind=='ugc' else 'Clear educational anatomy animation. ' if kind=='animation' else 'Close-up ingredient or product demonstration, preserve supplied packaging. '
 return prefix+f'SUBJECT: {person or "same approved adult creator"}. LOCATION: consistent everyday setting. ACTION: illustrate only this beat: {text}. CAMERA: gentle motivated movement, vertical 9:16. CONSTRAINTS: preserve identity and props; no invented labels, no extra claims, no baked captions; narration added separately.'
def parse_srt(text):
 rows=[]
 for block in re.split(r'\n\s*\n',text.strip().replace('\r','')):
  m=re.search(r'(\d+):(\d+):(\d+)[,.](\d+)\s*-->\s*(\d+):(\d+):(\d+)[,.](\d+)',block)
  if not m:continue
  n=list(map(int,m.groups())); a=n[0]*3600+n[1]*60+n[2]+n[3]/1000;b=n[4]*3600+n[5]*60+n[6]+n[7]/1000
  if b<=a:raise ValueError('Subtitle end must follow start')
  line=re.sub('<[^>]*>','',block[m.end():]).strip()
  if rows and a<rows[-1]['end']-.01:raise ValueError('Overlapping subtitles: fix the SRT before import')
  rows.append(dict(start=a,end=b,text=line))
 if not rows:raise ValueError('No valid SRT cues found')
 return rows

def word_units(cues):
 result=[]
 for c in cues:
  if c.get('words'):result.extend(c['words']);continue
  ws=c['text'].split()
  for i,w in enumerate(ws):result.append(dict(start=c['start']+(c['end']-c['start'])*i/len(ws),end=c['start']+(c['end']-c['start'])*(i+1)/len(ws),text=w))
 return result

def make_plan(p):
 if p.get('workflow')=='montage':
  from .montage import plan
  return plan(p)
 from .matching import prepare,rank,context_for,assign_unique
 from .sentences import transcript_words,sentence_ranges,signature
 from .context import beat_intent,area_cuts,list_cuts,symptom_cuts
 from .products import focus as product_focus,ingredient_explanation
 duration=p['duration'];step=max(.5,min(15,float(p.get('shot_seconds',2))))
 cues=p.get('cues',[]);words=transcript_words(cues);mode=p.get('timing','sentences')
 analysis=p.get('sentence_analysis') if p.get('sentence_signature')==signature(cues) else None
 ranges=sentence_ranges(words,cues,analysis)
 boundaries=[0.0]
 if mode=='sentences':
  for first,last in ranges:
   if last+1<len(words):boundaries.append(min(duration,max(words[last]['end'],words[last+1]['start'])))
 elif mode=='words':
  for w in words:
   if w['end']-boundaries[-1]>=step and w['end']<duration:boundaries.append(w['end'])
 else:
  while boundaries[-1]+step<duration:boundaries.append(round(boundaries[-1]+step,4))
 if mode in ('sentences','words'):
  boundaries.extend(area_cuts(words,ranges));boundaries.extend(list_cuts(words,ranges));boundaries.extend(symptom_cuts(words,ranges))
 boundaries.extend(s['end'] for s in p.get('media_segments',[]) if 0<s['end']<duration)
 boundaries=sorted(set(t for t in boundaries if t<duration))+[duration]
 scenes=[];options={};assets=p.get('assets',[]);person=p.get('person','').strip();coverage=float(p.get('coverage',1));carry=0
 prepared=prepare(assets);script=' '.join(c['text'] for c in cues)
 for index,(a,b) in enumerate(zip(boundaries,boundaries[1:])):
  text=' '.join(w['text'] for w in words if a<=(w['start']+w['end'])/2<b)
  context=context_for(words,a,b,cues)
  visual='';kind=treatment(text or context)
  if mode=='sentences' and analysis:
   last_index=max((i for i,w in enumerate(words) if (w['start']+w['end'])/2<b),default=0)
   beat=next((beat for beat in analysis['sentences'] if beat['end_word']>=last_index),analysis['sentences'][-1]);visual=beat['visual']+' '+beat['keywords'];kind=beat['kind'];context=context_for(words,a,b,cues)
  intent=beat_intent(text,context,script)
  if intent['kind']:
   kind=intent['kind'];visual=intent['visual'];context=(context+' '+intent['anchor']).strip()
  product=product_focus(text,script,prepared,p.get('product_name',''))
  if product and not intent['kind'] and (kind in ('ugc','product') or kind=='ingredient' and not ingredient_explanation(text,product)):
   kind='ugc' if product['action'] or product['result'] else 'product'
   visual=('Real person using the actual '+product['subject']+' product' if product['action'] else 'Real person with the actual '+product['subject']+' product' if product['result'] else 'Actual '+product['subject']+' product packaging and close-up')
  if 'cotton' in tokens(text) or 'muslin' in tokens(text) or 'fabric' in tokens(text):kind='product'
  carry+=coverage;show=carry>=1 or p.get('source_type')=='voiceover'
  if show:carry-=1
  scene=dict(id=hashlib.sha256(json.dumps([p.get('id',''),a,b,text]).encode()).hexdigest()[:12],start=round(a,4),end=round(b,4),text=text,context=context,visual=visual,kind=kind,path='',offset=0,review=True,reason='No relevant unused footage',visual_region=intent['region'],expected_product=product['subject'] if product and not intent['kind'] and kind in ('ugc','product') else '',context_inherited=bool(intent['anchor']),prompt=prompt(visual or text,kind,person))
  if not show and p.get('source_type')=='talking':scene.update(path=p['source'],offset=round(a,4),kind='presenter',review=False,reason='Return to presenter')
  else:options[index]=rank(text,context,kind,prepared,person,allow_edited=p.get('allow_edited')=='last_resort',project_text=script,visual=visual,product_name=p.get('product_name',''))
  scenes.append(scene)
 from .creators import choose,prefer
 creator=choose(scenes,options,person) if p.get('creator_mode','auto')!='off' else person
 p['resolved_person']=creator
 options={i:prefer(rows,creator) for i,rows in options.items()}
 for i,rows in options.items():scenes[i]['candidate_ids']=[a['id'] for _,a,_ in rows[:45]]
 assigned=assign_unique(scenes,options,p.get('repeat_policy','never'),creator)
 for i,scene in enumerate(scenes):
  if i in assigned:
   _,asset,state=assigned[i]
   scene.update(path=asset['path'],kind=asset.get('kind',scene['kind']),reason='Sentence/context match · '+('clean footage confirmed by you' if state=='clean' else 'LAST RESORT: possible captions / narration' if state in ('edited','suspected') else 'content unverified: check captions / narration'))
   from .actions import apply_window
   apply_window(scene,asset)
   if creator and scene['kind']=='ugc':scene['reason']+=' · '+('preferred creator: '+creator if asset.get('person')==creator else 'creator fallback: no unused eligible preferred-creator clip')
  elif not scene['path'] and p.get('source_type')=='talking':scene.update(path=p['source'],offset=scene['start'],reason='No relevant unused footage: presenter fallback')
 return scenes

def atomic(path,data):
 # Unique files keep concurrent writers from truncating each other's staged
 # JSON. Close the handle before replacing: Windows can reject a replacement
 # while another thread, scanner or syncing process briefly has the file open.
 payload=json.dumps(data,indent=2,ensure_ascii=False);path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
 tmp=path.with_name(path.name+'.'+uuid.uuid4().hex+'.tmp');complete=False
 try:
  with tmp.open('x',encoding='utf8') as stream:
   stream.write(payload);stream.flush();os.fsync(stream.fileno())
  complete=True
  delays=(.025,.05,.1,.15,.2,.25,.3,.4,.5,.6)
  for attempt in range(len(delays)+1):
   try:os.replace(tmp,path);return
   except OSError as error:
    transient=isinstance(error,PermissionError) or getattr(error,'winerror',None) in (5,32,33) or error.errno in (errno.EACCES,errno.EBUSY,errno.ETXTBSY)
    if not transient:raise
    if attempt==len(delays):
     raise PermissionError(f'Could not save {path.name}. Windows or another process is blocking the file. Close other editor copies and check access to the project folder, then try again. The previous file and a complete pending save were kept.') from error
    time.sleep(delays[attempt])
 finally:
  # Keep a complete staged JSON if replacement stays blocked. Never delete
  # the destination to force a save; readers must see the old or new file.
  if not complete:
   try:tmp.unlink(missing_ok=True)
   except OSError:pass
