"""Identity and action cues for showing the actual named product."""
from pathlib import PureWindowsPath
from .core import tokens, GROUP_TOKENS

GENERIC=tokens('a an the this that and with from your our my she he it one brand product supplement bottle bottles capsule capsules pills pack package packaging box boxes close up closeup shot video person woman women man men hands hand holding using use taking take takes applies applying apply opens opening drinking drink scoop dose happy smiling face body before after ugc animation ingredient original final media clip')
GENERIC |= set().union(*GROUP_TOKENS.values())
ACTIONS=tokens('use uses using used take takes taking apply applies applying drink drinks drinking swallow swallowing mix mixing scoop scooping open opens opening hold holds holding try tries trying')
PERSON=tokens('person woman women man men girl boy lady creator customer patient hands hand she her he his')
RESULT=tokens('happy happier smiling smile relief relieved energy energized results result feeling better after')
PRODUCT_CUES=tokens('product supplement bottle capsule pills dose scoop pack packaging take taking use uses using apply applying drink drinking')

def aliases(name, script='', prepared=()):
 configured=[tokens(chunk) for chunk in str(name or '').split(',') if chunk.strip()]
 configured=[row for row in configured if row]
 if configured:return configured
 # A distinctive product-library word said in the recording is an identity cue.
 spoken=tokens(script)
 candidates=set()
 for asset,words,_,_ in prepared:
  if asset.get('kind')=='product' or words&ACTIONS:
   candidates.update(word for word in words&spoken if len(word)>=5 and word not in GENERIC)
 return [{word} for word in sorted(candidates)]

def focus(text,script,prepared,name=''):
 known=aliases(name,script,prepared)
 if not known:return None
 spoken=tokens(text)
 mentioned=any(alias<=spoken for alias in known)
 action=bool(spoken&ACTIONS)
 result=bool(spoken&RESULT)
 if not (mentioned or spoken&PRODUCT_CUES and (action or 'product' in spoken or 'supplement' in spoken)):
  return None
 # Describe what the line actually asks to show.
 return {'aliases':known,'action':action,'result':result,'named':mentioned,'subject':name.split(',')[0].strip() if name else next(iter(next((a for a in known if a<=spoken),known[0])))}

def identity(asset,aliases):
 # The scan's relative label is useful; the absolute source root may name the client.
 label=asset.get('label') or PureWindowsPath(str(asset.get('path','')).replace('/','\\')).stem
 words=tokens(label+' '+asset.get('tags',''))
 return any(alias<=words for alias in aliases)

def person_using(asset):
 words=tokens(asset.get('label','')+' '+asset.get('tags',''))
 return bool(words&PERSON and words&ACTIONS)

def person_result(asset):
 words=tokens(asset.get('label','')+' '+asset.get('tags',''))
 return bool(words&PERSON and words&RESULT)


def ingredient_explanation(text,product):
 if not product:return False
 named=set().union(*(a for a in product['aliases'] if a<=tokens(text))) if product['aliases'] else set()
 other=tokens(text)-named
 return bool(other&tokens('bromelain pineapple enzyme extracted extract herb herbs source derived contains ingredient ingredients vitamin vitamins mineral minerals from'))
