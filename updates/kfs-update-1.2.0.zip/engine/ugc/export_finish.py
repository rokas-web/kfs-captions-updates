"""Apply client finishing corrections to saved projects without buying new media."""
import copy,re,uuid
from pathlib import Path
from .core import IMAGE,atomic

def default_emphasis(text):
 # Emphasize an existing phrase only; never invent headline wording.
 words=str(text).split();weak=set('a an the of to in on for and or how why this that your my is are was were'.split())
 for i in range(len(words)-1,-1,-1):
  if re.sub(r'[^\w]','',words[i]).lower() not in weak:
   start=max(0,i-2)
   while start<i and re.sub(r'[^\w]','',words[start]).lower() in weak:start+=1
   return ' '.join(words[start:i+1])
 return ''

def apply(studio,id):
 studio.idle(id);p=studio.load(id)
 if not p.get('scenes') or not p.get('cues'):raise ValueError('Open a saved project with a storyboard and timed captions first.')
 backup=studio.folder(id)/('before_client_finish_'+uuid.uuid4().hex[:8]+'.json')
 atomic(backup,copy.deepcopy(p))
 p.update(caption_grouping='smart',caption_flow='connected',headline_duration='hook',montage_motion='in',montage_strength=.06,visual_motion='dynamic',
  headline_text_color='#FFFFFF',headline_emphasis_color='#FFE800',headline_box_style='none',headline_case='upper')
 changed=0
 for s in p['scenes']:
  if s.get('visual_route')=='layout' or s.get('visual_type') in ('chapter','diagram','offer'):
   s['motion']='none'
   continue
  if Path(s.get('path','')).suffix.lower() in IMAGE and s.get('visual_route')!='layout' and s.get('visual_type') not in ('chapter','diagram','offer'):
   s.update(motion='in',motion_strength=.06);changed+=1
 for h in p.get('hooks',[]):
  if not h.get('emphasis'):h['emphasis']=default_emphasis(h.get('headline',''))
 # Existing exports remain downloadable until a fresh export succeeds.
 p['client_finish_note']=f'Applied connected whole phrases, first-scene headlines and smooth slow zooms to {changed} images. Export again to update the video. Original project backed up.'
 p['client_finish_backup']=str(backup)
 studio.save(p);return p
