"""Local editable chapter, diagram and offer cards. Text is never baked by AI."""
from pathlib import Path
import json,math
from PIL import Image,ImageDraw,ImageFont,ImageOps
from .media import BASE

def font(size):return ImageFont.truetype(str(BASE/'fonts'/'Montserrat-Bold.ttf'),max(12,int(size)))

def lines(text,f,width):
 draw=ImageDraw.Draw(Image.new('RGB',(1,1)));result=[];row=''
 for word in str(text).split():
  if draw.textlength(word,font=f)>width:
   if row:result.append(row);row=''
   part=''
   for c in word:
    if part and draw.textlength(part+c,font=f)>width:result.append(part);part=''
    part+=c
   row=part;continue
  candidate=(row+' '+word).strip()
  if row and draw.textlength(candidate,font=f)>width:result.append(row);row=word
  else:row=candidate
 if row:result.append(row)
 return result

def text_block(draw,text,box,fill='#352c23',size=64):
 x,y,w,h=box
 for s in range(int(size),17,-2):
  f=font(s);rows=lines(text,f,w);line=round(s*1.35)
  if len(rows)*line<=h:break
 if len(rows)*line>h:raise ValueError('Card text is too long. Shorten its title or labels.')
 top=y+(h-len(rows)*line)/2
 for row in rows:
  draw.text((x+w/2,top),row,font=f,fill=fill,anchor='mt');top+=line

def render_card(p,scene,folder):
 layout=scene.get('layout') or {};kind=scene.get('visual_type','illustration')
 if kind not in {'chapter','diagram','offer'}:raise ValueError('Choose a card or diagram first')
 from .geometry import frame_size
 w,h=frame_size(p);im=Image.new('RGB',(w,h),'#f4ead7');d=ImageDraw.Draw(im)
 # A consistent cream canvas and generous safe area; no model-dependent text.
 margin=round(w*.08);d.rounded_rectangle((margin,round(h*.07),w-margin,round(h*.93)),radius=round(w*.025),outline='#b8a48a',width=3)
 title=str(layout.get('title',''))
 if kind=='chapter':
  text_block(d,title,(margin*2,h*.3,w-margin*4,h*.3),size=w*.095)
 elif kind=='offer':
  offer=p.get('visual_offer',{})
  text_block(d,offer.get('brand',''),(margin*2,h*.09,w-margin*4,h*.1),size=w*.055)
  product=offer.get('image_path','')
  if product and Path(product).is_file():
   photo=Image.open(product).convert('RGBA');photo.thumbnail((round(w*.75),round(h*.4)))
   im.paste(photo,(round((w-photo.width)/2),round(h*.23)),photo);d=ImageDraw.Draw(im)
  else:text_block(d,offer.get('product',''),(margin*2,h*.25,w-margin*4,h*.3),size=w*.07)
  text_block(d,offer.get('price',''),(margin*2,h*.64,w-margin*4,h*.09),size=w*.09)
  text_block(d,offer.get('offer',''),(margin*2,h*.74,w-margin*4,h*.08),size=w*.043)
  text_block(d,offer.get('cta',''),(margin*2,h*.84,w-margin*4,h*.055),size=w*.033)
 else:
  text_block(d,title,(margin*2,h*.09,w-margin*4,h*.13),size=w*.056)
  nodes=layout.get('labels',[])[:6];count=len(nodes)
  if not count:raise ValueError('Add diagram labels first')
  mode=layout.get('diagram','flow')
  if mode=='layers':
   for x in (.3,.5,.7):
    d.line((w*x,h*.83,w*x,h*.27),fill='#559b9e',width=max(3,round(w*.005)))
    d.polygon([(w*x,h*.26),(w*(x-.025),h*.29),(w*(x+.025),h*.29)],fill='#559b9e')
   for i,label in enumerate(nodes):
    top=h*(.29+i*.075);d.rounded_rectangle((w*.2,top,w*.8,top+h*.065),radius=10,fill=('#d8c7a5' if i%2 else '#e8dabe'),outline='#a5957a',width=2)
    text_block(d,label,(w*.23,top,w*.54,h*.065),size=w*.035)
  elif mode=='comparison':
   for i,label in enumerate(nodes):
    col=i%2;row=i//2;top=h*(.29+row*.18);left=w*(.13+col*.39)
    d.rounded_rectangle((left,top,left+w*.35,top+h*.15),radius=16,fill='#e6d7bd',outline='#b8a48a',width=2)
    text_block(d,label,(left+w*.02,top+w*.02,w*.31,h*.15-w*.04),size=w*.035)
  else:
   for i,label in enumerate(nodes):
    top=h*(.27+i*.095);d.rounded_rectangle((w*.17,top,w*.83,top+h*.075),radius=16,fill='#e6d7bd',outline='#b8a48a',width=2)
    text_block(d,label,(w*.2,top,w*.6,h*.075),size=w*.037)
    if i<count-1:
     y=top+h*.08;d.line((w*.5,y,w*.5,y+h*.012),fill='#559b9e',width=4)
     d.polygon([(w*.5,y+h*.02),(w*.485,y+h*.008),(w*.515,y+h*.008)],fill='#559b9e')
  text_block(d,layout.get('footer',''),(margin*2,h*.84,w-margin*4,h*.065),size=w*.025)
 folder=Path(folder);folder.mkdir(exist_ok=True,parents=True);dest=folder/(scene['id']+'.png');im.save(dest)
 # The layout JSON is also collected in the Premiere package.
 dest.with_suffix('.layout.json').write_text(json.dumps(dict(kind=kind,layout=layout,offer=p.get('visual_offer') if kind=='offer' else None),ensure_ascii=False,indent=2),encoding='utf8')
 return str(dest)
