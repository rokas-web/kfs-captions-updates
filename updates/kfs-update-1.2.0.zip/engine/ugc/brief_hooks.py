"""Normalize version labels and explicit body-only hook directions."""
import re
from .hook_limits import MAX_HOOKS
HEADER=re.compile(r'^\s*(?:H|V|HOOK\s*)(\d+)\s*(?:\([^\n)]*\))?\s*(?::\s*(.*))?\s*$',re.I)
BODY_ONLY=re.compile(r"^(?:\(?\s*(?:nothing(?: written)? here(?: it means it starts directly from the body)?|no hook\s*[-–—:]?\s*(?:straight to (?:the )?body)?|(?:start|starts|starting)\s+(?:straight |directly )?from (?:the )?body|straight to (?:the )?body|body only)\s*[.!]?\s*\)?)$",re.I)
def header(line):
 match=HEADER.fullmatch(line)
 if not match:return None
 n=int(match.group(1))
 if str(n)!=match.group(1) or not 1<=n<=MAX_HOOKS:raise ValueError('Use up to 50 hooks, H1–H50')
 return 'H'+str(n),match.group(2) or ''
def body_only(text):return not str(text).strip() or bool(BODY_ONLY.fullmatch(str(text).strip()))
def normalize(text):
 lines=[]
 for raw in text.splitlines():
  line=re.sub(r'^#+\s*','',raw.strip())
  found=header(line)
  if found:line=found[0]+': '+found[1]
  elif re.match(r'^Headline(?:\s+on\s+screen)?\s*:',line,re.I) or line.lower()=='headline':line='HEADLINE:'
  lines.append(line)
 return '\n'.join(lines)
