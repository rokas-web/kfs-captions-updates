"""Joined, rounded TikTok background for one or two centered text lines."""
import math

def bubble(boxes,color):
 from .captions import rounded,ass_color
 if not boxes:return []
 a=boxes[0]
 if len(boxes)==1:
  x,y,w,h,r=a;path=rounded(w,h,r)
 else:
  b=boxes[1];al,at,aw,ah,r=a;bl,bt,bw,bh,br=b
  # Nearly equal lines share a clean outer edge, avoiding tiny ledges.
  if abs(aw-bw)<=2*max(r,br):
   center=(al+aw/2+bl+bw/2)/2;aw=bw=max(aw,bw);al=bl=center-aw/2
  ar,ab=al+aw,at+ah;right,bottom=bl+bw,bt+bh
  if not (at<bt<ab<bottom):
   return sum((bubble([box],color) for box in boxes),[])
  if bl<=al and ar<=right:
   points=[(al,at),(ar,at),(ar,bt),(right,bt),(right,bottom),(bl,bottom),(bl,bt),(al,bt)]
  elif al<=bl and right<=ar:
   points=[(al,at),(ar,at),(ar,ab),(right,ab),(right,bottom),(bl,bottom),(bl,ab),(al,ab)]
  else:return sum((bubble([box],color) for box in boxes),[])
  # Degenerate equal-width steps are straight edges, not tiny corners.
  points=[p for i,p in enumerate(points) if p!=points[i-1]]
  changed=True
  while changed and len(points)>4:
   changed=False
   for i,p in enumerate(points):
    prev,nxt=points[i-1],points[(i+1)%len(points)]
    if (prev[0]==p[0]==nxt[0]) or (prev[1]==p[1]==nxt[1]):points.pop(i);changed=True;break
  x=min(p[0] for p in points);y=min(p[1] for p in points);points=[(p[0]-x,p[1]-y) for p in points]
  corners=[]
  for i,p in enumerate(points):
   prev,nxt=points[i-1],points[(i+1)%len(points)];d1=math.dist(p,prev);d2=math.dist(p,nxt);radius=min(r,br,d1/2,d2/2)
   before=tuple(p[j]+(prev[j]-p[j])*radius/d1 for j in (0,1));after=tuple(p[j]+(nxt[j]-p[j])*radius/d2 for j in (0,1))
   c1=tuple(before[j]+(p[j]-before[j])*.55228475 for j in (0,1));c2=tuple(after[j]+(p[j]-after[j])*.55228475 for j in (0,1))
   corners.append((before,c1,c2,after))
  xy=lambda p:f'{p[0]:.2f} {p[1]:.2f}'
  path='m '+xy(corners[0][0])
  for i,(before,c1,c2,after) in enumerate(corners):
   if i:path+=' l '+xy(before)
   path+=' b '+xy(c1)+' '+xy(c2)+' '+xy(after)
  path+=' l '+xy(corners[0][0])
 vector=r'{\an7\pos('+f'{x:.2f},{y:.2f}'+r')\c'+ass_color(color)+r'\p1}'+path+r'{\p0}'
 return [(0,'Draw',vector)]
