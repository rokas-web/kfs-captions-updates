"""Free structured brief import: creative notes stay separate from recorded speech."""
import copy,re
from .presenter import clean,parse_brief
from .hook_limits import MAX_HOOKS,HOOK_PATTERN,hook_number
from .brief_hooks import normalize,body_only

LABEL=re.compile(r'^('+HOOK_PATTERN+r'|BODY|REF|REFERENCE|IDEA|IDE|CONCEPT|TEXT|SCRIPT|AVATAR|CHARACTERS|HEADLINE)(?:\s*:\s*(.*))?$',re.I)

def parse(text,input_mode='brief',hook_count=None):
 if input_mode not in ('brief','spoken','spoken_hooks'):raise ValueError('Choose full brief or spoken script only.')
 result=_hook_lines(text,hook_count) if input_mode=='spoken_hooks' else _spoken(text) if input_mode=='spoken' else _parse(text)
 result['input_mode']=input_mode
 result['parser_version']=4
 result['body_only_hooks']=[key for key in result['hooks'] if result['sections'][key].get('body_only')]
 result['direction_count']=sum(len(s.get('directions',[])) for s in result['sections'].values())
 return result

def _hook_lines(text,hook_count):
 """Explicit input layout, not content inference: first N lines are hooks."""
 if type(hook_count) is not int or not 1<=hook_count<=MAX_HOOKS:raise ValueError('Choose 1–50 opening hook lines.')
 if not isinstance(text,str) or not text.strip():raise ValueError('Paste your spoken script first')
 if len(text)>100000:raise ValueError('Keep the script under 100,000 characters')
 lines=[line.strip() for line in text.splitlines() if line.strip()]
 if len(lines)<=hook_count:raise ValueError('Put each opening hook on its own line, then the shared body on the following lines.')
 if any(re.match(r'^(?:H[0-9]+|BODY)\s*(?::|$)',line,re.I) for line in lines):raise ValueError('This mode uses hook lines without labels. For H1/BODY labels, choose the complete-script mode.')
 sections={f'H{i+1}':dict(spoken=' '.join(line.split()),directions=[]) for i,line in enumerate(lines[:hook_count])}
 sections['BODY']=dict(spoken=' '.join(' '.join(lines[hook_count:]).split()),directions=[])
 return dict(sections=sections,hooks=[f'H{i+1}' for i in range(hook_count)],idea='',reference_urls=[],hook_count=hook_count)

def _spoken(text):
 """Literal narration: only explicit hook/body headers have structural meaning."""
 if not isinstance(text,str) or not text.strip():raise ValueError('Paste your spoken script first')
 if len(text)>100000:raise ValueError('Keep the script under 100,000 characters')
 sections={};current='SINGLE';buffer=[]
 def commit():
  spoken=' '.join(' '.join(buffer).split())
  if not spoken and current=='SINGLE':return
  if current.startswith('H') and body_only(spoken):
   if current in sections:raise ValueError('Duplicate script section: '+current)
   sections[current]=dict(spoken='',directions=[],body_only=True);return
  if not spoken:raise ValueError(current+': no spoken words.')
  if current in sections:raise ValueError('Duplicate script section: '+current)
  sections[current]=dict(spoken=spoken,directions=[])
 for raw in normalize(text).splitlines():
  match=re.fullmatch(r'\s*(H[0-9]+|BODY)\s*(?::\s*(.*))?\s*',raw,re.I)
  if match:
   if re.match(r'^H[0-9]',match.group(1),re.I) and not re.fullmatch(HOOK_PATTERN,match.group(1),re.I):raise ValueError('Use up to 50 hooks, H1–H50')
   commit();current=match.group(1).upper();buffer=[match.group(2)] if match.group(2) else []
  else:buffer.append(raw)
 commit()
 if not sections:raise ValueError('Paste your spoken script first')
 hooks=sorted((k for k in sections if k.startswith('H')),key=hook_number)
 if hooks and ('BODY' not in sections or 'SINGLE' in sections):raise ValueError('Put alternate hooks under H1/H2/H3 and the shared narration under BODY.')
 return dict(sections=sections,hooks=hooks,idea='',reference_urls=[])

def _parse(text):
 if not isinstance(text,str) or not text.strip():raise ValueError('Paste your brief first')
 if len(text)>100000:raise ValueError('Keep the brief under 100,000 characters')
 sections={};current=None;buffer=[];found=False
 def commit():
  if current:
   if current in sections:raise ValueError('Duplicate brief section: '+current)
   sections[current]='\n'.join(buffer).strip()
 for raw in normalize(clean(text)).splitlines():
  line=re.sub(r'^#+\s*','',raw.strip()).strip('"“”');match=LABEL.fullmatch(line.rstrip(':'))
  if match:
   if re.match(r'^H[0-9]',match.group(1),re.I) and not re.fullmatch(HOOK_PATTERN,match.group(1),re.I):raise ValueError('Use up to 50 hooks, H1–H50')
   commit();current=match.group(1).upper();current='IDEA' if current=='IDE' else current;buffer=[match.group(2)] if match.group(2) else [];found=True
  elif re.match(r'^H[0-9]+(?:\s*:|$)',line,re.I):raise ValueError('Use up to 50 hooks, H1–H50')
  elif current:buffer.append(raw)
 commit()
 if not found:
  spoken=parse_brief(text)
  return dict(sections=spoken,hooks=[],idea='',reference_urls=[])
 spoken_keys=[k for k in sections if re.fullmatch(HOOK_PATTERN+r'|BODY',k)]
 if not spoken_keys:
  raw=sections.get('SCRIPT',sections.get('TEXT',''))
  if not raw:raise ValueError('Add H1 and BODY headings, or paste only a spoken script')
  return dict(sections=parse_brief(raw),hooks=[],idea=sections.get('IDEA','')[:4000],reference_urls=list(dict.fromkeys(re.findall(r'https?://[^\s<>\])]+',sections.get('REF',sections.get('REFERENCE','')))))[:5])
 if any(k.startswith('H') for k in spoken_keys) and 'BODY' not in spoken_keys:raise ValueError('Add the shared BODY section after your hooks')
 spoken={}
 for key in spoken_keys:
  if key.startswith('H') and body_only(sections[key]):spoken[key]=dict(spoken='',directions=[],body_only=True)
  else:spoken[key]=parse_brief(key+'\n'+sections[key])[key]
 links=re.findall(r'https?://[^\s<>\])]+',sections.get('REF',sections.get('REFERENCE','')))
 return dict(sections=spoken,hooks=sorted((k for k in spoken if k.startswith('H')),key=hook_number),idea=sections.get('IDEA',sections.get('CONCEPT',''))[:4000],reference_urls=list(dict.fromkeys(links))[:5])

def selection(brief,hook):
 sections=brief['sections'];hooks=brief['hooks']
 if hooks:
  if hook not in hooks:raise ValueError('Choose a hook found in this brief')
  return (sections[hook]['spoken']+' '+sections['BODY']['spoken']).strip()
 if hook not in ('BODY','SINGLE'):raise ValueError('This brief has no alternate hooks')
 return next(iter(sections.values()))['spoken']

def all_speech(brief):
 return ' '.join(brief['sections'][k]['spoken'] for k in [*brief['hooks'],'BODY']) if brief['hooks'] else selection(brief,'BODY' if 'BODY' in brief['sections'] else 'SINGLE')

def attach_scripts(p):
 """Map files in brief hook order; the shared body has exactly one script."""
 brief=p.get('visual_brief')
 if p.get('workflow')!='montage' or not brief:return
 pieces=p.get('media_segments',[])
 if not pieces:
  p['original_script']=all_speech(brief) if p.get('media_mode')=='hooks' else selection(brief,p.get('visual_brief_hook') or (brief['hooks'] or ['BODY' if 'BODY' in brief['sections'] else 'SINGLE'])[0])
  return
 hooks=[s for s in pieces if s['kind']=='hook'];body=[s for s in pieces if s['kind']=='body']
 if len(hooks)!=len(brief['hooks']) or len(body)!=1:raise ValueError('Import one audio file per brief hook, in '+', '.join(brief['hooks'])+' order, plus one BODY audio file.')
 p['segment_scripts']={piece['id']:brief['sections'][label]['spoken'] for piece,label in zip(hooks,brief['hooks'])}
 p['segment_scripts'][body[0]['id']]=brief['sections']['BODY']['spoken']
 for piece,label in zip(hooks,brief['hooks']):
  piece['name']=label
  for hook in p.get('hooks',[]):
   if hook['id']==piece['id']:hook['name']=label
 body[0]['name']='BODY';p['original_script']=all_speech(brief)

def apply(studio,id,data):
 studio.idle(id);p=studio.load(id)
 if p.get('workflow')!='montage':raise ValueError('Use this importer in Narrated montage / Illustrated explainer')
 if 'text' in data:
  brief=parse(data['text']);brief['text']=data['text']
 else:
  brief=copy.deepcopy(p.get('visual_brief'))
  if not brief:raise ValueError('Import your brief first')
 options=brief['hooks'] or ['BODY' if 'BODY' in brief['sections'] else 'SINGLE']
 hook=data.get('hook') or (p.get('visual_brief_hook') if p.get('visual_brief_hook') in options else options[0])
 script=all_speech(brief) if p.get('media_mode')=='hooks' else selection(brief,hook)
 if len(script)>60000:raise ValueError('Keep the spoken script under 60,000 characters')
 changed=p.get('visual_brief_hook')!=hook or p.get('original_script')!=script or p.get('visual_brief')!=brief
 if changed:
  from .visual_montage import clear_outputs
  p.update(original_script=script,visual_brief=brief,visual_brief_hook=hook,needs_rebuild=bool(p.get('scenes')))
  attach_scripts(p)
  p.pop('script_alignment',None);p.pop('alignment_review',None);p.pop('alignment_review_file',None);p.pop('visual_plan_approval',None);clear_outputs(p)
 else:p['visual_brief_hook']=hook
 from .offer_script import autofill
 offer_changed=autofill(p)
 if offer_changed:
  from .visual_montage import clear_outputs
  for scene in p.get('scenes',[]):
   if scene.get('visual_type')=='offer' and scene.get('visual_route')=='layout':scene['path']='';scene['review']=True
  clear_outputs(p)
 studio.save(p);return p

def planning_notes(p):
 brief=p.get('visual_brief') or {};sections=brief.get('sections',{});hook=p.get('visual_brief_hook')
 labels=[*brief.get('hooks',[]),'BODY','SINGLE'] if p.get('media_mode')=='hooks' else (hook,'BODY','SINGLE')
 out=dict(idea=brief.get('idea',''),directions={k:sections[k].get('directions',[]) for k in labels if k in sections})
 if p.get('media_segments') and p.get('media_mode')=='hooks':out['sections']=[{k:s[k] for k in ('name','kind','start','end')} for s in p['media_segments']]
 return out
