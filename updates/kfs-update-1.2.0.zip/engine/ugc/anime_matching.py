"""Offline Dragon Ball matching. Never rewrites narration or caption text."""
import copy,re
from pathlib import Path
from .core import IMAGE

VERSION=1
EXTRA_CHARACTERS={'bardock','raditz','nappa','cabba','caulifla','kale','gogeta','vegito'}
SAIYANS={'goku','vegeta','gohan','trunks','broly','goten','pan',*EXTRA_CHARACTERS}
ALIASES={
 'vegeta':'vegeta vegita vegiita vegeeta vegetta vegieta vegueta vejita bejita vageta vageeta',
 'saiyan':'saiyan saiyan saiyans sayan sayans sayian sayians saian saians saiyajin saiyajins saiyajines sayajin sayajins saiajin saiajins saiya saiyas',
 'goku':'goku gokuu gokou gokuh kakarot kakarott kakarotto',
 'frieza':'frieza freeza freezer freiza freesa friza',
 'granolah':'granolah granola granolla',
 'beerus':'beerus birus beirus',
 'bardock':'bardock bardok',
 'raditz':'raditz radits radditz',
 'gogeta':'gogeta gojeeta',
 'vegito':'vegito vegetto vegetto',
}
LOOKUP={a:key for key,aliases in ALIASES.items() for a in aliases.split()}

def enabled(p):return p.get('workflow')=='montage' and p.get('visual_style')=='anime'

def canonical(text):
 def replace(match):
  word=match.group(0).casefold()
  if word in LOOKUP:return LOOKUP[word]
  # Vowel-only variants: VEGEETA / VEGIITA / VEGUETA, not unrelated words.
  if 5<=len(word)<=10 and re.fullmatch(r'v[aeiou]+g+[aeiou]+t+[aeiou]+',word):return 'vegeta'
  if 5<=len(word)<=11 and re.fullmatch(r's[aeiou]+y[aeiou]+n+s?',word):return 'saiyan'
  return word
 text=re.sub(r'[_\-]+',' ',str(text).lower())
 return re.sub(r'\b[^\W\d_]+\b',replace,text)

def query(text,context,visual,previous=''):
 from .montage import character_names,forms
 text,context,visual=map(canonical,(text,context,visual))
 current=character_names(text,True);mentioned=character_names(context,True)
 prior=character_names(previous,True)
 if current:
  # Measured speech wins over an old AI direction for a different actor/form.
  if character_names(visual,True)-current or (forms(text,True) and forms(visual,True)-forms(text,True)):visual=''
  subject=current
 elif len(mentioned)==1:subject=mentioned
 else:subject=prior
 stated=forms(text,True);context_forms=forms(context,True)
 if not stated and subject==mentioned and len(mentioned)==1 and len(context_forms)==1:
  stated=context_forms;text+=' '+next(iter(stated))
 if stated and forms(visual,True)-stated:visual=''
 # Keep the nearest subject for abstract phrases such as "this shift". A
 # general word like "universe" must not replace him with arbitrary fighters.
 if subject and not current:
  if character_names(visual,True)-subject:visual=''
  text+=' '+' '.join(n.replace('_',' ') for n in sorted(subject))
 return ' '.join([text,visual]).strip(),subject or prior

def segment(s):return {k:copy.deepcopy(s[k]) for k in ('id','start','end','text','context','visual') if k in s}

def append_hold(p,scenes,s):
 """Extend only a contiguous, existing still; sections and cards stay separate."""
 if not enabled(p) or not scenes or s.get('path') or s.get('visual_route','data')!='data' or s.get('visual_type') in ('chapter','diagram','offer'):return False
 previous=scenes[-1]
 if previous.get('visual_route','data')!='data' or previous.get('visual_type') in ('chapter','diagram','offer'):return False
 path=previous.get('path','')
 if not path or Path(path).suffix.lower() not in IMAGE or not Path(path).is_file():return False
 if abs(float(previous['end'])-float(s['start']))>1e-7:return False
 if any(previous.get(k)!=s.get(k) for k in ('section_id','section_kind','section_name')):return False
 parts=previous.setdefault('anime_hold_segments',[segment(previous)])
 parts.extend(copy.deepcopy(s.get('anime_hold_segments') or [segment(s)]))
 previous.update(end=s['end'],text=' '.join(part.get('text','') for part in parts if part.get('text','').strip()),anime_hold=True,review=True)
 previous['context']=' '.join(dict.fromkeys(part.get('context','') for part in parts if part.get('context','')))
 previous['reason']='Anime continuity: previous still extended through unmatched speech. Review this longer hold; narration and captions keep their original timing.'
 return True

def valid_hold(p,s):
 if not enabled(p) or not s.get('anime_hold') or Path(s.get('path','')).suffix.lower() not in IMAGE or s.get('visual_route','data')!='data':return False
 parts=s.get('anime_hold_segments',[])
 if not isinstance(parts,list) or len(parts)<2:return False
 cursor=float(s['start'])
 try:
  for part in parts:
   if abs(float(part['start'])-cursor)>1e-7 or float(part['end'])<=cursor:return False
   cursor=float(part['end'])
  return abs(cursor-float(s['end']))<=1e-7
 except (KeyError,TypeError,ValueError):return False

def repair(studio,id,stop,update):
 """Repair the current local shots, preserving approved and paid selections."""
 import time
 from collections import defaultdict
 from . import montage,media
 from .core import atomic
 from .visual_montage import filtered,clear_outputs
 p=studio.load(id)
 if not enabled(p):raise ValueError('Select Dragon Ball / shonen anime to use anime repair.')
 if p.get('visual_source','data')=='ai':raise ValueError('Anime matching repair uses your local media; choose My data only or My data + AI.')
 if p.get('needs_rebuild'):raise ValueError('The script or settings changed. Build your current shots before repairing matches.')
 if not p.get('scenes'):raise ValueError('Build your shots first.')
 assets=filtered(p).get('assets',[])
 if not assets:raise ValueError('Scan your image/video database first.')
 original=copy.deepcopy(p['scenes']);index=montage.search_index(assets,True)
 history=defaultdict(list);lengths={};result=[];subject='';previous_section=None;replaced=extended=0
 for i,old in enumerate(original):
  if stop and stop.is_set():raise InterruptedError('Cancelled; original shots are kept')
  update('Checking anime shot '+str(i+1)+' of '+str(len(original)),round(i/max(1,len(original))*90))
  s=copy.deepcopy(old);section=(s.get('section_id'),s.get('section_kind'),s.get('section_name'))
  if section!=previous_section:subject='';previous_section=section
  matching,subjects=query(s.get('text',''),s.get('context',''),s.get('visual',''),subject)
  subject=' '.join(n.replace('_',' ') for n in sorted(subjects))
  protected=(not s.get('review',True) or s.get('visual_route','data')!='data' or s.get('visual_type') in ('chapter','diagram','offer') or any(s.get(k) for k in ('image_path','video_path','image_task','video_task','image_submission','video_submission','product_photo_path','product_reference_path')))
  if not protected:
   rows=montage.rank_assets(matching,'','',assets,'anime',index,anime=True)
   video_first=p.get('montage_media_preference')=='video_first'
   choices=sorted(rows,key=lambda row:(video_first and Path(row[1]['path']).suffix.lower() not in IMAGE,row[0]-20*len(history[montage.asset_key(row[1])])),reverse=True)
   s['candidate_ids']=[a['id'] for _,a in choices[:45]]
   exists=s.get('path') and Path(s['path']).is_file()
   # Leave good suggestions untouched. Correct only unavailable footage or
   # an unapproved actor/form mismatch; approved/manual choices stay intact.
   incompatible=bool(subjects or montage.forms(matching,True)) and s.get('path') and not any(montage.path_key(a['path'])==montage.path_key(s['path']) for _,a in rows)
   if not exists or incompatible:
    s['path']='';s['offset']=0
    for score,a in choices:
     key=montage.asset_key(a)
     if not montage.can_reuse(p,history[key],len(result)) or not Path(a['path']).is_file():continue
     if Path(a['path']).suffix.lower() not in IMAGE:
      if key not in lengths:
       try:lengths[key]=float(a.get('montage_duration') or media.duration(a['path']))
       except (OSError,RuntimeError,ValueError):lengths[key]=0
      if lengths[key]+.02<s['end']-s['start']:continue
     s.update(path=a['path'],review=True,reason='Anime spelling and narration-context match. Review the exact character, form and action.')
     break
    if s.get('path')!=old.get('path'):replaced+=1
   if append_hold(p,result,s):extended+=1;continue
  if s.get('path'):
   a=next((a for a in assets if montage.path_key(a['path'])==montage.path_key(s['path'])),{'path':s['path']})
   history[montage.asset_key(a)].append(len(result))
  result.append(s)
 if stop and stop.is_set():raise InterruptedError('Cancelled; original shots are kept')
 if result!=original:
  backup=studio.folder(id)/('anime_matching_backup_'+str(time.time_ns())+'.json')
  atomic(backup,{'scenes':original,'needs_rebuild':p.get('needs_rebuild',False),'visual_plan_approval':p.get('visual_plan_approval')})
  p.setdefault('anime_matching_backups',[]).append(str(backup))
  p['scenes']=result;montage.validate(copy.deepcopy(p));clear_outputs(p);p.pop('visual_plan_approval',None)
 p.update(anime_matching_version=VERSION,anime_repair_note=f'Anime repair complete: {replaced} matches changed, {extended} gaps joined to the previous still. Review changed shots before exporting.')
 studio.save(p)
