"""Local speech recognition in disposable, cancellable processes.

Resolve/download once before trying CUDA, so a network wait is not mistaken
for a GPU failure. Workers never write project files or invoke provider APIs.
"""
import atexit, json, os, shutil, subprocess, sys, tempfile, threading, time
from contextlib import contextmanager
from pathlib import Path

GPU_LOAD_TIMEOUT=90
GPU_SPEECH_TIMEOUT=120
CPU_LOAD_TIMEOUT=120
DOWNLOAD_TIMEOUT=1200
POLL_SECONDS=.15
HEARTBEAT_SECONDS=5
_workers=set()
_pending_cleanup=set()
_lock=threading.Lock()
_dll_handles=[]

def configure_gpu_libraries():
 """Register portable NVIDIA DLLs inside this process; no system installation."""
 if sys.platform!='win32':return
 roots=[Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parents[1]))/'gpu_runtime',Path(sys.executable).parent/'gpu_runtime']
 paths=[str(root.resolve()) for root in roots if root.is_dir()]
 paths=list(dict.fromkeys(paths))
 if paths:
  os.environ['PATH']=os.pathsep.join(paths+[os.environ.get('PATH','')])
  for path in paths:_dll_handles.append(os.add_dll_directory(path))

class SpeechWorkerError(RuntimeError):pass

WHISPER_FILES=('config.json','tokenizer.json','vocabulary.txt','model.bin')
def whisper_dir(model):
 return (Path.home()/'Library'/'Application Support' if __import__('sys').platform=='darwin' else Path(__import__('os').environ.get('LOCALAPPDATA') or Path.home()))/'KandyForScaleCaptions'/'whisper'/model

def direct_download(model,progress):
 """Plain HTTPS download of the Systran faster-whisper files into the app folder."""
 import ssl,urllib.request
 try:
  import certifi;context=ssl.create_default_context(cafile=certifi.where())
 except Exception:context=ssl.create_default_context()
 target=whisper_dir(model);target.mkdir(parents=True,exist_ok=True)
 base='https://huggingface.co/Systran/faster-whisper-'+model+'/resolve/main/'
 for name in WHISPER_FILES:
  dest=target/name
  if dest.is_file() and dest.stat().st_size>0:continue
  part=dest.with_name(name+'.part');last=0
  request=urllib.request.Request(base+name,headers={'User-Agent':'KandyForScaleCaptions'})
  with urllib.request.urlopen(request,timeout=60,context=context) as response,part.open('wb') as stream:
   total=int(response.headers.get('Content-Length') or 0);size=0
   while True:
    chunk=response.read(1024*1024)
    if not chunk:break
    stream.write(chunk);size+=len(chunk)
    if total>5_000_000 and size-last>=20_000_000:
     last=size;progress('download',f'Downloading speech model · {size//1_000_000} of {total//1_000_000} MB (first use only)')
  if total and size!=total:raise ValueError('Speech model download was interrupted')
  os.replace(part,dest)
 return target

def model_ready(path):
 path=Path(path)
 return all((path/name).is_file() and (path/name).stat().st_size>0 for name in ('model.bin','config.json','tokenizer.json')) and any(f.is_file() and f.stat().st_size>0 for f in path.glob('vocabulary.*'))

def worker_command(folder):
 if getattr(sys,'frozen',False):return [sys.executable,'--speech-worker',str(folder)]
 # pythonw launches a hidden worker too; no shell or PATH interpreter required.
 return [sys.executable,str(Path(__file__).resolve().parents[1]/'app.py'),'--speech-worker',str(folder)]

def _terminate(process):
 if process.poll() is not None:return
 try:process.terminate()
 except OSError:
  if process.poll() is not None:return
  raise
 try:process.wait(timeout=2)
 except subprocess.TimeoutExpired:
  process.kill();process.wait(timeout=2)

def cancel_all():
 with _lock:active=list(_workers)
 for process in active:
  try:_terminate(process)
  except OSError:pass

atexit.register(cancel_all)

def _cleanup_folder(folder):
 # Windows may retain a sharing lock briefly after process termination.
 # Housekeeping must never replace a recognition result or cancellation.
 try:shutil.rmtree(folder)
 except FileNotFoundError:pass
 except OSError:
  with _lock:_pending_cleanup.add(folder)
  return
 with _lock:_pending_cleanup.discard(folder)

@contextmanager
def _worker_directory(root):
 with _lock:pending=list(_pending_cleanup)
 for old in pending:_cleanup_folder(old)
 folder=Path(tempfile.mkdtemp(prefix='speech_',dir=root))
 try:yield folder
 finally:_cleanup_folder(folder)

def _run_worker(request,stop,update,root):
 if stop.is_set():raise InterruptedError('Cancelled')
 with _worker_directory(root) as folder:
  folder=Path(folder);(folder/'request.json').write_text(json.dumps(request),encoding='utf8')
  events=folder/'events.jsonl';events.touch()
  env=os.environ.copy();env.setdefault('HF_HUB_ETAG_TIMEOUT','15');env.setdefault('HF_HUB_DOWNLOAD_TIMEOUT','30')
  process=subprocess.Popen(worker_command(folder),stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,env=env,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
  with _lock:_workers.add(process)
  stage='download' if request['action']=='prepare' else 'startup'
  device=request.get('device','cpu');born=changed=time.monotonic();last_ui=0;offset=0;pending='';result=None;error=None;label='Starting local speech worker';progress=0
  try:
   while True:
    if stop.is_set():raise InterruptedError('Cancelled')
    with events.open(encoding='utf8') as stream:
     stream.seek(offset);pending+=stream.read();offset=stream.tell()
    lines=pending.split('\n');pending=lines.pop()
    for line in lines:
     if not line:continue
     item=json.loads(line);kind=item.get('kind')
     if kind=='progress':
      stage=item['stage'];label=item['message'];progress=item.get('progress',0);changed=time.monotonic();last_ui=changed;update(label,progress)
     elif kind=='result':result=item['value']
     elif kind=='error':error=item['message']
    if stop.is_set():raise InterruptedError('Cancelled')
    if result is not None:return result
    if error:raise SpeechWorkerError(error)
    if process.poll() is not None:raise SpeechWorkerError(f'Local speech worker exited unexpectedly (code {process.returncode}).')
    now=time.monotonic()
    if request['action']=='prepare':
     limit=DOWNLOAD_TIMEOUT;elapsed=now-born
    else:
     # Preparing the first segment includes audio decoding/VAD, which can be
     # slower on CPU. Later progress resets this inactivity deadline.
     limit=(GPU_LOAD_TIMEOUT if stage in ('startup','load') else GPU_SPEECH_TIMEOUT) if device=='cuda' else (CPU_LOAD_TIMEOUT if stage in ('startup','load') else max(180,min(900,float(request.get('duration',0))*3+60)))
     elapsed=now-changed
    if elapsed>=limit:
     if request['action']=='prepare':raise SpeechWorkerError('Speech model download timed out. Check your internet connection and try again; downloaded files stay cached.')
     raise SpeechWorkerError(f'{"GPU" if device=="cuda" else "CPU"} {"loading" if stage in ("startup","load") else "speech processing"} stopped responding for {int(limit)} seconds.')
    if now-last_ui>=HEARTBEAT_SECONDS:
     suffix=f' · {int(now-born)}s elapsed'
     if request['action']=='prepare':suffix+=' · first use may download files'
     elif device=='cuda':suffix+=f' · CPU retry after {int(limit)}s without progress'
     update(label+suffix,progress);last_ui=now
    stop.wait(POLL_SECONDS)
  finally:
   try:_terminate(process)
   finally:
    with _lock:_workers.discard(process)

def recognize(p,model_name,preference,stop,update,root,cpu_reason='',windows=None):
 request=dict(action='prepare',model=model_name)
 update(f'Checking/downloading {model_name.title()} speech model (first use needs internet)',0)
 prepared=_run_worker(request,stop,update,root)
 pieces=p.get('media_segments') or [dict(start=0,end=p['duration'],prepared_path=p['source'],name='Narration')]
 request=dict(action='transcribe',model=model_name,model_path=prepared['model_path'],duration=p['duration'],pieces=pieces)
 if windows:request.update(windows=windows,duration=20)
 reason=cpu_reason if preference=='auto' else ''
 if preference=='auto' and not reason:
  try:
   answer=_run_worker({**request,'device':'cuda'},stop,update,root)
   if not answer.get('unavailable'):return {**answer,'fallback_reason':''}
   # No compatible GPU is ordinary CPU operation, not a failed GPU session.
  except SpeechWorkerError as exc:reason=str(exc)[:600]
 if stop.is_set():raise InterruptedError('Cancelled')
 update(('GPU unavailable/stalled; retrying on CPU automatically. '+reason) if reason else 'Using CPU for local speech recognition',0)
 answer=_run_worker({**request,'device':'cpu'},stop,update,root)
 if stop.is_set():raise InterruptedError('Cancelled')
 return {**answer,'fallback_reason':reason}

def execute(request,emit):
 def progress(stage,message,n=0):emit(dict(kind='progress',stage=stage,message=message,progress=n))
 try:
  if request['action']=='prepare':
   progress('download',f'Checking cached {request["model"].title()} speech model')
   errors=[];path=whisper_dir(request['model'])
   if not model_ready(path):
    from faster_whisper.utils import download_model
    try:
     path=download_model(request['model'],local_files_only=True)
     if not model_ready(path):raise FileNotFoundError('Incomplete model cache')
    except Exception:
     progress('download',f'Downloading {request["model"].title()} speech model · first use only (about 480 MB)')
     try:path=direct_download(request['model'],progress)
     except Exception as exc:errors.append(str(exc));path=whisper_dir(request['model'])
     if not model_ready(path):
      try:path=download_model(request['model'])
      except Exception as exc:errors.append(str(exc))
   if not model_ready(path):raise ValueError('Could not download the speech model (about 480 MB). Check the internet connection (a VPN or firewall can block huggingface.co), or run the Kandy For Scale Captions installer again, which downloads it. Details: '+' | '.join(e[:160] for e in errors[-2:]))
   emit(dict(kind='result',value=dict(model_path=str(path))));return
  device=request['device'];label='GPU' if device=='cuda' else 'CPU'
  progress('load',f'Loading {label} {request["model"].title()} speech model')
  if device=='cuda':
   configure_gpu_libraries()
   import ctranslate2
   if ctranslate2.get_cuda_device_count()<1:
    emit(dict(kind='result',value=dict(unavailable=True)));return
  from faster_whisper import WhisperModel
  compute='int8_float16' if device=='cuda' else 'int8'
  if sys.platform=='darwin':
   import ctranslate2
   if compute not in ctranslate2.get_supported_compute_types('cpu'):compute='float32'
  model=WhisperModel(request['model_path'],device=device,compute_type=compute,local_files_only=True)
  found=[]
  if request.get('windows'):
   # Audio is decoded inside this disposable worker, so Cancel also interrupts
   # decoding. No FFmpeg grandchildren or script prompts are involved.
   from faster_whisper.audio import decode_audio
   for window in request['windows']:
    progress('speech',f'Rechecking a short passage on {label}',0)
    audio=decode_audio(window['path']);lo=window['start'];hi=window['end']
    segments,_=model.transcribe(audio[int(lo*16000):int(hi*16000)],word_timestamps=True,vad_filter=False,condition_on_previous_text=False,initial_prompt=None)
    offset=window['offset']+lo
    for segment in segments:
     found.append(dict(start=offset+segment.start,end=offset+segment.end,text=segment.text.strip(),words=[dict(start=offset+w.start,end=offset+w.end,text=w.word.strip()) for w in segment.words or []]))
    progress('speech',f'Short passage checked on {label}',100)
   emit(dict(kind='result',value=dict(cues=found,device='GPU' if device=='cuda' else 'cpu')));return
  for piece in request['pieces']:
   name=piece.get('name','speech');progress('speech',f'Transcribing {name} on {label}',int(piece['start']/request['duration']*100))
   segments,_=model.transcribe(piece['prepared_path'],word_timestamps=True,vad_filter=True,condition_on_previous_text=False,initial_prompt=None)
   for segment in segments:
    start=piece['start']+segment.start;end=min(piece['end'],piece['start']+segment.end)
    if end<=start:continue
    found.append(dict(start=start,end=end,text=segment.text.strip(),words=[dict(start=piece['start']+w.start,end=min(piece['end'],piece['start']+w.end),text=w.word.strip()) for w in segment.words or []]))
    progress('speech',f'Transcribing {name} on {label}',int(end/request['duration']*100))
  if not found:raise ValueError('No speech detected. Check the audio or import an SRT.')
  emit(dict(kind='result',value=dict(cues=found,device='GPU' if device=='cuda' else 'cpu')))
 except Exception as exc:
  message=str(exc)
  if isinstance(exc,ImportError):message='Speech dependencies unavailable. Run Setup_Windows.bat. '+message
  emit(dict(kind='error',message=message[:1500] or type(exc).__name__))

def worker_main(folder):
 folder=Path(folder)
 request=json.loads((folder/'request.json').read_text(encoding='utf8'))
 with (folder/'events.jsonl').open('a',encoding='utf8') as stream:
  def emit(item):stream.write(json.dumps(item,ensure_ascii=True)+'\n');stream.flush()
  execute(request,emit)
