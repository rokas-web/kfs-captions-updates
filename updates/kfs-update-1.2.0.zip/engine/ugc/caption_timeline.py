"""One connected caption clock, with still-picture cuts on whole phrase edges."""
import copy,re,hashlib,json
from pathlib import Path
from .caption_phrases import smart_groups,token,caption_words,chapter,terminal,language_edges,WEAK,clause_start
from .core import IMAGE
ENGINE="captions-1.9-readable-previews"

class CaptionCutConflict(ValueError):
 def __init__(self,message,cut_time=None):
  super().__init__(message);self.cut_time=cut_time

def punctuated_word(w):
 text=str(w['text']);raw=str(w.get('raw',text))
 lexical=lambda value:re.sub(r'[^\w%‰°]','',str(value).casefold())
 if lexical(raw)!=lexical(text):return text
 before=re.match(r'^[^\w$£€]*',raw).group()
 after=re.search(r'[^\w%‰°]*$',raw).group()
 return before+text.strip('.,!?;:"“”()')+after

def caption_text(p,words):
 """Apply punctuation to saved manual groups as well as newly parsed words."""
 from .captions import clean_text
 return clean_text(' '.join(punctuated_word(w) if p.get('caption_punctuation') else w['text'] for w in words),punctuation=p.get('caption_punctuation',False))

def display_words(p):
 from .captions import clean_text
 display=[]
 measured=caption_words(p);joined=[];index=0
 while index<len(measured):
  w=measured[index]
  if str(w['text']).strip() in {'$','£','€'} and index+1<len(measured) and re.match(r'\d',str(measured[index+1]['text'])):
   right=measured[index+1];w={**w,'text':w['text'].strip()+right['text'],'raw':w['text'].strip()+right.get('raw',right['text']),'end':right['end']};index+=1
  # ASR may emit 30 + -59 + % as three timed tokens. Keep the numeric
  # expression intact before punctuation cleaning, including its symbol.
  while index+1<len(measured):
   right=measured[index+1];left_text=str(w['text']).strip();right_text=str(right['text']).strip()
   numeric=bool(re.fullmatch(r'\d[\d,.]*(?:[-–—]\d[\d,.]*)?',left_text))
   if numeric and (right_text in {'%','‰','°'} or re.fullmatch(r'[-‐‑‒–—]\d[\d,.]*',right_text)):
    w={**w,'text':left_text+right_text,'raw':w.get('raw',left_text)+right.get('raw',right_text),'end':right['end']};index+=1
   else:break
  joined.append(w);index+=1
 for w in joined:
  text=w['text']
  if p.get('caption_punctuation'):
   # Only restore punctuation from a matching script token. Its digits and
   # spoken wording always come from measured speech, never the brief.
   text=punctuated_word(w)
  parts=clean_text(text,False,punctuation=p.get('caption_punctuation',False)).split()
  for i,part in enumerate(parts):
   if not re.search(r'\w',part):continue
   display.append(dict(text=part,raw=w.get('raw',w['text']) if i==len(parts)-1 else part,
    start=w['start']+(w['end']-w['start'])*i/max(1,len(parts)),end=w['start']+(w['end']-w['start'])*(i+1)/max(1,len(parts)),caption_break_before=i==0 and w.get('caption_break_before',False)))
 return display

def timed_rows(rows,start,end):
 """Display changes follow measured onsets; readability never delays speech."""
 from .captions import clean_text
 result=[]
 for row in rows:
  r={**row,'words':copy.deepcopy(row['words'])}
  r['start']=max(start,min(end,round(r['words'][0]['start']*30)/30))
  if not result:r['start']=start
  r['text']=clean_text(' '.join(w['text'] for w in r['words']))
  result.append(r)
 i=0
 while i+1<len(result):
  row,nxt=result[i],result[i+1]
  if nxt['start']-row['start']<.4 and row['sentence_id']==nxt['sentence_id'] and not chapter(row['words'],0) and len(row['text']+' '+nxt['text'])<=110:
   row['words'].extend(nxt['words']);row['text']=clean_text(' '.join(w['text'] for w in row['words']));result.pop(i+1);continue
  i+=1
 for i,r in enumerate(result):
  next_start=result[i+1]['start'] if i+1<len(result) else end
  r['end']=min(end,next_start)
 return [r for r in result if r['end']>r['start']]

def audio_context_edges(p):
 """Silence trimming can fragment one recording into many retained ranges."""
 segments=p.get('media_segments',[]);edges=[]
 identity=lambda s:s.get('id') or s.get('input_path') or s.get('prepared_path') or s.get('kind')
 for i,s in enumerate(segments):
  if 'end' not in s:continue
  if i+1<len(segments) and identity(s) and identity(s)==identity(segments[i+1]):continue
  edges.append(round(float(s['end'])*30)/30)
 return sorted(set(edges))

def groups(p,cut_times=(),cut_word_edges=None):
 """Parse the complete word stream BEFORE imposing any picture intervals."""
 display=display_words(p)
 if not display:return []
 duration=float(p['duration'])
 cuts=sorted({round(float(t)*30)/30 for t in cut_times if 0<float(t)<duration})
 required=dict(cut_word_edges or {})
 hard=audio_context_edges(p);context_cuts=[]
 # Independent hook/body recordings are real context boundaries, unlike
 # imported SRT rows. Do not let NLP invent a noun spanning two recordings.
 # Legacy pause fragments after The / and / a modifier remain connected.
 modifiers=set('best better worst natural swollen synthetic american small big real new flat'.split())
 for t in hard:
  j=sum(round(w['start']*30)<round(t*30) for w in display)
  if 0<j<len(display) and token(display[j-1]) not in WEAK|modifiers|{'step'} and not chapter(display,j-1):
   display[j]['caption_break_before']=True;context_cuts.append(t)
 cuts=sorted(set(cuts)|{t for t in context_cuts if 0<t<duration})
 _,_,_,safe=language_edges(display)
 for t in cuts if cut_word_edges is None else ():
  j=sum(round(w['start']*30)<round(t*30) for w in display)
  if j not in safe:
   left=display[j-1]['text'] if j else ''
   right=display[j]['text'] if j<len(display) else ''
   raise CaptionCutConflict(f'Visual cut at {t:.2f}s splits the phrase “{left} {right}”. Move this video cut to a phrase boundary, or replace that shot with an image. No new render was created.',cut_time=t)
  required[j]=t
 # Imported audio section boundaries are hints only: a chopped function
 # word must stay with the following phrase, even across a legacy section.
 blocks=[];block=[];section=0;begin=0
 for i,w in enumerate(display):
  next_section=sum(round(w['start']*30)>=round(t*30) for t in hard)
  punctuation=block and terminal(block[-1])
  section_break=next_section!=section and i in safe
  if block and (section_break or punctuation or clause_start(display,i) or w.get('caption_break_before')):
   blocks.append((begin,block));block=[];begin=i
  block.append(w);section=next_section
 if block:blocks.append((begin,block))
 result=[]
 for sentence_id,(begin,block) in enumerate(blocks):
  mode=p.get('caption_grouping','smart')
  rows=smart_groups(block,max_words=4 if mode=='short' else None,required=[j-begin for j in required if begin<j<begin+len(block)],force_cuts=cut_word_edges is not None)
  cursor=begin
  for row in rows:
   result.append(dict(words=row,sentence_id=sentence_id,first_word=cursor));cursor+=len(row)
 # Partition complete groups, rather than feeding chopped shot buckets back
 # through the parser. This preserves The + noun and and + following clause.
 if cut_word_edges is not None:cuts=sorted(required.values())
 windows=list(zip([0.]+cuts,cuts+[duration]));out=[]
 word_edges=[0]+sorted(required)+[len(display)]
 for index,(a,b) in enumerate(windows):
  bucket=[r for r in result if word_edges[index]<=r['first_word']<word_edges[index+1]] if cut_word_edges is not None else [r for r in result if round(a*30)<=round(r['words'][0]['start']*30)<round(b*30)]
  local=timed_rows(bucket,a,b)
  for row in local:
   if row['end']-row['start']<.4-1e-8 and cut_word_edges is None and b in cuts:
    raise CaptionCutConflict(f"Cut at {b:.2f}s leaves an unreadable caption flash: “{row['text']}”. Adjust this video cut to allow a readable phrase. No new render was created.",cut_time=b if b<duration else a)
  out.extend(local)
 return out

def align_still_run(p,phrases):
 scenes=p.get('scenes',[])
 if not scenes or not all(Path(s.get('path','')).suffix.lower() in IMAGE for s in scenes):return
 edges=[g['start'] for g in phrases]+[float(p['duration'])]
 n=len(scenes);count=len(phrases)
 def chapter(s):
  title=str(s.get('layout',{}).get('title',''))
  return s.get('visual_type')=='chapter' or bool(re.match(r'^step\s+(?:\d+|one|two|three|four|five|six|seven|eight|nine|ten)\b',title,re.I))
 def image_for(g):
  is_label=bool(re.match(r'^step\s+(?:\d+|one|two|three|four|five|six|seven|eight|nine|ten)\b',g['text'],re.I))
  choices=[s for s in scenes if chapter(s)==is_label] or scenes
  # Never carry a chapter card into explanatory text when cuts are collapsed.
  if is_label:return min(choices,key=lambda s:abs(s['start']-g['start']))
  return max(choices,key=lambda s:max(0,min(g['end'],s['end'])-max(g['start'],s['start'])))
 if n>count:
  # More pictures than complete phrases cannot all have different readable
  # captions. Keep the best overlapping original image for each phrase.
  # All originals remain in the saved project; this is an export-only view.
  out=[]
  for g in phrases:
   shot=image_for(g)
   out.append({**copy.deepcopy(shot),'start':g['start'],'end':g['end']})
  p['scenes']=out;p['caption_picture_alignment']={'merged_cuts':n-count,'method':'whole phrases','export_only':True};return
 if n==1:
  p['scenes'][0].update(start=0,end=float(p['duration']));return
 # Chapter cards are pinned to their spoken label, followed immediately by
 # its explanatory phrase. This prevents Step one leaking onto the next image.
 locks={}
 chapters=[i for i,g in enumerate(phrases) if re.match(r'^step\s+(?:\d+|one|two|three|four|five|six|seven|eight|nine|ten)\b',g['text'],re.I)]
 for i,s in enumerate(scenes):
  if chapter(s):
   if chapters:
    j=min(chapters,key=lambda j:abs(edges[j]-s['start']))
    if i:locks[i]=j
    if i+1<n:locks[i+1]=j+1
 # Monotone nearest-edge assignment keeps picture order and all paid images
 # when there are enough phrases. No narration or word timing is changed.
 previous={0:(0.,[])}
 for cut in range(1,n):
  current={};best=(float('inf'),None,None)
  for j in range(cut,count-(n-cut)+1):
   for k in [j-1]:
    if k in previous and previous[k][0]<best[0]:best=(previous[k][0],previous[k][1],k)
   if cut in locks and j!=locks[cut]:continue
   if best[1] is not None:current[j]=(best[0]+(edges[j]-float(scenes[cut]['start']))**2,best[1]+[j])
  previous=current
  if not previous:break
 if not previous:
  # Fall back to one visual per phrase with correct chapter ownership, rather
  # than blank captions or one-word fragments when constraints conflict.
  out=[]
  for g in phrases:
   shot=image_for(g)
   out.append({**copy.deepcopy(shot),'start':g['start'],'end':g['end']})
  p['scenes']=out
 else:
  chosen=min(previous.values(),key=lambda item:item[0])[1];cuts=[0]+[edges[j] for j in chosen]+[float(p['duration'])]
  for i,s in enumerate(scenes):s.update(start=cuts[i],end=cuts[i+1])
 p['caption_picture_alignment']={'method':'whole phrases','export_only':True}

def still_scene(s):return Path(s.get('path','')).suffix.lower() in IMAGE

def align_stills(p,phrases):
 """Align each still run independently, preserving authored video intervals."""
 scenes=p.get('scenes',[])
 if not scenes:return
 if all(still_scene(s) for s in scenes):return align_still_run(p,phrases)
 out=[];i=0;reports=[]
 while i<len(scenes):
  if not still_scene(scenes[i]):out.append(scenes[i]);i+=1;continue
  j=i+1
  while j<len(scenes) and still_scene(scenes[j]):j+=1
  a,b=scenes[i]['start'],scenes[j-1]['end']
  local=copy.deepcopy(p);local['duration']=b-a
  local['scenes']=[{**copy.deepcopy(s),'start':s['start']-a,'end':s['end']-a} for s in scenes[i:j]]
  rows=[{**g,'start':g['start']-a,'end':g['end']-a} for g in phrases if a-1e-8<=g['start'] and g['end']<=b+1e-8]
  if rows:
   align_still_run(local,rows)
   out.extend({**s,'start':round((s['start']+a)*30)/30,'end':round((s['end']+a)*30)/30} for s in local['scenes'])
   reports.append(local.get('caption_picture_alignment',{}))
  else:out.extend(scenes[i:j])
  i=j
 p['scenes']=out
 if reports:p['caption_picture_alignment']={'method':'whole phrases within still runs','export_only':True,'runs':len(reports),'merged_cuts':sum(r.get('merged_cuts',0) for r in reports)}

def fixed_groups(p):
 from .caption_phrases import scene_windows
 return groups(p,cut_times=[a for a,b in scene_windows(p)][1:])

def visible_cuts(p):
 """Original video cuts are fixed; still images can align to phrase edges."""
 duration=float(p['duration'])
 cuts=set(p.get('caption_scene_cuts',[]))
 for scene in p.get('scenes',[]):
  if not still_scene(scene):cuts.update((scene['start'],scene['end']))
 return sorted({round(float(t)*30)/30 for t in cuts if 0<float(t)<duration})

def connected_groups(p,rows):
 """Cover every frame, including pauses and the lead-in, without moving onsets."""
 if not rows:return rows
 rows=copy.deepcopy(rows);rows[0]['start']=0.
 for left,right in zip(rows,rows[1:]):left['end']=right['start']
 rows[-1]['end']=float(p['duration'])
 return rows

def split_at_scene_cuts(rows,cuts):
 """Enforce picture edges even for manual merges or cuts inside one word.

 A held word during a cut/silent pause may need the same text on both sides.
 Those display continuations do not add or change any measured speech token.
 """
 result=[]
 for row in rows:
  boundaries=[row['start']]+[t for t in cuts if row['start']+1e-8<t<row['end']-1e-8]+[row['end']]
  for index,(a,b) in enumerate(zip(boundaries,boundaries[1:])):
   out=copy.deepcopy(row);out.update(start=a,end=b)
   if index:out['scene_continuation']=True
   result.append(out)
 return result

def shot_groups(p):
 """Every detected cut is a caption edge; keep speech words on their clock."""
 words=display_words(p)
 if not words:return []
 cuts=visible_cuts(p);_,_,hints,safe=language_edges(words)
 # Prefer the nearest acoustic word boundary. Grammar breaks ties, rather than
 # discarding picture cuts. A cut in a pause must not promote distant speech.
 edges={};previous=0
 for cut in cuts:
  candidates=[j for j in range(previous+1,len(words)) if abs(words[j]['start']-cut)<=.35 and j in safe and token(words[j-1]) not in WEAK]
  if not candidates:continue
  j=min(candidates,key=lambda j:abs(words[j]['start']-cut)+(0 if j in safe else .025))
  edges[j]=cut;previous=j
 rows=groups(p,sorted(edges.values()),cut_word_edges=edges) if edges else groups(p)
 p['caption_scene_cuts']=cuts;p['caption_ignored_scene_cuts']=[]
 p['caption_picture_alignment']={'method':'every detected scene cut; continuous caption coverage',
  'maximum_boundary_shift_seconds':round(max((abs(words[j]['start']-cut) for j,cut in edges.items()),default=0),3),
  'word_boundary_splits':sum(j not in safe for j in edges),'detected_cuts':len(cuts)}
 return rows

def video_groups(p,cut_times):
 if p.get('caption_cut_policy','shot')=='continuous':return groups(p)
 if p.get('caption_cut_policy')=='strict':return groups(p,cut_times)
 return shot_groups(p)

def fingerprint(p):
 fields=('_caption_canvas','cues','scenes','duration','media_segments','caption_grouping','caption_flow','original_script','segment_scripts','story_brief','visual_brief','script_alignment','caption_inputs','caption_scene_cuts','caption_cut_policy','caption_style_colors','caption_size','caption','caption_max_lines','caption_punctuation','caption_phrase_edits','_caption_edit_key')
 return hashlib.sha256(json.dumps({k:p.get(k) for k in fields},sort_keys=True,default=str).encode()).hexdigest()

def prepare(p,stop=None,update=None):
 if stop is not None and stop.is_set():raise InterruptedError('Cancelled')
 if p.get('caption')=='none':return p
 if p.get('_caption_flow_engine')==ENGINE and p.get('_caption_flow_signature')==fingerprint(p):return p
 out=copy.deepcopy(p)
 out.pop('caption_picture_alignment',None);out.pop('caption_cut_repair',None);out.pop('caption_ignored_scene_cuts',None)
 out.setdefault('duration',max((float(c.get('end',0)) for c in out.get('cues',[])),default=0))
 for key in tuple(out):
  if key.startswith('_caption_flow_'):out.pop(key,None)
 scenes=[]
 for s in out.get('scenes',[]):
  prev=scenes[-1] if scenes else None
  keys=('id','path','motion','motion_strength','focal_x','focal_y','fit','visual_type')
  source_contiguous=prev and (still_scene(s) or abs(float(prev.get('offset',0))+prev['end']-prev['start']-float(s.get('offset',0)))<1e-7)
  if source_contiguous and s.get('id') and all(prev.get(k)==s.get(k) for k in keys) and abs(prev['end']-s['start'])<1e-7:prev['end']=s['end']
  else:scenes.append(s)
 if scenes:out['scenes']=scenes
 # A later video must not switch every still/card to shot-bucket parsing.
 # Honor safe fixed cuts; complete captions can span incompatible video cuts.
 video_cuts={float(s[k]) for s in scenes if not still_scene(s) for k in ('start','end')}
 align=True
 if out.get('caption_cut_policy','shot')=='shot' and visible_cuts(out) and display_words(out):
  phrases=shot_groups(out)
 elif out.get('caption_flow','connected')=='fixed' and scenes:
  try:
   phrases=fixed_groups(out);align=False
  except CaptionCutConflict:
   phrases=video_groups(out,video_cuts)
   if any(still_scene(s) for s in scenes):out['caption_cut_repair']='Image cuts adjusted to keep complete caption phrases. '+out.get('caption_cut_repair','')
 else:phrases=video_groups(out,video_cuts)
 if not phrases:return out
 from .caption_readability import repair
 phrases=repair(out,phrases)
 from .captions import fit_groups
 phrases=fit_groups(out,phrases,stop,update)
 from .caption_editor import apply
 phrases=apply(out,phrases)
 phrases=fit_groups(out,phrases,stop,update)
 # Final text formatting is shared by MP4, review and sidecar SRT. Keep the
 # source cues and measured word clocks untouched for later regeneration.
 from .captions import clean_text
 for row in phrases:row['text']=caption_text(out,row['words'])
 # Saved manual merges retain their words and chosen phrase boundaries.
 from .caption_limits import limit_groups
 phrases=limit_groups(phrases)
 if out.get('caption_flow','connected')=='connected':phrases=connected_groups(out,phrases)
 if out.get('caption_cut_policy','shot')=='shot':phrases=split_at_scene_cuts(phrases,visible_cuts(out))
 if align:align_stills(out,phrases)
 out['_caption_flow_groups']=phrases
 out['_caption_flow_cuts']=sorted({round(s['start']*30)/30 for s in out.get('scenes',[])}|{round(s['end']*30)/30 for s in out.get('scenes',[])}|set(out.get('caption_scene_cuts',[])))
 out['_caption_flow_engine']=ENGINE;out['_caption_flow_signature']=fingerprint(out)
 return out


def report(p,preview=False):
 """Small export evidence, without input paths, credentials or audio."""
 out=prepare(p);length=min(float(out['duration']),10.) if preview else float(out['duration'])
 return dict(engine=out.get('_caption_flow_engine','none'),duration=length,
  caption_flow=out.get('caption_flow','connected'),repair=out.get('caption_cut_repair',''),
  alignment=out.get('caption_picture_alignment',{}),
  picture_cuts=out.get('caption_scene_cuts',[]),
  ignored_dense_cuts=out.get('caption_ignored_scene_cuts',[]),
  outro_hold=out.get('caption_outro_hold',[]),
  continuous_coverage=not any(b['start']>a['end']+1e-8 for a,b in zip(out.get('_caption_flow_groups',[]),out.get('_caption_flow_groups',[])[1:])),
  scene_continuations=sum(bool(g.get('scene_continuation')) for g in out.get('_caption_flow_groups',[])),
  groups=[dict(start=g['start'],end=min(g['end'],length),text=g['text'],scene_continuation=bool(g.get('scene_continuation'))) for g in out.get('_caption_flow_groups',[]) if g['start']<length],
  scenes=[dict(id=s.get('id',''),start=s['start'],end=min(s['end'],length),kind='image' if still_scene(s) else 'video') for s in out.get('scenes',[]) if s['start']<length])
