"""Canvas selection is isolated to the narrated montage workflow."""
def frame_size(p,preview=False):
 wide=p.get('workflow') in ('montage','captions') and p.get('montage_format','16:9')=='16:9'
 w,h=(1920,1080) if wide else (1080,1920)
 return (w//2,h//2) if preview else (w,h)
