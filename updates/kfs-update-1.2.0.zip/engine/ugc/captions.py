"""One caption/headline layout for MP4, UI samples and collected overlays."""
import re,sys,struct,math
from pathlib import Path
from functools import lru_cache
from PIL import ImageFont
from .sentences import transcript_words,sentence_ranges,signature
from .geometry import frame_size
BASE=Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parents[1]))
PRESETS={
 'tiktok':dict(name='TikTok · Proxima Nova',font='Proxima Nova',file='@proxima',size=64,outline=2,shadow=1,case='sentence'),
 'tiktok_native_white':dict(name='TikTok Native · white background',font='Proxima Nova',file='@proxima',size=72,outline=0,shadow=0,case='sentence',color='#000000',box='#FFFFFF',native_bubble=True),
 'tiktok_native_stroke':dict(name='TikTok Native · black stroke',font='Proxima Nova',file='@proxima',size=66,outline=5,shadow=0,case='sentence',color='#FFFFFF'),
 'white':dict(name='White text',font='Montserrat',file='Montserrat-Bold.ttf',size=64,outline=0),
 'reference':dict(name='Reference · white outline',font='Montserrat ExtraBold',file='Montserrat-ExtraBold.ttf',size=64,outline=4,case='sentence'),
 'classic':dict(name='Classic bold',font='Montserrat',file='Montserrat-Bold.ttf',size=64,outline=3),
 'clean':dict(name='Clean subtitle',font='Montserrat',file='Montserrat-Bold.ttf',size=52,outline=1,case='sentence'),
 'box':dict(name='Black box · white text',font='Montserrat',file='Montserrat-Bold.ttf',size=64,outline=0,box='#000000'),
 'word_box':dict(name='Box follows words',font='Montserrat',file='Montserrat-Bold.ttf',size=64,outline=2,box='#000000',active=True,reaction_word_box=True),
 'grey':dict(name='Grey rounded box',font='Montserrat',file='Montserrat-Bold.ttf',size=64,outline=0,box='#777777',radius=14),
 'white_box':dict(name='White rounded box',font='Montserrat ExtraBold',file='Montserrat-ExtraBold.ttf',size=64,outline=0,box='#FFFFFF',color='#000000',radius=14,case='sentence'),
 'outlined':dict(name='Strong outline',font='Montserrat ExtraBold',file='Montserrat-ExtraBold.ttf',size=70,outline=5),
 'yellow':dict(name='Yellow text',font='Montserrat ExtraBold',file='Montserrat-ExtraBold.ttf',size=76,outline=3,color='#FFE800'),
 'yellow_box':dict(name='Yellow box',font='Montserrat',file='Montserrat-Bold.ttf',size=64,outline=0,color='#000000',box='#FFE800'),
 'orange_box':dict(name='Orange rounded box',font='Montserrat ExtraBold',file='Montserrat-ExtraBold.ttf',size=68,outline=2,box='#FF6A00',radius=14),
 'karaoke':dict(name='Active word',font='Montserrat ExtraBold',file='Montserrat-ExtraBold.ttf',size=72,outline=3,highlight='#FFE800',active=True),
 'orange_highlight':dict(name='Orange active word',font='Montserrat ExtraBold',file='Montserrat-ExtraBold.ttf',size=72,outline=3,highlight='#FF9500',active=True),
 'impact':dict(name='Impact bold',font='Anton',file='Anton-Regular.ttf',size=88,outline=4),
 'none':dict(name='No captions',font='Montserrat',file='Montserrat-Bold.ttf',size=64,outline=0),
}
def clean_text(text,strip_edges=True,punctuation=False):
 # Display-only: transcript punctuation remains intact for sentence matching.
 text=str(text)
 if punctuation:
  text=re.sub(r'[\[\]{}\\/]+','',text)
 else:
  # Decimal points are numeric content, not optional sentence punctuation.
  text=re.sub(r'(?<=\d)\.(?=\d)','\uE000',text)
  text=re.sub(r'[.!?…;:"“”«»()\[\]{}\\/]+','',text).replace('\uE000','.')
 text=re.sub(r'(?<=\w)[-\u2010-\u2015](?=\w)','-',text)
 text=re.sub(r'(?<!\w)[-\u2010-\u2015]+|[-\u2010-\u2015]+(?!\w)',' ',text)
 text=re.sub(r'\s+',' ',text).strip()
 # Thousands separators are part of the amount, not a phrase comma.
 source=text
 def comma(match):
  left=source[:match.start()].rstrip();right=source[match.end():]
  return ',' if left[-1:].isdigit() and re.match(r'\d{3}(?:\D|$)',right) else ', ' if punctuation else ' '
 text=re.sub(r'\s*,\s*',comma,text)
 return text.strip() if punctuation else text.strip(' ,') if strip_edges else text
def color(value,default='#FFFFFF'):
 return value.upper() if re.fullmatch(r'#[0-9a-fA-F]{6}',str(value)) else default
def ass_color(value):
 value=color(value);return '&H00'+value[5:7]+value[3:5]+value[1:3]
def stamp_ticks(n):
 h,n=divmod(n,360000);m,n=divmod(n,6000);s,c=divmod(n,100)
 return f'{h}:{m:02}:{s:02}.{c:02}'

def stamp(t,cut=False):
 return stamp_ticks(math.floor(t*100+1e-7) if cut else round(t*100))

def timed_events(states,precision):
 """Validate AFTER timestamp quantization, as required by ASS/SRT renderers.

 A positive fractional frame can collapse to a zero-duration ASS event. In
 libass/FFmpeg that event can also suppress the opening caption. Skip internal
 sub-tick events; round the final endpoint outwards to cover the last frame.
 """
 valid=[s for s in states if math.isfinite(s['start']) and math.isfinite(s['end']) and s['end']>s['start']]
 final_end=max((s['end'] for s in valid),default=0.)
 for state in valid:
  start=math.floor(state['start']*precision+1e-7) if state.get('start_at_cut',False) else round(state['start']*precision)
  end=math.floor(state['end']*precision+1e-7) if state.get('end_at_cut',False) else round(state['end']*precision)
  if abs(state['end']-final_end)<1e-8:end=math.ceil(state['end']*precision-1e-7)
  if end>start:yield state,start,end

@lru_cache(maxsize=128)
def font(file,size):return ImageFont.truetype(str(font_path(file)),int(size))

def font_path(file):
 if file=='@proxima':
  from .caption_fonts import proxima_font
  return proxima_font(BASE,globals().get('PROXIMA_WEIGHT') or None)
 return BASE/'fonts'/file
@lru_cache(maxsize=128)
def face_name(face):
 family,weight=face.getname()
 if 'proxima' in family.lower():
  # Some Proxima files use different Windows/Mac full names. libass resolves
  # their PostScript name reliably; the PIL family+weight alias can fall back
  # silently to Arial even when the correct font has been loaded.
  data=Path(face.path).read_bytes()
  for i in range(struct.unpack_from('>H',data,4)[0]):
   tag,_,offset,length=struct.unpack_from('>4sIII',data,12+i*16)
   if tag!=b'name':continue
   _,count,storage=struct.unpack_from('>HHH',data,offset)
   for j in range(count):
    platform,encoding,language,name,length,start=struct.unpack_from('>6H',data,offset+6+j*12)
    if name==(6 if data[:4]==b'OTTO' else 4) and (data[:4]==b'OTTO' or platform in (0,3)):
     return data[offset+storage+start:offset+storage+start+length].decode('utf-16-be' if platform in (0,3) else 'latin1')
 return family if weight=='Regular' or family.endswith(weight) else family+' '+weight
def rounded(width,height,radius):
 w,h=width,height;r=min(radius,w/2,h/2);k=r*.55228475
 return f'm {r:.2f} 0 l {w-r:.2f} 0 b {w-r+k:.2f} 0 {w:.2f} {r-k:.2f} {w:.2f} {r:.2f} l {w:.2f} {h-r:.2f} b {w:.2f} {h-r+k:.2f} {w-r+k:.2f} {h:.2f} {w-r:.2f} {h:.2f} l {r:.2f} {h:.2f} b {r-k:.2f} {h:.2f} 0 {h-r+k:.2f} 0 {h-r:.2f} l 0 {r:.2f} b 0 {r-k:.2f} {r-k:.2f} 0 {r:.2f} 0'
@lru_cache(maxsize=16)
def ass_metrics(file):
 # Same SFNT/Windows metrics as Reaction Editor V17.2.34.
 data=font_path(file).read_bytes();base=struct.unpack_from('>I',data,12)[0] if data[:4]==b'ttcf' else 0
 tables={}
 for i in range(struct.unpack_from('>H',data,base+4)[0]):
  tag,_,offset,length=struct.unpack_from('>4sIII',data,base+12+i*16);tables[tag]=offset
 em=struct.unpack_from('>H',data,tables[b'head']+18)[0];asc,desc=struct.unpack_from('>HH',data,tables[b'OS/2']+74)
 if not asc+desc:raise ValueError('Invalid font metrics')
 return em,asc,desc

@lru_cache(maxsize=8192)
def text_length(face,text):return face.getlength(text)

@lru_cache(maxsize=8192)
def ink_box(face,text):
 # Pathological transcript tokens must not allocate a huge 1024px glyph bitmap.
 if len(str(text))>80:return face.getbbox(str(text),anchor='ls')
 try:
  mask,offset=face.getmask2(str(text),mode='L',anchor='ls');bounds=mask.getbbox()
  if bounds:return tuple(offset[i%2]+bounds[i] for i in range(4))
 except (AttributeError,TypeError,ValueError):pass
 return face.getbbox(str(text),anchor='ls')

def reaction_word_layout(text,style,size,y,active,width=880,canvas=(1080,1920),_fit_only=False):
 """Keep the original one-line look; wrap long phrases at the selected size."""
 cw,ch=canvas
 face=font(style['file'],1024);em,asc,desc=ass_metrics(style['file']);per_point=em/(1024.0*(asc+desc))
 advance=max(1.0,text_length(face,text))*per_point;fs=max(1,min(int(size),int(width/advance)))
 if fs<int(size):
  # The former one-line fit made this style ignore large size settings.
  # Use the shared two-line renderer only when a single line cannot fit.
  return layout(text,{**style,'reaction_word_box':False,'reaction_multiline_box':True},size,y,active,width,canvas,_fit_only)
 if _fit_only:return fs
 scale=fs*per_point;raw_width=text_length(face,text)*scale;items=text.split()
 y=max(40+fs,min(ch-40-fs,float(y)))
 if active is None or not 0<=active<len(items):return []
 token=items[active];prefix=(' '.join(items[:active])+' ') if active else ''
 glyph=ink_box(face,token);origin=text_length(face,prefix)*scale
 left=origin+glyph[0]*scale;right=origin+glyph[2]*scale
 box_center=max(40.0,min(cw-40.0,cw/2+(left+right)/2-raw_width/2))
 cap=ink_box(face,'H');glyph_height=max(glyph[3]-glyph[1],cap[3]-cap[1])*scale+4
 pad_x=8.0;pad_y=max(5.0,min(9.0,fs*.055))
 bw=max(24.0,min(cw-120.0,right-left+2*pad_x));bh=max(30.0,glyph_height+2*pad_y)
 bx=max(0.0,min(cw-bw,box_center-bw/2));baseline=y+fs*(asc-desc)/(2*(asc+desc))
 ink_center=baseline+(glyph[1]+glyph[3])*scale/2;by=ink_center-bh/2
 radius=min(13.0,bh*.18,bw*.22)
 vector=r'{\an7\pos('+f'{bx:.2f},{by:.2f}'+r')\c'+ass_color(style.get('box','#000000'))+r'\p1}'+rounded(bw,bh,radius)+r'{\p0}'
 # A bundled Bold face is already bold. Do not synthesize another bold weight.
 family=face_name(face)
 letters=r'{\an5\pos('+f'{cw/2:g},{y:.2f}'+r')\fn'+family+r'\fs'+str(fs)+r'\fscx100\fscy100\b0\bord2\shad0\3c'+ass_color(style.get('outline_color','#000000'))+r'\3c'+ass_color(style.get('outline_color','#000000'))+r'\c'+ass_color(style.get('color','#FFFFFF'))+'}'+text
 return [(0,'Draw',vector),(1,'Main',letters)]

def layout(text,style,size,y,active=None,width=880,canvas=(1080,1920),_fit_only=False,_line_count=False):
 cw,ch=canvas
 text=re.sub(r'[{}\\]','',str(text)).strip() if style.get('headline') else clean_text(text,punctuation=style.get('punctuation',False));text=text if style.get('case')=='sentence' else text.upper()
 if not text:return int(size) if _fit_only else []
 if style.get('reaction_word_box'):
  if _line_count:return layout(text,{**style,'reaction_word_box':False},size,y,active,width,canvas,_line_count=True)
  return reaction_word_layout(text,style,size,y,active,width,canvas,_fit_only)
 size=int(size);f=font(style['file'],1024);em,asc,desc=ass_metrics(style['file']);scale=size*em/(1024.0*(asc+desc))
 measure=lambda value:text_length(f,value)*scale
 words=text.split()
 if not style.get('headline'):
  from .caption_fixed import lines as fixed_lines
  limit=min(width,cw-2*(40+16+style.get('outline',0)))
  lines=fixed_lines(words,measure,limit,style)
  if lines is None:
   if _fit_only or _line_count:return 0
   raise ValueError(f'Caption cannot fit at size {size}; choose a smaller caption size. Text size was kept unchanged.')
 else:
  words=text.split();lines=[];line=[]
  if style.get('max_lines',2)==1:
   # Keep every phrase on one line. Preparation first chooses shorter coherent
   # phrases; only an indivisible phrase must fit at a smaller font size.
   if measure(text)>width and size>1:return layout(text,style,max(1,size-2),y,active,width,canvas,_fit_only)
   lines=[words]
  for word in words:
   if style.get('max_lines',2)==1:break
   if line and measure(' '.join(line+[word]))>width:lines.append(line);line=[]
   line.append(word)
  if line:lines.append(line)
  if len(lines)>1 and not style.get('headline'):
   from .caption_phrases import WEAK,STARTERS,token
   from .caption_language import boundaries
   protected,_=boundaries([{'text':word} for word in words])
   from .caption_numbers import boundaries as number_boundaries
   numeric=number_boundaries(words)
   choices=[]
   for cut in range(1,len(words)):
    if cut in protected:continue
    left,right=words[:cut],words[cut:]
    if any(len(side)==1 and (token({'text':side[0]}) in WEAK or len(side[0])<=4) for side in (left,right)):continue
    a,b=measure(' '.join(left)),measure(' '.join(right))
    if max(a,b)>width:continue
    tail,head=token({'text':left[-1]}),token({'text':right[0]})
    penalty=8 if tail in WEAK or tail.endswith('ing') and head not in STARTERS else 0
    if head in STARTERS:penalty-=1
    choices.append((abs(a-b)/width+penalty,cut))
   if choices:
    cut=min(choices)[1];lines=[words[:cut],words[cut:]]
   elif any(cut not in numeric and max(measure(' '.join(words[:cut])),measure(' '.join(words[cut:])))<=width for cut in range(2,len(words)-1)):
    # Keep the selected font size when a long technical phrase has no
    # grammatically ideal line break. Two balanced lines read better than a
    # suddenly smaller one-line caption.
    cut=min((abs(measure(' '.join(words[:cut]))-measure(' '.join(words[cut:]))) / width,cut)
            for cut in range(2,len(words)-1)
            if cut not in numeric and max(measure(' '.join(words[:cut])),measure(' '.join(words[cut:])))<=width)[1]
    lines=[words[:cut],words[cut:]]
   elif size>1:
    return layout(text,style,max(1,size-2),y,active,width,canvas,_fit_only)
  if style.get('line_break') and style.get('max_lines',2)!=1:
   cut=int(style['line_break']);lines=[words[:cut],words[cut:]]
  if len(lines)>2 or max(measure(' '.join(l)) for l in lines)>width:
   if size>1:return layout(text,style,max(1,size-2),y,active,width,canvas,_fit_only)
  # Include actual font ink, box padding and outlines in the safe-area bound.
  margin=40;pad=16+style.get('outline',0)
  if max(measure(' '.join(l)) for l in lines)>cw-2*(margin+pad) and size>1:return layout(text,style,max(1,size-2),y,active,width,canvas,_fit_only)
 margin=40;pad=16+style.get('outline',0)
 if _line_count:return len(lines)
 # Fit probes only need the final size; rasterize glyphs when drawing.
 if _fit_only:return size
 # Separate baselines by the visible glyph height plus a small readable gap.
 # Font point height includes large ascender/descender padding in this face.
 ink_height=max(ink_box(f,' '.join(items))[3]-ink_box(f,' '.join(items))[1] for items in lines)*scale
 lineheight=ink_height+(6 if style.get('box') else max(5,size*.10)+2*style.get('outline',0))
 if style.get('native_bubble'):lineheight=max(ink_height+size*.10,size*1.08)
 extent=(len(lines)-1)*lineheight/2+size+pad
 y=max(margin+extent,min(ch-margin-extent,float(y)))
 rows=[];count=0;native_boxes=[]
 for li,items in enumerate(lines):
  value=' '.join(items);w=measure(value);cy=y+(li-(len(lines)-1)/2)*lineheight
  if not style.get('headline'):
   glyph=ink_box(f,value)
   cy-=size*(asc-desc)/(2*(asc+desc))+(glyph[1]+glyph[3])*scale/2
  if style.get('box'):
   glyph=ink_box(f,value);bx=cw/2-w/2+glyph[0]*scale;bw=(glyph[2]-glyph[0])*scale
   if active is not None:
    local=active-count
    if 0<=local<len(items):
     glyph=ink_box(f,items[local]);prefix=' '.join(items[:local])+(' ' if local else '')
     bx=cw/2-w/2+measure(prefix)+glyph[0]*scale;bw=(glyph[2]-glyph[0])*scale
    else:bw=0
   if bw:
    pad=size*.38 if style.get('native_bubble') else 8 if style.get('reaction_multiline_box') else 12
    pad_y=size*.55 if style.get('native_bubble') else 6
    bh=(glyph[3]-glyph[1])*scale+2*pad_y;baseline=cy+size*(asc-desc)/(2*(asc+desc));by=baseline+glyph[1]*scale-pad_y
    radius=min(size*.35,bh/2,(bw+pad*2)/2) if style.get('native_bubble') else min(13.0,bh*.18,(bw+pad*2)*.22) if style.get('reaction_multiline_box') else style.get('radius',7)
    path=rounded(bw+pad*2,bh,radius)
    if style.get('native_bubble'):native_boxes.append((bx-pad,by,bw+pad*2,bh,radius))
    else:rows.append((0,'Draw',r'{\an7\pos('+f'{bx-pad:.2f},{by:.2f}'+r')\c'+ass_color(style['box'])+r'\p1}'+path+r'{\p0}'))
  prefix=r'{\an5\pos('+f'{cw/2:g},{cy:.2f}'+r')\fn'+face_name(f)+r'\fs'+str(size)+r'\b0\bord'+str(style.get('outline',0))+r'\shad0\3c'+ass_color(style.get('outline_color','#000000'))+r'\c'+ass_color(style.get('color','#FFFFFF'))+'}'
  if style.get('emphasis_indices'):
   value=' '.join(r'{\c'+ass_color(style.get('emphasis_color','#FFE800') if count+j in style['emphasis_indices'] else style.get('color','#FFFFFF'))+'}'+word for j,word in enumerate(items))
  elif active is not None and style.get('highlight'):
   pieces=[]
   for j,word in enumerate(items):pieces.append(r'{\c'+ass_color(style['highlight'] if count+j==active else style.get('color','#FFFFFF'))+'}'+word)
   value=' '.join(pieces)
  if float(style.get('shadow_opacity',60))>0 and (float(style.get('shadow',0))>0 or float(style.get('shadow_blur',0))>0):
   d=float(style.get('shadow',0))*.7;alpha='&H%02X&'%round(255*(1-float(style.get('shadow_opacity',60))/100));sc=ass_color(style.get('shadow_color','#000000'))
   rows.append((1,'Main',r'{\an5\pos('+f'{cw/2+d:.2f},{cy+d:.2f}'+r')\fn'+face_name(f)+r'\fs'+str(size)+r'\b0\bord'+str(style.get('outline',0))+r'\shad0\blur'+f"{float(style.get('shadow_blur',0)):g}"+r'\c'+sc+r'\3c'+sc+r'\1a'+alpha+r'\3a'+alpha+'}'+re.sub(r'\{[^}]*\}','',value)))
  rows.append((1,'Main',prefix+value));count+=len(items)
 if native_boxes:
  from .caption_native import bubble
  rows=bubble(native_boxes,style['box'])+rows
 return rows


def fit_groups(p,groups,stop=None,update=None):
 from .caption_colors import style as colored_style
 from .caption_fixed import fit
 style=colored_style(p,PRESETS);cw,ch=p.get('_caption_canvas',frame_size(p));size=int(float(p.get('caption_size',style['size'])))
 return fit(p,groups,style,size,cw,ch,stop,update)

def one_line_groups(p,groups,style,size,cw,ch,stop=None):
 from .caption_fixed import fit
 return fit(p,groups,style,size,cw,ch,stop)

def phrase_groups(words):
 # Compatibility for integrations: the old greedy grouper is retired.
 from .caption_phrases import smart_groups
 return smart_groups(words,max_words=8)

def caption_states(p,limit=None,stop=None,update=None):
 from .caption_timeline import prepare
 p=prepare(p)
 key=p.get('caption','classic')
 if key=='none':return []
 from .caption_colors import style as colored_style
 style=colored_style(p,PRESETS);states=[]
 if style.get('active') and not style.get('reaction_word_box'):
  style['highlight']=color(style['highlight'])
 # One shared, versioned phrase clock for every caption style and export path.
 for group in p.get('_caption_flow_groups',[]):
  a,b=group['start'],group['end'];points=[(a,None)]
  if style.get('active'):
   points=[(a,0)]+[(max(a,min(b,round(w['start']*30)/30)),i) for i,w in enumerate(group['words'][1:],1)]
   points=list(dict(points).items())
  for i,(start,active) in enumerate(points):
   end=points[i+1][0] if i+1<len(points) else b
   if end>start:states.append(dict(start=start,end=end,text=group['text'],active=active,start_at_cut=True,end_at_cut=True,line_break=group.get('line_break',0)))
 cw,ch=frame_size(p)
 requested=float(p.get('caption_size',style['size']))
 y=ch-float(p.get('caption_y',740))*ch/1920
 width=cw-200
 # Each phrase uses the selected size. The layout may reduce an exceptional
 # oversized phrase to keep it within two lines, without shrinking the rest
 # of the video. Preview and full export therefore share the same sizing.
 if limit is not None:states=[{**state,'end':min(state['end'],limit)} for state in states if state['start']<limit]
 for index,state in enumerate(states):
  if stop is not None and stop.is_set():raise InterruptedError('Cancelled')
  if update and (index%10==0 or index+1==len(states)):update(f'Drawing caption {index+1}/{len(states)}',100*(index+1)/max(1,len(states)))
  state['rows']=[(layer+2,name,text) for layer,name,text in layout(state['text'],{**style,'line_break':state.get('line_break',0)},requested,y,state['active'],width=width,canvas=(cw,ch))]
 return states


def headline_states(p):
 from .caption_timeline import prepare
 p=prepare(p)
 cw,ch=frame_size(p)
 style=dict(headline=True,case='upper' if p.get('headline_case')=='upper' else 'sentence',font='Montserrat ExtraBold',file='Montserrat-ExtraBold.ttf',outline=4 if p.get('headline_box_style')=='none' else 0,color=color(p.get('headline_text_color','#FFFFFF')))
 if p.get('headline_box_style','rounded')!='none':style.update(box=color(p.get('headline_box_color','#000000')),radius=16 if p.get('headline_box_style','rounded')=='rounded' else 0)
 states=[]
 from .headline_timing import intervals
 for hook,start,end in intervals(p):
   text=re.sub(r'[{}\\]','',hook['headline']).strip()
   if p.get('headline_case')=='upper':text=text.upper()
   from .export_finish import default_emphasis
   emphasis=hook.get('emphasis') or default_emphasis(text)
   indices=set();tokens=text.split();normalized=[re.sub(r'[^\w\u2019\u0027]','',t).casefold() for t in tokens]
   for phrase in str(emphasis).split(','):
    parts=[re.sub(r'[^\w\u2019\u0027]','',t).casefold() for t in phrase.split()]
    if not parts:continue
    for i in range(len(tokens)-len(parts)+1):
     if normalized[i:i+len(parts)]==parts:indices.update(range(i,i+len(parts)))
   hs={**style,'emphasis_indices':indices,'emphasis_color':color(p.get('headline_emphasis_color','#FFE800'))}
   states.append(dict(start=start,end=end,text=text,start_at_cut=True,end_at_cut=True,rows=layout(text,hs,float(p.get('headline_size',88)),float(p.get('headline_y',350))*ch/1920,width=cw-160,canvas=(cw,ch))))
 return states

def write_ass(path,states,width=1080,height=1920):
 header='''[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920
WrapStyle: 2
ScaledBorderAndShadow: yes
[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Main,Montserrat,64,&H00FFFFFF,&H00FFFFFF,&H00000000,&H00000000,-1,0,0,0,100,100,0,0,1,2,0,5,0,0,0,1
Style: Draw,Montserrat,10,&H00000000,&H00000000,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,0,0,7,0,0,0,1
[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
'''
 header=header.replace('PlayResX: 1080',f'PlayResX: {width}').replace('PlayResY: 1920',f'PlayResY: {height}')
 for state,start,end in timed_events(states,100):
  for layer,style,text in state['rows']:header+=f'Dialogue: {layer},{stamp_ticks(start)},{stamp_ticks(end)},{style},,0,0,0,,{text}\n'
 Path(path).write_text(header,encoding='utf8')
def srt(path,states):
 def st(n):
  h,n=divmod(n,3600000);m,n=divmod(n,60000);s,ms=divmod(n,1000);return f'{h:02}:{m:02}:{s:02},{ms:03}'
 text=''
 for i,(state,start,end) in enumerate(timed_events(states,1000),1):text+=f'{i}\n{st(start)} --> {st(end)}\n{state["text"]}\n\n'
 Path(path).write_text(text,encoding='utf8')
