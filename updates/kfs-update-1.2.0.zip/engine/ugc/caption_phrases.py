"""Offline language-aware caption breaks; preserve words and measured timing."""
import re,copy
from difflib import SequenceMatcher

NUMBERS=set('one two three four five six seven eight nine ten'.split())
WEAK=set("a an the this these those my your her his our their its to for of in on with at from by and but or is are was were be been being that who which if because than as".split())
WEAK.update({"don't","doesn't","didn't","won't","can't","couldn't","shouldn't","wouldn't","isn't","aren't","wasn't","weren't","i'm","you're","we're","they're","it's","that's","not","have","has","had"})
WEAK.update({'through','over','under','into','onto','during','without','until','about','against','between'})
WEAK.update({'so','then'})
WEAK.update({'toward','towards','before','after','around','across','beyond','within','whether','what','where','when','while'})
STARTERS=set('a an the this these those my your her his our their its of in on for from with because but then when if so and or that who which'.split())
STARTERS.add('while')

def token(w):return str(w['text']).lower().replace('’',"'").strip(' ,.!?;:…\"“”')
def chapter(words,i):
 return i+1<len(words) and token(words[i])=='step' and (token(words[i+1]) in NUMBERS or re.fullmatch(r'\d{1,2}',token(words[i+1])))
def initialism(raw):
 raw=str(raw).strip(' \"“”');letters=re.sub(r'[^A-Za-z]','',raw)
 return bool(letters and letters.isupper() and len(letters)<=4 and '.' in raw and (len(letters)==1 or '.' in raw.rstrip('.')))

def terminal(w):return bool(re.search(r'[.!?][\"”]*$',w.get('raw',w['text']))) and not initialism(w.get('raw',w['text'])) and token(w) not in WEAK|{'mr','mrs','dr','ms'}

def clause_start(words,i):
 """Strong punctuation starts a new thought, not an arbitrary SRT row."""
 if not 0<i<len(words):return False
 left=words[i-1];raw=left.get('raw',left['text'])
 if i>=3 and re.search(r':[\"”]*$',raw) and token(left) not in WEAK:return True
 if not re.search(r'[,;][\"”]*$',raw):return False
 subjects={'i','we','you','he','she','it','they',"i'm","i'll","i've","we're","we'll","you've","you're","he's","she's","it's","they're"}
 right=token(words[i])
 return right in {'the','a','an','each'} and i>=3 and token(left) not in WEAK or right in subjects or right in {'and','but','so'} and any(token(w) in subjects for w in words[i+1:i+4])

def caption_words(p):
 """Recover only punctuation hints from matching script spans, never its words."""
 from .sentences import transcript_words
 words=copy.deepcopy(transcript_words(p.get('cues',[])))
 # Legacy pause flags are acoustic hints, not grammatical boundaries.
 for w in words:w.pop('caption_break_before',None)
 sources=[str(p.get('original_script',''))]+[str(s) for s in p.get('segment_scripts',{}).values()]
 for name in ('story_brief','visual_brief'):
  brief=p.get(name,{})
  if isinstance(brief,dict):sources += [s.get('spoken','') for s in brief.get('sections',brief).values() if isinstance(s,dict)]
 key=lambda text:re.sub(r'[^\w]', '',str(text).casefold().replace('’',"'"))
 observed=[key(w['text']) for w in words]
 for source in sources:
  script=[t for t in str(source).split() if re.search(r'\w',t)]
  if not script:continue
  match=SequenceMatcher(None,observed,[key(w) for w in script],autojunk=False)
  for block in match.get_matching_blocks():
   if block.size<3:continue
   for k in range(block.size):
    i,j=block.a+k,block.b+k
    words[i]['raw']=script[j]
    if j and re.search(r'[.!?][\"”]*$',script[j-1]) and not initialism(script[j-1]) and script[j-1].lower().strip('.!?,') not in {'mr','mrs','dr','ms'} and (k or block.a==0):words[i]['caption_break_before']=True
 # Exact script alignment certifies real sentence endings, including main
 # verbs such as "have.". Legacy chopped ASR/SRT fragments stay conservative.
 if p.get('script_alignment'):
  for left,right in zip(words,words[1:]):
   if re.search(r'[.!?][\"”]*$',left.get('raw',left['text'])) and not initialism(left.get('raw',left['text'])) and token(left) not in {'mr','mrs','dr','ms'}:
    right['caption_break_before']=True
 return words

def language_edges(words):
 """Allowed cuts use the whole sentence, never a shot-truncated parse."""
 n=len(words);hard={0,n};labels=set()
 from .caption_language import boundaries
 protected,hints=boundaries(words);hints=dict(hints)
 for i,w in enumerate(words):
  if w.get('caption_break_before'):hard.add(i)
  if terminal(w):hard.add(i+1)
  # A spoken introduction ending in a colon belongs before its list,
  # rather than carrying the first command onto the introduction card.
  if clause_start(words,i):hard.add(i)
  if chapter(words,i):hard.update((i,i+2));labels.add((i,i+2))
  if i>=2 and token(w).endswith('ing') and token(words[i-1]) in {'started','began','start','begin'} and token(words[i-2]) in {'i','we'}:hard.add(i)
 pairs={('like',"you're"),('like','you'),('like','that'),('you','are'),('no','matter'),('matter','what'),('as','well'),('even','though'),('rather','than'),('such','as'),('up','to'),('down','there'),('over','there')}
 modifiers=set('best better worst natural swollen synthetic American small big real new flat'.lower().split())
 safe={0,n}
 from .caption_numbers import boundaries as number_boundaries
 numeric=number_boundaries([w.get('raw',w['text']) for w in words])
 for j in range(1,n):
  left,right=token(words[j-1]),token(words[j])
  stranded=left in {'for','with','to','from'} and right in {'who','which','that'} and ',' in words[j-1].get('raw',words[j-1]['text'])
  before_stranded=j+1<n and right in {'for','with','to','from'} and token(words[j+1]) in {'who','which','that'}
  verb_prep=left in {'on','for','about'} and j>=3 and token(words[j-2]) in {'it','this','that'}
  if verb_prep:hints[j]=min(hints.get(j,0),-8)
  if j in numeric:
   hard.discard(j);continue
  if j in hard or stranded or verb_prep or hints.get(j,0)<=-15 or not (before_stranded or j in protected or left in WEAK or left in modifiers or (left,right) in pairs or left=='step'):safe.add(j)
 return hard,labels,hints,safe

def smart_groups(words,max_words=None,required=(),_relaxed=False,force_cuts=False):
 """Optimize phrases with full context; only valid fixed cuts are accepted."""
 if not words:return []
 # A soft target controls cadence; grammar and acoustic pauses decide the cut.
 target=4 if max_words==4 else 4.5
 max_words=len(words)
 n=len(words);hard,labels,hints,safe=language_edges(words)
 if force_cuts:safe.update(required)
 elif set(required)-safe:raise ValueError('A fixed visual cut splits a caption phrase.')
 hard.update(required)
 cost=[float('inf')]*(n+1);paths=[None]*(n+1);cost[0]=0
 for i in range(n):
  if i and paths[i] is None:continue
  for j in range(i+1,min(n,i+max_words)+1):
   if any(i<edge<j for edge in hard):break
   k=j-i;left=token(words[j-1]);right=token(words[j]) if j<n else ''
   if j not in hard and j not in safe and not _relaxed:continue
   # Conjunctions introduce the following clause, never finish the prior card.
   if k==1 and n>1 and (i,j) not in labels and not (i in hard and j in hard) and not _relaxed:continue
   if k>2 and (len(" ".join(w["text"] for w in words[i:j]))>110 or words[j-1]["end"]-words[i]["start"]>3.5) and j not in hard and j in safe:continue
   score=3+(k-target)**2*.35
   if j not in safe:score+=80+(1000 if left in WEAK else 0)
   if j<n:
    pause=max(0,float(words[j].get('start',0))-float(words[j-1].get('end',0)))
    score-=min(12,pause*20)
   # Sentence punctuation does not make a dangling final word readable.
   # Single-word sentences remain available; larger blocks prefer a phrase.
   if k==1 and n>1 and (i,j) not in labels:score+=40
   duration=words[j-1]['end']-words[i]['start']
   if duration>2.6:score+=(duration-2.6)*3
   if duration<.50 and (i,j) not in labels:score+=(.50-duration)*20
   if j<n:
    score+=hints.get(j,0)
    if left.endswith('ing') and right not in STARTERS:score+=10
    if right in STARTERS:score-=2.5
    if right in {'and','but','because','when','if','so','then'}:score-=6
    if right in {'that','who','which'}:score-=7
    if re.search(r'[,;:][\"”]*$',words[j-1].get('raw',words[j-1]['text'])):score-=5
   value=cost[i]+score
   if value<cost[j]:cost[j]=value;paths[j]=i
 # Long indivisible noun/verb phrases can exceed the compact target. Expand
 # the target before permitting a dangling article or dropping any token.
 if paths[n] is None:
  if not _relaxed:return smart_groups(words,None,required,True,force_cuts)
  raise ValueError('Unable to group the caption word stream.')
 result=[];j=n
 while j:
  i=paths[j];result.append(words[i:j]);j=i
 return list(reversed(result))

def scene_windows(p):
 """Use the same cumulative 30fps boundaries as final picture rendering."""
 duration=float(p.get('duration') or max((c.get('end',0) for c in p.get('cues',[])),default=0))
 cuts={0.,duration}
 for s in p.get('scenes',[]):
  cuts.update(max(0,min(duration,round(float(s[k])*30)/30)) for k in ('start','end'))
 for s in p.get('media_segments',[]):
  cuts.update(max(0,min(duration,round(float(s[k])*30)/30)) for k in ('start','end') if k in s)
 cuts=sorted(cuts)
 return [(a,b) for a,b in zip(cuts,cuts[1:]) if b>a]

def assign_windows(words,windows):
 """Each token belongs to one picture interval, using its spoken onset.

 A word straddling a cut stays with the scene in which it started; it is
 never copied onto the next scene. No-word intervals intentionally stay blank.
 """
 result=[[] for _ in windows];i=0;previous=None;previous_owner=0
 numbers=set('one two three four five six seven eight nine ten'.split())
 for w in words:
  while i+1<len(windows) and w['start']>=windows[i][1]-1e-8:i+=1
  owner=i
  # A spoken chapter label is atomic even if its word alignment straddles
  # the card's cut: do not leave a lone "one" on the following illustration.
  if previous and token(previous)=='step' and (token(w) in numbers or re.fullmatch(r'\d{1,2}',token(w))):owner=previous_owner
  if windows and (owner!=i or w['start']<windows[i][1] and w['end']>windows[i][0]):result[owner].append(w)
  previous=w;previous_owner=owner
 return result
