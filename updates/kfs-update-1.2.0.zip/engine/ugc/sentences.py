"""Transcript-preserving sentence boundaries. AI returns indices, never rewritten speech."""
import hashlib,json,re

def signature(cues):
 return hashlib.sha256(json.dumps(cues,sort_keys=True).encode()).hexdigest()

def transcript_words(cues):
 from .core import word_units
 result=[]
 for entry in word_units(cues):
  parts=entry['text'].split()
  for i,part in enumerate(parts):
   result.append({'start':entry['start']+(entry['end']-entry['start'])*i/len(parts),'end':entry['start']+(entry['end']-entry['start'])*(i+1)/len(parts),'text':part,**({'caption_break_before':True} if i==0 and entry.get('caption_break_before') else {})})
 return result

def sentence_ranges(words,cues,analysis=None,prefer_punctuation=False):
 if not words:return []
 if analysis:
  ends=[s['end_word'] for s in analysis['sentences']]
 else:
  ends=[]
  for i,w in enumerate(words):
   terminal=bool(re.search(r'[.!?]["\u201d\u2019]*$',w['text']))
   abbreviation=w['text'].lower() in {'mr.','mrs.','dr.','ms.','e.g.','i.e.'}
   if terminal and not abbreviation:ends.append(i)
   elif not prefer_punctuation and i+1<len(words) and words[i+1]['start']-w['end']>.75:ends.append(i)
  if not ends: # No punctuation: retain cue boundaries as an explicit fallback.
   for c in cues:
    indices=[i for i,w in enumerate(words) if w['start']<c['end'] and w['end']>c['start']]
    if indices:ends.append(indices[-1])
  if not ends or ends[-1]!=len(words)-1:ends.append(len(words)-1)
 ranges=[];start=0
 for end in sorted(set(ends)):
  if end<start:continue
  ranges.append((start,end));start=end+1
 return ranges

def validate_analysis(data,words):
 rows=data.get('sentences')
 if not isinstance(rows,list) or not rows:raise ValueError('AI did not return sentences; original project preserved')
 last=-1
 for row in rows:
  end=row.get('end_word')
  if type(end) is not int or end<=last or end>=len(words):raise ValueError('Invalid AI sentence indices; original project preserved')
  if row.get('kind') not in ('ugc','animation','ingredient','product'):raise ValueError('Invalid AI visual type')
  if not isinstance(row.get('visual'),str) or not isinstance(row.get('keywords'),str):raise ValueError('Invalid AI visual description')
  # Prevent model instructions or verbose text from silently ballooning future requests.
  row['visual']=row['visual'][:500];row['keywords']=row['keywords'][:300]
  last=end
 if last!=len(words)-1:raise ValueError('AI omitted transcript words; original project preserved')
 return data
