"""Compatibility for saved manual groups: no arbitrary word ceiling."""
def limit_groups(groups):
 return groups
