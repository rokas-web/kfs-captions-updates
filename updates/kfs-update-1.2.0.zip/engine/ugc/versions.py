"""Separate hook inputs + one body, and interval-safe per-hook version timelines."""
import copy,hashlib,json,re
from pathlib import Path
from . import media
from .core import VIDEO
from .hook_limits import MAX_HOOKS

def safe_name(name):return re.sub(r'[^A-Za-z0-9_-]+','_',str(name)).strip('_')[:60] or 'Version'
def assemble(studio,id,data,stop,update):
 hookpaths=data.get('hooks',[]);body=data.get('body','')
 if not isinstance(hookpaths,list) or not 1<=len(hookpaths)<=MAX_HOOKS:raise ValueError('Choose 1–50 separate hook files and one body file')
 p=studio.load(id);inputs=[];video_mode=p['source_type']=='talking' and p.get('workflow')!='captions'
 brief=p.get('caption_brief') if p.get('workflow')=='captions' else p.get('visual_brief') if p.get('workflow')=='montage' else None
 if brief and len(hookpaths)!=len(brief['hooks']):raise ValueError('Choose exactly '+str(len(brief['hooks']))+' hook audio files in '+', '.join(brief['hooks'])+' order, plus one BODY file. No inputs were changed.')
 for kind,path in [('hook',h) for h in hookpaths]+[('body',body)]:
  path=studio.resolve(id,path,stop,update);info=media.probe(path)
  if not any(s.get('codec_type')=='audio' for s in info['streams']):raise ValueError(f'{path.name} needs an audio track')
  if video_mode and not any(s.get('codec_type')=='video' for s in info['streams']):raise ValueError('Talking-head hook and body inputs must all have video')
  if any(path==previous for _,previous,_ in inputs):raise ValueError('Each hook and the body must use a different input file')
  inputs.append((kind,path,info))
 identity=hashlib.sha256(json.dumps([(str(path),path.stat().st_size,path.stat().st_mtime_ns) for _,path,_ in inputs]).encode()).hexdigest()[:14]
 work=studio.folder(id)/('inputs_'+identity);work.mkdir(exist_ok=True)
 old={h.get('input_path'):h for h in p.get('hooks',[])};segments=[];hooks=[];cursor=0
 for i,(kind,path,info) in enumerate(inputs):
  update(f'Preparing {kind} file {i+1}/{len(inputs)}',int(i/len(inputs)*80))
  if stop.is_set():raise InterruptedError('Cancelled')
  dest=work/(f'{i:02}_{kind}.mp4' if video_mode else f'{i:02}_{kind}.wav')
  ready=dest.with_suffix('.ready.json')
  temporary=dest.with_name(dest.stem+'.preparing'+dest.suffix)
  if not ready.is_file() or not dest.is_file():
   if video_mode:
    media.run(['ffmpeg','-y','-v','error','-i',path,'-filter_complex_threads','1','-filter_complex',media.picture_filter(),'-map','[v]','-map','0:a:0','-c:v','libx264','-preset','veryfast','-crf','19','-threads','2','-c:a','aac','-ar','48000','-ac','2',temporary],stop)
   else:media.run(['ffmpeg','-y','-v','error','-i',path,'-vn','-ar','48000','-ac','2','-c:a','pcm_s16le',temporary],stop)
   if stop.is_set():raise InterruptedError('Cancelled')
   temporary.replace(dest)
   ready.write_text(json.dumps({'duration':media.duration(dest)}),encoding='utf8')
  length=media.duration(dest);sid=hashlib.sha256(str(path).encode()).hexdigest()[:12]
  segment=dict(id=sid,kind=kind,name=path.stem,input_path=str(path),prepared_path=str(dest),start=cursor,end=cursor+length)
  segments.append(segment)
  if kind=='hook':
   previous=old.get(str(path),{});hooks.append({**segment,'headline':previous.get('headline',''),'enabled':previous.get('enabled',True)})
  cursor+=length
 (work/'concat.txt').write_text(''.join(f"file '{Path(s['prepared_path']).name}'\n" for s in segments),encoding='utf8')
 master=work/('combined.mp4' if video_mode else 'combined.wav')
 media.run(['ffmpeg','-y','-v','error','-f','concat','-safe','0','-i','concat.txt','-c','copy',master.name],stop,work)
 length=media.duration(master)
 if abs(length-cursor)>.15:raise ValueError('Hook/body assembly duration check failed; original project kept')
 # The final end uses the measured assembled duration (AAC can add padding).
 segments[-1]['end']=length
 p.update(story_slots=[],story_generation={},source=str(master),duration=length,cues=[],scenes=[],media_mode='hooks',media_segments=segments,hooks=hooks,body_range={'start':segments[-1]['start'],'end':length},variant_mode='per_hook')
 for key in ('render_file','preview_file','package_file','exports','sentence_analysis','sentence_signature','speech_cues','speech_source','speech_version','speech_model','script_alignment'):p.pop(key,None)
 from .presenter import attach_scripts
 attach_scripts(p)
 studio.save(p)

def retime_rows(rows,ranges,words=False,keep_points=False):
 result=[];cursor=0
 for a,b in ranges:
  for row in rows:
   left=max(a,float(row['start']));right=min(b,float(row['end']))
   if right<=left and not (keep_points and float(row['start'])==float(row['end']) and a<=left<b):continue
   out=copy.deepcopy(row);out.update(start=left-a+cursor,end=right-a+cursor)
   if row.get('anime_hold_segments'):
    parts=retime_rows(row['anime_hold_segments'],[(left,right)])
    out['anime_hold_segments']=[{**part,'start':part['start']+out['start'],'end':part['end']+out['start']} for part in parts]
   if words:
    from .sentences import transcript_words
    units=row.get('words') or transcript_words([row])
    if not row.get('words'):out['pacing_words_estimated']=True
    # Whisper can assign a valid spoken function word a zero-width timestamp.
    # Retain its text inside the selected recording; the phrase has duration.
    out['words']=retime_rows(units,[(a,b)],keep_points=True);out['words']=[{**w,'start':w['start']+cursor,'end':w['end']+cursor} for w in out['words']]
    out['text']=' '.join(w['text'] for w in out['words'])
   if 'offset' in out:out['offset']=float(row.get('offset',0))+left-float(row['start'])
   if out.get('action_window'):
    window=out['action_window'];offset=out.get('offset',0)
    if offset>=window['end'] or offset+(right-left)<=window['start']:out.pop('action_window',None)
   result.append(out)
  cursor+=b-a
 return result

def variant(p,hook,folder,stop):
 body=p.get('body_range') or {}
 if not (0<=body.get('start',-1)<body.get('end',-1)<=p['duration']+.05):raise ValueError('Set a valid shared body range')
 if hook['end']>body['start']+.02:raise ValueError('Hooks must end before the shared body starts')
 ranges=[(hook['start'],hook['end']),(body['start'],body['end'])]
 out=copy.deepcopy(p);out['_caption_edit_key']=hook['id'];out['name']=p['name']+' · '+hook['name'];out['duration']=sum(b-a for a,b in ranges)
 out['scenes']=retime_rows(p['scenes'],ranges);out['cues']=retime_rows(p['cues'],ranges,True)
 out['hooks']=[{**hook,'start':0,'end':hook['end']-hook['start']}]
 out['body_range']={'start':out['hooks'][0]['end'],'end':out['duration']}
 out['media_segments']=[dict(kind='hook',start=0,end=out['hooks'][0]['end']),dict(kind='body',start=out['hooks'][0]['end'],end=out['duration'])]
 out.pop('sentence_analysis',None);out.pop('sentence_signature',None)
 # Keep source video/path for presenter identity; narration is a separate cut.
 dest=Path(folder)/'narration.wav';Path(folder).mkdir(exist_ok=True)
 filters='[0:a]asplit=2[a0][a1];'+''.join(f'[a{i}]atrim=start={a}:end={b},asetpts=PTS-STARTPTS[t{i}];' for i,(a,b) in enumerate(ranges))+'[t0][t1]concat=n=2:v=0:a=1[a]'
 media.run(['ffmpeg','-y','-v','error','-i',p['source'],'-filter_complex',filters,'-map','[a]','-ac','2','-ar','48000',dest],stop)
 out['audio_source']=str(dest);out['source_ranges']=ranges
 return out
