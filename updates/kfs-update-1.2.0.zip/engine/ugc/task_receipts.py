"""Durable accepted-task IDs independent of a briefly locked project file."""
import hashlib,json
from .core import atomic

def signature(submission):return hashlib.sha256(json.dumps(submission,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
def location(studio,p,row,kind):
 folder=studio.folder(p['id'])/'Visuals'/'TaskReceipts';folder.mkdir(parents=True,exist_ok=True)
 return folder/(row['id']+'_'+str(row.get('generation_revision',0))+'_'+kind+'.json')
def record(studio,p,row,kind,task):
 if not isinstance(task,str) or not task.strip():raise ValueError('Provider returned no task ID; check provider history before retrying')
 atomic(location(studio,p,row,kind),dict(project=p['id'],row=row['id'],revision=row.get('generation_revision',0),kind=kind,signature=signature(row[kind+'_submission']),task=task))
def recover(studio,p,row,kind):
 submission=row.get(kind+'_submission')
 if not submission:return ''
 try:data=json.loads(location(studio,p,row,kind).read_text(encoding='utf8'))
 except (OSError,ValueError):return ''
 if not isinstance(data,dict):return ''
 expected=dict(project=p['id'],row=row['id'],revision=row.get('generation_revision',0),kind=kind,signature=signature(submission))
 task=data.get('task','')
 return task if all(data.get(k)==v for k,v in expected.items()) and isinstance(task,str) and task.strip() else ''
