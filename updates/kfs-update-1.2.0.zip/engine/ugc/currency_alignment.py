"""Match explicit equivalent currency notation inside measured speech spans."""
import copy,re
from decimal import Decimal
from difflib import SequenceMatcher

SYMBOLS={'$':'usd','€':'eur','£':'gbp'}
UNITS={'dollar':'usd','dollars':'usd','usd':'usd','euro':'eur','euros':'eur','eur':'eur','pound':'gbp','pounds':'gbp','gbp':'gbp'}
SCALES={'thousand':Decimal(1000),'million':Decimal(1000000),'billion':Decimal(1000000000),'trillion':Decimal(1000000000000)}
NUMBER=re.compile(r'\d+(?:,\d{3})*(?:\.\d+)?')

def clean(word):return str(word).strip('"“”\'‘’.,!?;:').casefold()

def units(texts,key):
 """A money expression is one comparison unit retaining original word indices."""
 result=[];i=0
 while i<len(texts):
  first=clean(texts[i]);currency='';number=first;j=i+1
  if first[:1] in SYMBOLS:
   currency=SYMBOLS[first[0]];number=first[1:]
   if not number and j<len(texts):number=clean(texts[j]);j+=1
  if NUMBER.fullmatch(number):
   scale=Decimal(1)
   if j<len(texts) and clean(texts[j]) in SCALES:scale=SCALES[clean(texts[j])];j+=1
   suffix=UNITS.get(clean(texts[j])) if j<len(texts) else None
   if suffix and (not currency or currency==suffix):currency=suffix;j+=1
   if currency:
    value=Decimal(number.replace(',',''))*scale
    result.append(('money:'+currency+':'+str(value.normalize()),i,j,True));i=j;continue
  result.append((key(texts[i]),i,i+1,False));i+=1
 return result

def equivalent_words(original,expected,key):
 """Only exact currency/value matches expand; ordinary omissions stay untouched."""
 source=units([w['text'] for w in original],key);target=units(expected,key)
 matcher=SequenceMatcher(None,[u[0] for u in source],[u[0] for u in target],autojunk=False)
 # A clear one-for-one amount/currency change is a real mismatch, not notation.
 for tag,a,b,c,d in matcher.get_opcodes():
  if tag=='replace' and b-a==d-c==1 and source[a][3] and target[c][3]:
   return copy.deepcopy(original),0,(source[a][1],source[a][2],target[c][1],target[c][2])
 edits={}
 for block in matcher.get_matching_blocks():
  for x,y in zip(source[block.a:block.a+block.size],target[block.b:block.b+block.size]):
   if not x[3] or not y[3]:continue
   _,a,b,_=x;_,c,d,_=y
   if [key(w['text']) for w in original[a:b]]==[key(w) for w in expected[c:d]]:continue
   left=float(original[a]['start']);right=float(original[b-1]['end'])
   if right<=left:continue
   # Currency symbols represent spoken words; interpolate only within this
   # already measured amount, never into surrounding words or another file.
   rows=[dict(text=t,start=left+(right-left)*n/(d-c),end=left+(right-left)*(n+1)/(d-c),timing_origin='currency_equivalence') for n,t in enumerate(expected[c:d])]
   edits[a]=(b,rows)
 result=[];i=0
 while i<len(original):
  if i in edits:
   end,rows=edits[i];result.extend(rows);i=end
  else:result.append(copy.deepcopy(original[i]));i+=1
 return result,len(edits),None
