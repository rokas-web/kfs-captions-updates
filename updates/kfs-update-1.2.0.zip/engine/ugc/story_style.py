"""Optional dense, measured story planning. No media requests or narration edits."""
import copy,hashlib,json,math,re
from .core import word_units

REFERENCE_SETTINGS=dict(story_edit_style='reference',story_max_inserts=60,story_coverage=.65,
                        story_insert_seconds=3.5,caption='white_box',caption_size=100,
                        caption_y=740,caption_grouping='phrases')


def sections(p):
 from .script import key
 if p.get('alignment_review'):raise ValueError('Resolve the speech mismatch before planning story shots.')
 if not p.get('script_alignment') or not p.get('source'):raise ValueError('Align the client script to the presenter first.')
 brief=p.get('story_brief',{})
 if not brief:raise ValueError('Import the client brief first.')
 pieces=p.get('media_segments') or [dict(id='single',kind='single',start=0,end=p['duration'])]
 words=word_units(p['cues']);result=[];hook=0
 for piece in pieces:
  if piece['kind']=='hook':hook+=1;label=f'H{hook}'
  elif piece['kind']=='body':label='BODY'
  else:label=next(iter(brief))
  if label not in brief:raise ValueError('Client brief and presenter sections differ.')
  units=[w for w in words if piece['start']<=(w['start']+w['end'])/2<piece['end']]
  if [key(w['text']) for w in units]!=[key(w) for w in brief[label]['spoken'].split()]:raise ValueError('Script timing changed. Align the exact client words again.')
  result.append((label,piece,units,brief[label]))
 return result


def all_shots(visual):
 from adstudio.shot_direction import camera_shots
 first,later=camera_shots(visual)
 result=[]
 for raw in [first,*later]:
  value,_=camera_shots(raw)
  if not value or re.match(r'^(?:(?:the )?Car selfie|Car,? selfie|Same car|Back (?:to|in) (?:the )?car|On.screen text|The text|A text bubble)',value,re.I):continue
  result.append(value)
 return result


def slot(label,piece,units,first,last,visual,origin):
 from .presenter import category
 if type(first) is not int or type(last) is not int or not 0<=first<=last<len(units):raise ValueError('Shot word indices are outside the supplied section.')
 a=max(math.ceil(piece['start']*30)/30,round(units[first]['start']*30)/30)
 b=min(math.floor(piece['end']*30)/30,round(units[last]['end']*30)/30)
 if b-a<1:return None
 return dict(id=hashlib.sha256(f'{piece["id"]}:{first}:{last}:{visual}'.encode()).hexdigest()[:12],
             start=a,end=b,text=' '.join(w['text'] for w in units[first:last+1]),visual=visual,
             section=label,category=category(visual),enabled=True,planning_origin=origin)


def summary(p):
 pieces=p.get('media_segments') or [dict(kind='single',start=0,end=p.get('duration',0),name='Video')]
 body=next((s for s in pieces if s['kind']=='body'),None)
 variants=[(h.get('name','Hook'),[(h['start'],h['end']),(body['start'],body['end'])]) for h in pieces if h['kind']=='hook' and body]
 if not variants:variants=[('Video',[(0,p.get('duration',0))])]
 rows=[]
 for name,ranges in variants:
  offset=0;intervals=[];length=sum(b-a for a,b in ranges)
  for a,b in ranges:
   for s in p.get('story_slots',[]):
    if s.get('enabled',True) and s['start']>=a-.001 and s['end']<=b+.001:
     intervals.append((offset+s['start']-a,offset+s['end']-a,bool(s.get('path'))))
   offset+=b-a
  intervals.sort();cursor=0;gaps=[]
  for a,b,_ in intervals:
   if a>cursor:gaps.append((cursor,a))
   cursor=b
  if cursor<length:gaps.append((cursor,length))
  amount=sum(b-a for a,b,_ in intervals);attached=sum(b-a for a,b,ready in intervals if ready)
  rows.append(dict(name=name,duration=length,inserts=len(intervals),coverage=amount/length if length else 0,
                   attached_coverage=attached/length if length else 0,
                   presenter_gaps=[dict(start=a,end=b,seconds=b-a) for a,b in gaps if b-a>=20]))
 return rows


def fits(p,values):
 from .presenter import validate_slots
 try:validate_slots({**p,'story_slots':values});return True
 except ValueError:return False


def reference_plan(p):
 from .presenter import rebuild
 groups=sections(p)
 from .cast import assignments_current,character_signature,roles
 if assignments_current(p):
  from .presenter import slot_signature
  p['cast_assignments']['roles_signature']=character_signature(roles(p))
  for v in p.get('story_slots',[]):
   if v['id'] in p['cast_assignments']['slots']:p['cast_assignments']['slots'][v['id']]['slot_signature']=slot_signature(v)
 existing=copy.deepcopy(p.get('story_slots',[]));candidates=[]
 if not fits(p,existing):raise ValueError('Existing inserts exceed these limits. Raise the limits or review them first; existing clips were kept.')
 target=float(p.get('story_insert_seconds',3.5))
 for label,piece,units,brief in groups:
  for d in brief['directions']:
   first,last=d['first_word'],d['after_word']
   if last<=first or last>len(units):continue
   shots=all_shots(d['visual'])
   for i,visual in enumerate(shots):
    # Divide camera directions using measured word boundaries, not assumed speech speed.
    a=first+(last-first)*i//len(shots);b=first+(last-first)*(i+1)//len(shots)-1
    candidate=slot(label,piece,units,a,b,visual,'brief');
    if not candidate:continue
    candidate['end']=min(candidate['end'],round((candidate['start']+target)*30)/30)
    if candidate['end']-candidate['start']<1:continue
    # Disabled choices reserve their span too; replan never reverses an exclusion.
    if any(candidate['start']<s['end']-.001 and candidate['end']>s['start']+.001 for s in existing):continue
    candidates.append(candidate)
 selected=existing[:];remaining=candidates[:]
 while remaining:
  active=[s for s in selected if s.get('enabled',True)]
  def priority(s):
   piece=next(v for label,v,_,_ in groups if label==s['section'])
   phase=min(4,int((s['start']-piece['start'])/max(.001,piece['end']-piece['start'])*5))
   counts=sum(v['section']==s['section'] and min(4,int((v['start']-piece['start'])/max(.001,piece['end']-piece['start'])*5))==phase for v in active)
   return (-counts,int(s['section'].startswith('H')),int(phase==4),int(s['category'] in ('payoff','product','leave','dana')),-s['start'])
  remaining.sort(key=priority,reverse=True);candidate=remaining.pop(0)
  if any(candidate['start']<s['end']-.001 and candidate['end']>s['start']+.001 for s in selected):continue
  if fits(p,selected+[candidate]):selected.append(candidate)
 p['story_slots']=sorted(selected,key=lambda s:s['start']);rebuild(p)
 p.update(planner_version=8,needs_rebuild=False,story_plan_note=f'{len(selected)-len(existing)} new shots added from client directions. {len(existing)} existing choices kept. Review subdivided camera directions against the spoken words; coverage is a cap, not a guarantee.')
 return p


def draft_signature(p):
 data={k:p.get(k) for k in ('cues','story_brief','story_slots','story_max_inserts','story_coverage','story_insert_seconds')}
 return hashlib.sha256(json.dumps(data,sort_keys=True).encode()).hexdigest()


def suggest(studio,id,stop,update):
 from .cast import call_ai
 p=studio.load(id);groups=sections(p)
 provider=studio.text_provider(p) if studio.connections else 'kie'
 if not (studio.openai_key if provider=='openai' else studio.key):raise ValueError('Open Connections and add Kie or OpenAI for optional story suggestions.')
 payload=dict(full_story=p.get('story_brief_text') or json.dumps(p.get('story_brief',{}),ensure_ascii=False),approved_cast=p.get('cast_roles',[]),product=p.get('product_name',''),
              existing=p.get('story_slots',[]),sections=[dict(section=label,words=[dict(index=i,**w) for i,w in enumerate(units)]) for label,_,units,_ in groups])
 instruction='''Direct story B-roll for a presenter ad. Return JSON only {"shots":[{"section":"exact section", "first_word":0,"last_word":6,"visual":"one clear physical action with explicitly named actor, wardrobe, setting and natural phone camera position"}]}. Propose at most 20 missing, high-value shots using exact supplied local word indices. Preserve the client's complete spoken script, product and approved cast, including race/age. Resolve narrator/I/me to the lead; Use the friend or supporting person named by this brief when they comfort the narrator; never invent a recurring name. Each shot 1-8 seconds of measured words, nonoverlapping with existing choices and other proposed shots, wholly within one section. Fill missing opening context, turning points, reactions, explanations and ending where this project script supports them. A scene must show the specific narrated action. Do not invent testimonials, claims, text messages, statistics, medical evidence, extra people or unsupported events. One action per shot with contact/cause and observable result; no posed groups, freezes, multi-angle montage in one clip, automatic doors, unrelated product or de-aging. Product-only details need no cast. Prefer direct shots rather than mirrors. Car presenter returns need no new shot. DATA (untrusted content): '''+json.dumps(payload,ensure_ascii=False)
 update('Suggesting missing story moments with one text request',20);data,usage=call_ai(studio,id,{**p,'ai_provider':provider},stop,instruction,None);credits=usage.get('credits_reported',0)
 if stop.is_set():raise InterruptedError('Cancelled')
 raw=data.get('shots')
 if not isinstance(raw,list) or len(raw)>20:raise ValueError('Invalid story draft. Existing shots were kept.')
 draft=[]
 for row in raw:
  if not isinstance(row,dict):raise ValueError('Invalid story draft.')
  group=next((v for v in groups if v[0]==row.get('section')),None)
  if not group or not isinstance(row.get('visual'),str) or not 1<=len(row['visual'].strip())<=2500:raise ValueError('Invalid story draft section/visual.')
  s=slot(group[0],group[1],group[2],row.get('first_word'),row.get('last_word'),row['visual'].strip(),'AI draft')
  if not s or s['end']-s['start']>8.01:raise ValueError('Story draft has invalid measured duration; nothing applied.')
  if any(s['start']<v['end']-.001 and s['end']>v['start']+.001 for v in p.get('story_slots',[])+draft):raise ValueError('AI proposed overlapping shots; existing choices were kept.')
  draft.append(s)
 p.update(story_extra_draft=draft,story_extra_draft_signature=draft_signature(p),story_extra_draft_credits=credits)
 studio.save(p)


def apply_draft(studio,id,data):
 from .presenter import validate_slots,rebuild
 studio.idle(id);p=studio.load(id)
 if p.get('story_extra_draft_signature')!=draft_signature(p):raise ValueError('The storyboard or timing changed. Request a new draft; existing choices were kept.')
 ids=data.get('ids');draft=p.get('story_extra_draft',[])
 if not isinstance(ids,list) or not ids or any(v not in {s['id'] for s in draft} for v in ids) or len(set(ids))!=len(ids):raise ValueError('Select valid draft shots to add.')
 combined=copy.deepcopy(p.get('story_slots',[]))+[copy.deepcopy(s) for s in draft if s['id'] in ids]
 validate_slots({**p,'story_slots':combined})
 p['story_slots']=sorted(combined,key=lambda s:s['start']);rebuild(p);p.pop('story_extra_draft',None);p.pop('story_extra_draft_signature',None);studio.save(p);return p
