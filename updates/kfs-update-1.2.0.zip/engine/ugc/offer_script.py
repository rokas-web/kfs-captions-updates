"""Free conservative offer extraction from spoken script, with manual overrides."""
import copy,hashlib,re
FIELDS=('brand','product','price','offer','cta')
NAME=r'([A-Z][A-Za-z0-9&\'-]*(?:\s+[A-Z][A-Za-z0-9&\'-]*){0,3})'

def spoken_script(p):
 for piece in p.get('media_segments',[]):
  if piece.get('kind')=='body' and p.get('segment_scripts',{}).get(piece['id']):return p['segment_scripts'][piece['id']]
 if p.get('original_script'):return str(p['original_script'])
 sections=(p.get('visual_brief') or {}).get('sections',{})
 return sections.get('BODY',{}).get('spoken','')

def extract(text):
 text=' '.join(str(text).split());values={};evidence={};ambiguous=[]
 def choose(field,rows):
  found={value.strip().rstrip('.!'):quote for value,quote in rows if value.strip()}
  if len(found)==1:
   value,quote=next(iter(found.items()));values[field]=value[:180];evidence[field]=quote[:400]
  elif len(found)>1:ambiguous.append(field)
 brands=[]
 for pattern in [r'\b(?:small\s+)?company\s+(?:did|does)[.:]\s*'+NAME,r'\b(?:Introducing|Meet)\s+'+NAME,r'\b(?:brand|company)\s+(?:called|named)\s+'+NAME]:
  for m in re.finditer(pattern,text):brands.append((m.group(1),m.group(0)))
 choose('brand',brands)
 # Exact product names are filled only when explicitly labeled in spoken text.
 products=[(m.group(1),m.group(0)) for m in re.finditer(r'\b[Pp]roduct\s+(?:called|named)\s+'+NAME,text)]
 choose('product',products)
 prices=[]
 amount=r'(?:R\$|\$|€|£)\s*\d+(?:,\d{3})*(?:\.\d+)?'
 for m in re.finditer(amount+r'\s+(?:a|per|each)\s+(?:bottle|box|pack|jar|bag|month|unit)\b',text,re.I):prices.append((m.group(0),m.group(0)))
 for m in re.finditer(r'\b\d+(?:\.\d+)?\s+(?:dollars|euros|pounds)\s+(?:a|per|each)\s+(?:bottle|box|pack|jar|bag|month|unit)\b',text,re.I):prices.append((m.group(0),m.group(0)))
 if not prices:
  for m in re.finditer(r'\b(?:costs?|priced at|only|just)\s+('+amount+r')(?!\d|[,.]\d)\b',text,re.I):
   if not re.match(r'\s+(?:thousand|million|billion|trillion|off)\b',text[m.end():],re.I):prices.append((m.group(1),m.group(0)))
 choose('price',prices)
 offers=[(m.group(0),m.group(0)) for m in re.finditer(r'\bBuy\s+(?:\d+|one|two|three|four|five)\s*,?\s*get\s+(?:\d+|one|two|three|four|five)\s+free\b',text,re.I)]
 choose('offer',offers)
 ctas=[(m.group(0),m.group(0)) for m in re.finditer(r'\b(?:Link(?:[\'’]s| is)?\s+(?:below|in (?:the )?bio)|Click\s+(?:the\s+)?link\s+below|Shop\s+now|Order\s+now)\b',text,re.I)]
 choose('cta',ctas)
 guarantees=[(m.group(0),m.group(0)) for m in re.finditer(r'\b\d+[- ]day\s+money[- ]back\s+guarantee\b',text,re.I)]
 g={v for v,q in guarantees}
 if len(g)==1 and 'cta' in values:
  guarantee=next(iter(g));values['cta']=(values['cta']+' · '+guarantee)[:180]
  evidence['cta']+=' / '+guarantee
 return dict(values=values,evidence=evidence,ambiguous=ambiguous)

def autofill(p,explicit=False):
 text=spoken_script(p);result=extract(text);old=p.get('visual_offer_autofill') or {};offer=p.setdefault('visual_offer',{})
 previous=old.get('values',{});manual=set(p.get('visual_offer_manual',[]));filled=[]
 for k,v in result['values'].items():
  current=offer.get(k,'')
  if k in manual and not (explicit and not current.strip()):continue
  if not current.strip() or (k not in manual and k in previous and current==previous[k]):
   if current!=v:offer[k]=v;filled.append(k)
   manual.discard(k)
 # Remove a previously automatic value when a changed script no longer states it.
 for k,v in previous.items():
  if k not in result['values'] and k not in manual and offer.get(k)==v:offer[k]='';filled.append(k)
 p['visual_offer_manual']=sorted(manual)
 p['visual_offer_autofill']={**result,'source_signature':hashlib.sha256(text.encode()).hexdigest(),'filled':filled}
 return filled

def mark_manual(p,old):
 manual=set(p.get('visual_offer_manual',[]))
 for k in FIELDS:
  if p.get('visual_offer',{}).get(k,'')!=old.get('visual_offer',{}).get(k,''):manual.add(k)
 p['visual_offer_manual']=sorted(manual)

def refresh(studio,id):
 studio.idle(id);p=studio.load(id)
 if p.get('workflow')!='montage':raise ValueError('Use script offer details in the illustrated / narrated workspace')
 changed=autofill(p,explicit=True)
 if changed:
  from .visual_montage import clear_outputs
  for s in p.get('scenes',[]):
   if s.get('visual_type')=='offer' and s.get('visual_route')=='layout':s['path']='';s['review']=True
  clear_outputs(p)
 studio.save(p);return p
