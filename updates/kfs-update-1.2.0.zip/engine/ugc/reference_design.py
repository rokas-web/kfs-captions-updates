"""Role-specific reference inputs; scene samples must not become every setting."""
import copy
VERSION=2

def reference_prompt(style,row):
 prefix='Art language only (medium, palette, texture and character design; scene examples are not subjects to copy): '+style+'. '
 if row['kind']=='style':
  return prefix+'Create an abstract material and color sample: watercolor washes, paper texture, ink strokes and simple nonrepresentational shapes demonstrating this art language. No identifiable location, architecture, people, heads, characters, boats, furniture, products, words, labels, panels or watermark. This is a palette/technique reference, not a story scene.'
 subject='Reference subject: '+row['name']+'. Approved definition: '+row['description']+'. '
 if row['kind']=='character':
  task='CHARACTER IDENTITY REFERENCE ONLY. One isolated full-body character, standing in a neutral front or three-quarter pose, centered on a plain untextured cream background. Preserve the specified face design, age and wardrobe. Show role-specific clothing or handheld props only when specified in the definition. No environment, scenery, buildings, boats, furniture, other people, scene action, captions, labels, panels or watermark.'
 else:
  task='EMPTY LOCATION REFERENCE ONLY. Show the named environment, its fixed architecture, objects, layout and lighting. Depict the setting described for this reference, not a scene mentioned in the art-language examples. No people, characters, heads, faces, bodies, foreground actor, captions, labels, panels or watermark. The setting is the only subject.'
 return prefix+subject+task

def shot_references(rows,shot):
 # A specific environment controls composition; characters control identities.
 # Old style scenes remain visible for review, but cannot contaminate new shots.
 location=[r for r in rows if r['kind']=='location' and r['id']==shot.get('location_id')]
 characters=[r for r in rows if r['kind']=='character' and r['id'] in shot.get('cast_ids',[])]
 palette=[r for r in rows if r['kind']=='style' and r.get('style_anchor_type')=='palette' and r.get('reference_prompt_version')==VERSION]
 return location+characters+palette

def reference_roles(rows,start=1):
 roles={'location':'Environment layout only; no person identity or borrowed action.',
  'character':'Specified character face/body/wardrobe only; ignore the reference background, pose and scene props not requested here.',
  'style':'Palette, texture and drawing technique only; no scene composition or subjects.'}
 return ' '.join(f'Reference {j}: {r["kind"]} {r["name"]}; {r["description"]}. Role: {roles[r["kind"]]}' for j,r in enumerate(rows,start))

def sync_checkpoint(p,v):
 cache=p.get('visual_plan_checkpoint')
 if cache and cache.get('signature')==v.input_signature(p):
  cache['bible']=copy.deepcopy(p['visual_bible'])
  for s in p['scenes']:
   if s['id'] in cache.get('shots',{}):cache['shots'][s['id']]=copy.deepcopy(s)

def edit(studio,id,data):
 from . import visual_montage as v
 studio.idle(id);p=v.validate(studio.load(id),check_media=False)
 row=next((r for r in p.get('visual_refs',[]) if r['id']==data.get('id')),None)
 if not row or row['kind'] not in ('character','location'):raise ValueError('Choose a character or location reference')
 description=data.get('description')
 if not isinstance(description,str) or not description.strip() or len(description)>1200:raise ValueError('Use a reference description of 1–1,200 characters')
 description=description.strip()
 if description==row['description']:return p
 bible=copy.deepcopy(p['visual_bible']);key='characters' if row['kind']=='character' else 'locations'
 identity=next((r for r in bible[key] if r['id']==row['id']),None)
 if not identity:raise ValueError('Reference identity is missing from the current plan')
 identity['description']=description;p['visual_bible']=v.validate_bible(bible)
 v.reset_row(p,row,'image');row['description']=description;v.invalidate_reference(p,row['id'])
 p.pop('visual_plan_approval',None);sync_checkpoint(p,v);v.clear_outputs(p);studio.save(p);return p

def remove_location(studio,id,data):
 from . import visual_montage as v
 studio.idle(id);p=v.validate(studio.load(id),check_media=False)
 target=data.get('id');row=next((r for r in p.get('visual_refs',[]) if r['id']==target),None)
 if not row or row['kind']!='location':raise ValueError('Only a location reference can be removed from the plan')
 p.setdefault('visual_history',[]).append(copy.deepcopy(row))
 p['visual_refs']=[r for r in p['visual_refs'] if r['id']!=target]
 p['visual_bible']['locations']=[r for r in p['visual_bible']['locations'] if r['id']!=target]
 for s in p['scenes']:
  if s.get('location_id')==target:
   if s.get('path') or any(s.get(k) for k in ('image_path','video_path','image_task','video_task','image_submission','video_submission')):v.reset_row(p,s,'image')
   s['location_id']='';s['review']=True
 p.pop('visual_plan_approval',None);sync_checkpoint(p,v);v.clear_outputs(p);studio.save(p);return p
