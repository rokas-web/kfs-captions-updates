"""Validate native media tools before setup, packaging, or importing footage."""
import os, shutil, struct, subprocess, sys
from functools import lru_cache
from pathlib import Path

def windows_binary(path):
 try:
  with Path(path).open('rb') as stream:
   header=stream.read(64)
   if len(header)<64 or header[:2]!=b'MZ':return False
   stream.seek(struct.unpack_from('<I',header,60)[0]);pe=stream.read(6)
   return pe[:4]==b'PE\0\0' and struct.unpack_from('<H',pe,4)[0] in (0x14c,0x8664,0xaa64)
 except (OSError,struct.error):return False

@lru_cache(maxsize=32)
def _checked(path,size,modified):
 if sys.platform=='win32' and not windows_binary(path):return False
 try:
  result=subprocess.run([path,'-version'],capture_output=True,timeout=10,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
  return result.returncode==0 and Path(path).stem.lower().encode() in result.stdout.lower()
 except (OSError,subprocess.TimeoutExpired):return False

def usable(path):
 try:
  p=Path(path);s=p.stat();return _checked(str(p.resolve()),s.st_size,s.st_mtime_ns)
 except OSError:return False

def resolve(name,base):
 if name not in ('ffmpeg','ffprobe'):return name
 suffix='.exe' if sys.platform=='win32' else ''
 bundled=Path(base)/(name+suffix)
 if usable(bundled):return str(bundled)
 found=shutil.which(name)
 if found and usable(found):return found
 raise RuntimeError(f'{name} is missing or incompatible. Close Premiere and rerun INSTALL_MAC.command to repair the Mac media tools.')

def verify_bundle(base):
 for name in ('ffmpeg','ffprobe'):
  if not usable(Path(base)/(name+'.exe')):
   raise RuntimeError(f'Cannot package {name}.exe: it is not a working Windows executable. Run Setup_Windows.bat to repair it.')
