"""Free, explicit product-photo binding without rebuilding paid story work."""
import hashlib,re,shutil
from pathlib import Path

def store_photo(folder,path):
 digest=hashlib.sha256(path.read_bytes()).hexdigest()
 dest=folder/('product_'+digest[:20]+path.suffix.lower())
 if path.resolve()!=dest.resolve():shutil.copy2(path,dest)
 return str(dest)

def suggestions(p):
 """Conservative hints; a generic historical diet-pill bottle is not the brand."""
 names=[v.strip() for k in ('brand','product') if (v:=p.get('visual_offer',{}).get(k,'')) and len(v.strip())>=3]
 def named(text):return any(re.search(r'(?<!\w)'+re.escape(n)+r'(?!\w)',text,re.I) for n in names)
 brand_seen=False;ids=[]
 for s in p.get('scenes',[]):
  text=s.get('text','');visual=s.get('visual','')
  brand_seen=brand_seen or named(text)
  eligible=s.get('visual_route') in ('image','video')
  packaging=bool(re.search(r'\b(bottles?|capsules?|packaging|packshot|product)\b',visual,re.I))
  if eligible and (s.get('product_reference_path') or named(visual) or named(text) or s.get('visual_type')=='offer' or (brand_seen and packaging)):
   ids.append(s['id'])
 return ids

def bind(studio,id,data):
 from . import visual_montage as v
 from .reference_design import sync_checkpoint
 studio.idle(id);p=studio.load(id)
 photo=Path(p.get('visual_offer',{}).get('image_path',''))
 if not photo.is_file():raise ValueError('Add a product photo first and check its preview.')
 ids=data.get('ids')
 if not isinstance(ids,list) or not ids or any(not isinstance(x,str) for x in ids) or len(ids)!=len(set(ids)):raise ValueError('Select the product shots that should use this photo.')
 rows={s['id']:s for s in p.get('scenes',[])}
 if any(x not in rows or rows[x].get('visual_route') not in ('image','video') for x in ids):raise ValueError('Select AI image or video shots only.')
 changed=[rows[x] for x in ids if rows[x].get('product_reference_path')!=str(photo)]
 reset=[s for s in changed if any(s.get(k) for k in ('image_path','image_task','image_submission','video_path','video_task','video_submission'))]
 if reset and data.get('replace_existing') is not True:raise ValueError('Confirm replacing the selected completed or submitted product shots. Other shots are preserved.')
 for s in changed:
  v.reset_row(p,s,'image');s['product_reference_path']=str(photo)
 if changed:
  p.pop('visual_plan_approval',None);v.clear_outputs(p);sync_checkpoint(p,v)
 p['product_reference_note']=f'Photo applied to {len(changed)} changed shots; {len(reset)} selected shots need replacement. Other visuals kept. Approve the plan before generation.' if changed else 'Selected shots already use this photo. Existing images kept.'
 studio.save(p);return p

def image_input(s):
 path=s.get('product_reference_path')
 if not path:return '', ''
 if not Path(path).is_file():raise ValueError('Product photo for this shot is missing. Add it again and apply it to the selected shot before generation.')
 prompt='Reference 1 is the actual product packaging, not an art style or setting. Show this product naturally in the requested shot; preserve its bottle shape, cap, label design, colors and proportions. Retain the supplied packaging print only; do not invent labels, claims or certifications. Keep the surrounding scene in the chosen art style. '
 return path,prompt

def shot_mode(s):
 if s.get('visual_route')=='data' and s.get('product_photo_path') and s.get('path')==s['product_photo_path']:return 'photo'
 if s.get('visual_route') in ('image','video') and s.get('product_reference_path'):return 'reference'
 return 'none'

def set_shot(studio,id,data):
 """Change one shot only. This action never submits a provider request."""
 from . import visual_montage as v
 from .reference_design import sync_checkpoint
 studio.idle(id);p=studio.load(id)
 row=next((s for s in p.get('scenes',[]) if s['id']==data.get('id')),None)
 if not row:raise ValueError('Unknown shot')
 mode=data.get('mode')
 if mode not in ('none','reference','photo'):raise ValueError('Choose no photo, AI reference, or original product photo.')
 if mode=='reference' and p.get('visual_source')=='data':raise ValueError('Select an AI source in Setup before using an AI product reference.')
 photo=p.get('visual_offer',{}).get('image_path','')
 if mode!='none' and not Path(photo).is_file():raise ValueError('Add a product photo first and check its preview.')
 current=shot_mode(row)
 unchanged=(mode=='reference' and current==mode and row.get('product_reference_path')==photo) or (mode=='photo' and current==mode and row.get('product_photo_path')==photo) or (mode=='none' and not row.get('product_reference_path') and not row.get('product_photo_path'))
 if unchanged:
  p['product_reference_note']='This shot already uses that option. Existing visuals kept.';studio.save(p);return p
 has_work=any(row.get(k) for k in ('path','image_path','image_task','image_submission','video_path','video_task','video_submission'))
 if has_work and data.get('replace_existing') is not True:raise ValueError('Confirm replacing this shot. Old files and task IDs are kept; other shots are preserved.')
 was_photo=current=='photo';v.reset_row(p,row,'image')
 row.pop('product_reference_path',None);row.pop('product_photo_path',None)
 if mode=='photo':
  row.update(product_photo_path=photo,path=photo,visual_route='data',visual_type='illustration',offset=0,motion='none',fit='blur',review=True)
 elif mode=='reference':
  row['product_reference_path']=photo
  if row.get('visual_route') not in ('image','video'):row['visual_route']='image'
  if row.get('visual_type') in ('chapter','diagram','offer'):row['visual_type']='illustration'
  if was_photo:row['motion']='none' if p.get('visual_motion')=='still' else 'in'
 elif was_photo:
  row['visual_route']='data' if p.get('visual_source')=='data' else 'image';row['visual_type']='illustration'
 p.pop('visual_plan_approval',None);v.ensure_refs(p);v.clear_outputs(p);sync_checkpoint(p,v)
 p['product_reference_note']={'photo':'Original product photo attached to this shot. No AI charge. Review and approve the shot.', 'reference':'Product photo applied to this shot as an AI reference. Approve the plan, then generate this shot with separate credit confirmation.', 'none':'Product photo removed from this shot. Review the plan before generating a replacement.'}[mode]
 studio.save(p);return p
