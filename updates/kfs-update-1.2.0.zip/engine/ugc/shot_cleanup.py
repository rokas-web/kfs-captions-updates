"""Free pre-generation repair using the existing timed speech and directions."""
import copy,re
from . import montage

def intro_diagram(row,p=None):
 context=row.get('context') or row.get('text','')
 if row.get('visual_type')!='diagram' or not re.match(r'\s*(how|why)\b',context,re.I) or not re.search(r'\bexplained\s+like\b',context,re.I):return False
 if row.get('section_kind')=='hook':return True
 if p and p.get('media_segments'):
  mid=(row['start']+row['end'])/2
  return any(r['kind']=='hook' and r['start']<=mid<r['end'] for r in p['media_segments'])
 return True

def normalize_intro(row,p=None):
 if not intro_diagram(row,p):return False
 context=row.get('context') or row['text']
 row.update(visual_type='illustration',visual_route='image',layout={},review=True,
  visual='A single narrative illustration representing this opening: '+context+'. Convey it through characters, props and a setting. No diagrams, arrows, charts, panels, labels or lettering.',
  motion_prompt='Gentle camera movement over one coherent scene.')
 row['prompt']=row['visual'];return True

def issues(p):
 rows=p.get('scenes',[])
 empty=sum(not s.get('text','').strip() for s in rows)
 fragments=sum(0<len(s.get('text','').split())<=2 and len(s.get('context','').split())>len(s['text'].split()) and s.get('visual_type')!='chapter' for s in rows)
 intros=sum(intro_diagram(s,p) for s in rows)
 # Never discard a paid or submitted task, or an already chosen local shot.
 started=any(s.get('path') or any(s.get(k) for k in ('image_path','video_path','image_task','video_task','image_submission','video_submission')) for s in rows)
 allowed=bool(rows and p.get('visual_engine') and p.get('visual_source') in ('ai','hybrid') and not started and not p.get('needs_rebuild') and p.get('cues') and (empty or fragments or intros))
 return dict(empty_shots=empty,fragment_shots=fragments,intro_diagrams=intros,cleanup_available=allowed)

def clean(studio,id):
 from . import visual_montage as v
 studio.idle(id);p=v.validate(studio.load(id),check_media=False)
 if not issues(p)['cleanup_available']:raise ValueError('Free cleanup requires an ungenerated AI shot plan with empty cuts or sentence fragments. Completed visuals and submitted tasks are kept.')
 old=copy.deepcopy(p['scenes']);draft=v.draft(p)
 def section(t):return next((i for i,r in enumerate(p.get('media_segments',[])) if r['start']<=t<r['end']),None)
 rows=[]
 for row in draft:
  midpoint=(row['start']+row['end'])/2
  candidates=[s for s in old if section((s['start']+s['end'])/2)==section(midpoint) and min(row['end'],s['end'])>max(row['start'],s['start']) and s.get('text','').strip()]
  if not candidates:candidates=[s for s in old if section((s['start']+s['end'])/2)==section(midpoint)]
  if not candidates:raise ValueError('No prior visual direction for this narration section. Existing plan kept.')
  before=max(candidates,key=lambda s:max(0,min(row['end'],s['end'])-max(row['start'],s['start'])))
  for key in ('visual','motion_prompt','cast_ids','location_id','visual_type','visual_route','layout'):
   if key in before:row[key]=copy.deepcopy(before[key])
  row.setdefault('visual_type','illustration');row.setdefault('visual_route','image');row.setdefault('cast_ids',[]);row.setdefault('location_id','');row.setdefault('layout',{})
  row['path']='';row['offset']=0;row['review']=True;row['prompt']=row.get('visual') or row['context'];row['reason']='Retimed from complete narration phrases; review the reused visual direction.'
  normalize_intro(row,p)
  row['motion']='none' if row['visual_route']=='layout' or p['visual_motion']=='still' else ('in','out')[len(rows)%2]
  rows.append(row)
 # The free cleanup is atomic: never alter words, audio, section edges or refs.
 expected=' '.join(w['text'] for w in montage.transcript_words(p['cues']))
 if ' '.join(s['text'] for s in rows)!=expected:raise ValueError('Cleanup speech coverage check failed; existing plan kept.')
 montage.validate({**p,'scenes':rows});v.validate({**p,'scenes':rows})
 p.setdefault('visual_history',[]).extend(old);p['scenes']=rows
 cache=p.get('visual_plan_checkpoint',{})
 p['visual_plan_checkpoint']=dict(signature=v.input_signature(p),bible=copy.deepcopy(p.get('visual_bible',{})),shots={s['id']:copy.deepcopy(s) for s in rows},usage=cache.get('usage',[]),pending_batches={})
 p['visual_semantic_version']=montage.SEMANTIC_VERSION;p['visual_cleanup_note']=f'Cleaned {len(old)} shots into {len(rows)} phrase-aware shots locally. No paid planning request. Review the visual directions, then approve the plan.'
 p.update(status='done',message='Cleaned shot plan is ready to review',progress=100)
 p.pop('visual_plan_approval',None);v.ensure_refs(p);v.clear_outputs(p);studio.save(p);return p
