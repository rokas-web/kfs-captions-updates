"""Choose the recorded hook from measured speech, without prompting ASR."""
import re
from difflib import SequenceMatcher
NUMBERS={'eight':'8','forty':'40','sixty':'60'}
def tokens(text):
 return [NUMBERS.get(x,x) for x in re.findall(r"\w+(?:'\w+)?",str(text).lower().replace('’',"'"))]
def choose(sections,cues,selection='auto'):
 from ugc.sentences import transcript_words
 hooks={key:str(value) for key,value in sections.items() if re.fullmatch(r'H(?:[1-9]|[1-4][0-9]|50)',key)}
 body=str(sections.get('BODY',''))
 if not hooks:return dict(script=body or str(sections.get('SINGLE','')),hook=None,automatic=False,needs_review=False)
 if selection not in ('','auto'):
  if selection not in hooks:raise ValueError('Choose a hook from this brief.')
  return dict(script=(hooks[selection]+' '+body).strip(),hook=selection,automatic=False,needs_review=False)
 words=transcript_words(cues);heard=tokens(' '.join(w['text'] for w in words if w['start']<20))
 ranks=[]
 for key,text in hooks.items():
  expected=tokens(text or ' '.join(body.split()[:40]));n=len(expected)
  score=max((SequenceMatcher(None,expected,heard[:stop],autojunk=False).ratio() for stop in range(max(1,n-4),min(len(heard),n+4)+1)),default=0)
  ranks.append((score,key))
 ranks.sort(reverse=True);score,key=ranks[0];margin=score-(ranks[1][0] if len(ranks)>1 else 0)
 return dict(script=(hooks[key]+' '+body).strip(),hook=key,automatic=True,confidence=round(score,3),margin=round(margin,3),needs_review=score<.7 or len(ranks)>1 and margin<.07,scores={k:round(s,3) for s,k in ranks})
