"""Frame-accurate word timing by CTC forced alignment (local patch).

The speech model (Whisper) already knows WHAT was said; its word timings are
only estimates (often 0.1-0.2 s off in continuous speech). Here a dedicated
acoustic model (wav2vec2, English characters, ONNX) is forced to match those
exact words to the audio, sound by sound, which gives each word's real start.

Runs fully offline once the model is downloaded by the patch installer.
If anything is missing or fails, it returns {} and the caller keeps the
speech model's own timing.
"""
import json, re
from pathlib import Path

MODEL_DIR = (Path.home()/'Library'/'Application Support' if __import__('sys').platform=='darwin' else Path(__import__('os').environ.get('LOCALAPPDATA') or Path.home()))/'KandyForScaleCaptions'/'align'
STRIDE = 0.02          # wav2vec2 emits one frame per 20 ms
PAD = 0.25             # audio added around each sentence window
LEAD = 0.03            # small lead: show the caption as the first sound begins
STATUS = {'ok': None}
REPORT = []

def boundary(db, spike, prev_end):
    """The character model fires slightly AFTER a word's sound begins. The real
    start lies between the previous word's last sound and this spike: take the
    quietest point there (the gap between the words) and start right after it."""
    if db is None: return spike
    hop = 0.01
    lo = (prev_end + 0.03) if prev_end is not None else spike - 0.25
    lo = max(lo, spike - 0.30)
    a, b = int(lo / hop), int(spike / hop) + 1
    if b - a < 3 or a < 0 or b >= len(db): return spike
    seg = db[a:b]
    m = int(seg.argmin()); low = float(seg[m])
    # need a real dip compared with the speech after it, otherwise trust the spike
    after = float(db[b:b + 8].max()) if b + 8 <= len(db) else low
    if after - low < 6: return spike
    k = a + m
    while k + 1 < b and db[k + 1] < low + 3: k += 1
    return (k + 1) * hop

ONES = 'ZERO ONE TWO THREE FOUR FIVE SIX SEVEN EIGHT NINE TEN ELEVEN TWELVE THIRTEEN FOURTEEN FIFTEEN SIXTEEN SEVENTEEN EIGHTEEN NINETEEN'.split()
TENS = 'ZERO TEN TWENTY THIRTY FORTY FIFTY SIXTY SEVENTY EIGHTY NINETY'.split()

def number_words(n):
    n = int(n)
    if n < 20: return ONES[n]
    if n < 100: return TENS[n // 10] + ('' if n % 10 == 0 else ' ' + ONES[n % 10])
    if n < 1000: return ONES[n // 100] + ' HUNDRED' + ('' if n % 100 == 0 else ' ' + number_words(n % 100))
    if n < 1000000: return number_words(n // 1000) + ' THOUSAND' + ('' if n % 1000 == 0 else ' ' + number_words(n % 1000))
    return ' '.join(ONES[int(c)] for c in str(n))

def spoken(text):
    """Turn a transcript word into the characters the acoustic model knows."""
    t = str(text).upper().replace('’', "'").replace('%', ' PERCENT')
    t = re.sub(r'(\d+)(ST|ND|RD|TH|S)\b', lambda m: number_words(m.group(1)) + ('S' if m.group(2) == 'S' else ''), t)
    t = re.sub(r'\d+', lambda m: ' ' + number_words(m.group(0)) + ' ', t)
    t = re.sub(r"[^A-Z' ]", ' ', t)
    return ' '.join(t.split())

_session = None
def model():
    global _session
    if _session is None:
        import onnxruntime as ort
        path = next((p for p in (MODEL_DIR / 'model_quantized.onnx', MODEL_DIR / 'model.onnx') if p.is_file()), None)
        if path is None: raise FileNotFoundError('alignment model not installed')
        vocab = json.loads((MODEL_DIR / 'vocab.json').read_text(encoding='utf-8'))
        opts = ort.SessionOptions(); opts.log_severity_level = 3; opts.intra_op_num_threads = 2; opts.inter_op_num_threads = 1
        sess = ort.InferenceSession(str(path), opts, providers=['CPUExecutionProvider'])
        _session = (sess, vocab, sess.get_inputs()[0].name)
    return _session

def emissions(audio):
    import numpy as np
    sess, vocab, name = model()
    x = audio.astype(np.float32)
    x = (x - x.mean()) / np.sqrt(x.var() + 1e-7)
    logits = sess.run(None, {name: x[None, :]})[0][0].astype(np.float64)
    m = logits.max(axis=1, keepdims=True)
    return logits - m - np.log(np.exp(logits - m).sum(axis=1, keepdims=True)), vocab

def viterbi(logp, tokens, blank=0):
    """CTC forced alignment. Returns, for each token, the first frame it is emitted."""
    import numpy as np
    T, S = logp.shape[0], 2 * len(tokens) + 1
    ext = [blank] * S
    for i, t in enumerate(tokens): ext[2 * i + 1] = t
    ext = np.array(ext)
    if T < len(tokens): return None
    NEG = -1e30
    can_skip = np.zeros(S, bool)
    for s in range(3, S, 2): can_skip[s] = ext[s] != ext[s - 2]
    score = np.full(S, NEG); score[0] = logp[0, ext[0]]; score[1] = logp[0, ext[1]]
    back = np.zeros((T, S), np.int8)
    for t in range(1, T):
        stay = score
        step = np.concatenate(([NEG], score[:-1]))
        skip = np.where(can_skip, np.concatenate(([NEG, NEG], score[:-2])), NEG)
        stack = np.vstack([stay, step, skip])
        choice = stack.argmax(axis=0)
        score = stack[choice, np.arange(S)] + logp[t, ext]
        back[t] = choice
    s = S - 1 if score[S - 1] >= score[S - 2] else S - 2
    first = [None] * len(tokens); last = [None] * len(tokens)
    for t in range(T - 1, -1, -1):
        if s % 2 == 1:
            first[s // 2] = t
            if last[s // 2] is None: last[s // 2] = t
        s -= int(back[t, s])
        if s < 0: break
    return first, last

def align_cue(audio, sr, cue, duration):
    """Aligned start times (seconds) for each word of one sentence/cue."""
    words = cue.get('words') or []
    if not words: return {}
    a = max(0.0, float(cue['start']) - PAD); b = min(duration, float(cue['end']) + PAD)
    seg = audio[int(a * sr):int(b * sr)]
    if len(seg) < sr * 0.2: return {}
    logp, vocab = emissions(seg)
    sep = vocab.get('|'); blank = vocab.get('<pad>', 0)
    tokens, owner = [], []
    for wi, w in enumerate(words):
        chars = [vocab[c] for c in spoken(w['text']).replace(' ', '|') if c in vocab]
        if not chars: continue
        if tokens and sep is not None: tokens.append(sep); owner.append(None)
        for k, c in enumerate(chars): tokens.append(c); owner.append((wi, k == 0))
    if not tokens: return {}
    got = viterbi(logp, tokens, blank)
    if got is None: return {}
    first, last = got
    out = {}; prev_end = None
    for i, o in enumerate(owner):
        if o is None: continue
        wi, is_first = o
        if is_first and first[i] is not None:
            out[wi] = (a + first[i] * STRIDE, prev_end)
        if last[i] is not None: prev_end = a + last[i] * STRIDE
    return out

def align_starts(p):
    """{whisper word start (rounded) : aligned start} for the whole recording."""
    src = p.get('source') or ''
    if not src:
        try:
            from speech_follow import _previous_audio
            src = _previous_audio(p)
        except Exception: src = ''
    if not src: STATUS['ok'] = 'no audio'; return {}
    try:
        from faster_whisper.audio import decode_audio
        audio = decode_audio(str(src), sampling_rate=16000)
    except Exception:
        import numpy as np, wave
        with wave.open(str(src), 'rb') as w:
            ch, hz, n = w.getnchannels(), w.getframerate(), w.getnframes()
            x = np.frombuffer(w.readframes(n), np.int16).astype(np.float32).reshape(-1, ch).mean(axis=1) / 32768
        step = max(1, round(hz / 16000)); audio = x[:len(x) // step * step].reshape(-1, step).mean(axis=1)
    duration = float(p.get('duration') or len(audio) / 16000)
    result, moved = {}, []
    REPORT.clear()
    try:
        for cue in p.get('cues') or []:
            got = align_cue(audio, 16000, cue, duration)
            for wi, (spike, prev_end) in got.items():
                w = cue['words'][wi]; t0 = float(w['start'])
                t = max(0.0, spike - LEAD)   # the character model fires ~1 frame after the sound starts
                REPORT.append(dict(text=w['text'], whisper=round(t0, 3), spike=round(spike, 3),
                                   prev_end=None if prev_end is None else round(prev_end, 3), final=round(t, 3)))
                # sanity: forced alignment never moves a word more than 0.5 s
                if abs(t - t0) <= 0.5:
                    result[round(t0, 3)] = round(t, 3); moved.append(t - t0)
        STATUS.update(ok=True, words=len(result), mean_shift_ms=round(1000 * sum(moved) / len(moved)) if moved else 0)
    except Exception as exc:
        STATUS['ok'] = repr(exc); return {}
    return result
