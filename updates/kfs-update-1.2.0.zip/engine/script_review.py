"""Compare the selected script with captions without inventing speech or timing."""
import re
import unicodedata
from difflib import SequenceMatcher


def tokens(text):
    value = unicodedata.normalize('NFKC', str(text)).replace('\u2019', "'")
    return [(m.group(), m.group().casefold().replace("'", ''))
            for m in re.finditer(r"\w+(?:'\w+)*", value)]


def compare(script, groups):
    expected = tokens(script)
    if not expected:
        return None
    heard = [(word, key, float(row['start']), float(row['end']))
             for row in groups for word, key in tokens(row['text'])]
    differences = []
    missing = 0
    for tag, a, b, c, d in SequenceMatcher(
            None, [w[1] for w in heard], [w[1] for w in expected],
            autojunk=False).get_opcodes():
        if tag == 'equal':
            continue
        missing += d - c
        anchor = heard[a] if a < len(heard) else heard[-1] if heard else None
        differences.append(dict(
            expected=' '.join(w[0] for w in expected[c:d]),
            detected=' '.join(w[0] for w in heard[a:b]),
            near=anchor[2] if anchor else None,
            before=' '.join(w[0] for w in expected[max(0, c-5):c]),
            after=' '.join(w[0] for w in expected[d:d+5])))
    return dict(expected_words=len(expected), detected_words=len(heard),
                unmatched_script_words=missing, needs_review=bool(differences),
                differences=differences[:100], total_differences=len(differences))
