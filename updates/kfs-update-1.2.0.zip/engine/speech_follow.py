"""Speech-following caption timing (local patch).

Each caption appears on its first spoken word and clears shortly after its
last word. Short pauses are bridged to avoid flicker; real pauses show no
caption. Manually edited rows keep their exact start/end.
"""
import copy,math

LEAD=0.0      # captions appear exactly on the measured onset
HOLD=0.30     # keep text up briefly after the last word
BRIDGE=0.45   # pauses shorter than this keep the caption up until the next one

HOP=0.01  # 10 ms analysis frames
ONSET={'ok':None}

def _speech_band_db(path):
 """Per-10ms loudness (dB) in the speech band 250-4000 Hz of the exported audio."""
 import numpy as np
 audio=None
 try:
  from faster_whisper.audio import decode_audio
  audio=decode_audio(str(path),sampling_rate=16000)
 except Exception:
  import wave
  with wave.open(str(path),'rb') as w:
   ch,hz,width,n=w.getnchannels(),w.getframerate(),w.getsampwidth(),w.getnframes()
   raw=w.readframes(n)
  dtype={1:np.int8,2:np.int16,4:np.int32}[width]
  x=np.frombuffer(raw,dtype=dtype).astype(np.float32)
  x=x.reshape(-1,ch).mean(axis=1)/float(np.iinfo(dtype).max)
  step=max(1,round(hz/16000));audio=x[:len(x)//step*step].reshape(-1,step).mean(axis=1) if step>1 else x
 x=np.asarray(audio,dtype=np.float32);sr=16000;hop=160;win=400
 if len(x)<win:return None
 n=1+(len(x)-win)//hop
 idx=np.arange(win)[None,:]+hop*np.arange(n)[:,None]
 frames=x[idx]*np.hanning(win).astype(np.float32)
 out=np.empty(n,dtype=np.float32)
 freqs=np.fft.rfftfreq(512,1/sr);band=(freqs>=100)&(freqs<=7900)
 for k in range(0,n,4096):
  spec=np.abs(np.fft.rfft(frames[k:k+4096],512,axis=1))**2
  out[k:k+4096]=10*np.log10(spec[:,band].sum(axis=1)+1e-10)
 # frame k is centred at k*hop+win/2 samples; shift so index = time/HOP
 shift=int(round((win/2)/hop))
 return np.concatenate([np.full(shift,out[0]),out])

def measured_onset(db,t0,lo,hi,prev_t=None,next_t=None):
 """Where speech actually starts near the transcript estimate t0.

 After a pause: the first frame where speech-band energy rises clearly above
 the local noise floor and stays up. Inside continuous speech: the energy dip
 between words closest to t0. Returns None when the audio is not decisive.
 """
 import numpy as np
 n=len(db);k0=int(round(t0/HOP))
 a,b=max(0,int((t0-1.2)/HOP)),min(n,int((t0+1.2)/HOP))
 if b-a<20:return None
 local=db[a:b];peak=float(np.percentile(local,95))
 # noise floor from a wider window, so a quiet s/sh/f is never mistaken for silence
 floor=float(np.percentile(db[max(0,int((t0-6)/HOP)):min(n,int((t0+6)/HOP))],5))
 if peak-floor<12:return None
 thr=floor+max(8.,.35*(peak-floor));quiet=floor+.25*(peak-floor)
 L,H=max(1,int(lo/HOP)),min(n-6,int(hi/HOP))
 cands=[]
 for k in range(L,H+1):
  # Only a REAL pause counts: >=150 ms near the noise floor right before the
  # rise. Short gaps inside words (t, k, p, s sounds) are ignored.
  if k<15:continue
  if db[k]>=thr and (db[k-15:k]<quiet).all() and (db[k:k+6]>=thr).sum()>=5:
   j=k
   while j>0 and db[j-1]>floor+.5*(quiet-floor) and k-j<4:j-=1
   cands.append(j)
 def near(j,limit):
  t=j*HOP
  if abs(t-t0)>limit:return False
  for nb in (prev_t,next_t):
   if nb is not None and abs(t-nb)<abs(t-t0):return False
  return True
 cands=[j for j in cands if near(j,.3)]
 if cands:return min(cands,key=lambda j:abs(j-k0))*HOP
 # Short but real silent gap between words (>=70 ms, >=15 dB below the speech
 # that follows). Stop consonants inside words are shorter than this. Only
 # accepted near the transcript estimate and closer to it than to neighbours.
 cands=[]
 quiet2=floor+.5*(peak-floor)   # gap must be near-silent, not a quiet s/sh/f sound
 prevok=False
 for k in range(max(L,7),min(H,n-10)+1):
  after=float(np.median(db[k+2:k+10]))
  gap=float(db[k-7:k].max())
  hit=gap<=after-15 and gap<=quiet2 and db[k]>db[k-1]+3
  if hit and not prevok:cands.append(k)
  prevok=hit
 cands=[j for j in cands if near(j,.18)]
 if cands:return min(cands,key=lambda j:abs(j-k0))*HOP
 # Continuous speech (no pause): keep the speech model's own word timing.
 return None

def _previous_audio(p):
 """Rebuilds don't re-export audio: reuse this sequence's last exported WAV."""
 import json
 from pathlib import Path
 root=Path.home()/'Documents'/'Kandy For Scale Captions'
 try:folders=sorted((d for d in root.iterdir() if d.is_dir()),reverse=True)
 except Exception:return ''
 for d in folders[:200]:
  wav=d/'sequence.wav'
  if not wav.is_file():continue
  try:seq=json.loads((d/'result.json').read_text(encoding='utf-8')).get('sequence',{})
  except Exception:continue
  if seq.get('name')==p.get('name') and abs(float(seq.get('duration',-1))-float(p['duration']))<.05:return str(wav)
 return ''

def refine_onsets(p,rows):
 """Move each caption start onto the measured speech onset in the audio."""
 src=p.get('source') or '' or _previous_audio(p)
 if not src:ONSET['ok']='no audio file';return {}
 try:db=_speech_band_db(src)
 except Exception as exc:ONSET['ok']=repr(exc);return {}
 if db is None:ONSET['ok']='audio too short';return {}
 out={};moved=[];prev_start=-1.;prev_onset=-1.
 for i,r in enumerate(rows):
  words=[w for w in r.get('words') or [] if 'start' in w and 'end' in w]
  if not words:continue
  t0=float(words[0]['start']);lo=max(prev_start+.08,prev_onset+.15,t0-.4);hi=min((float(words[1]['start'])-.03) if len(words)>1 else float(words[0]['end'])+.2,t0+.35)
  prev_start=float(words[-1]['start'])
  if hi<=lo:continue
  nxt=float(words[1]['start']) if len(words)>1 else None
  t=measured_onset(db,t0,lo,hi,prev_start if prev_start>=0 else None,nxt)
  if t is not None:out[i]=t;moved.append(t-t0)
  prev_onset=out.get(i,t0)
 ONSET['ok']=True;ONSET['moved']=len(moved);ONSET['mean_shift_ms']=round(1000*sum(moved)/len(moved)) if moved else 0
 return out

def speech_groups(p,rows,manual=False):
 if not rows:return rows
 rows=copy.deepcopy(rows);duration=float(p['duration'])
 if not manual:
  # 1) frame-accurate word starts from forced alignment (if installed)
  try:
   from speech_align import align_starts
   amap=align_starts(p)
  except Exception:amap={}
  for r in rows:
   for w in r.get('words') or []:
    k=round(float(w.get('start',-1)),3)
    if k in amap:w['start']=amap[k]
 # 2) exact onsets after real pauses, measured from the audio energy
 onsets={} if manual else refine_onsets(p,rows)
 spans=[]
 for i,r in enumerate(rows):
  words=[w for w in r.get('words') or [] if 'start' in w and 'end' in w]
  if manual or not words:spans.append((float(r['start']),float(r['end'])));continue
  start=onsets.get(i,float(words[0]['start']))
  spans.append((max(0.,start-LEAD),max(float(words[-1]['end']),start+.1)))
 out=[];prev_end=0.
 for i,(r,(a,last)) in enumerate(zip(rows,spans)):
  a=max(a,prev_end)
  nxt=spans[i+1][0] if i+1<len(spans) else duration
  if manual:b=min(last,nxt)
  elif nxt-last<=BRIDGE:b=nxt
  else:b=min(last+HOLD,nxt)
  b=min(b,duration)
  if b-a<1/30:continue
  r['start'],r['end']=round(a,4),round(b,4);out.append(r);prev_end=b
 return out

MAX_CHARS=22    # per line, spaces included
SOFT_MAX=25     # a phrase may run up to this long instead of being cut badly
OVER_COST=45    # cost per character above MAX_CHARS
MIN_SHOW=0.8    # captions spoken faster than this count as flashing
BLOCK_PAUSE=1.0 # a pause this long always ends a caption
SUBJECTS={'i','you','we','they','he','she','it'}
# Words that must stay with what follows (verb chains, determiners, preps).
GLUE={'will','would','can','could','should','must','may','might','shall','do','does','did',
 'am','is','are','was','were','be','been','being','have','has','had','not',"n't",'to',
 'a','an','the','my','your','his','her','our','their','its','this','that','these','those',
 'some','any','every','each','no','very','so','too','more','most','dr','mr','mrs','ms','mx'}
# Words that naturally open a new phrase: conjunctions, subordinators, prepositions.
CLAUSE_OPENERS={'and','but','or','so','because','before','after','when','while','if','until','since',
 'although','though','unless','whereas','then'}
PREPS={'for','on','in','at','with','from','into','onto','over','under','during','without','about',
 'through','by','near','behind','across','like'}
# Verbs that take "to + verb" as one phrase: wants to learn, going to try.
TO_VERBS={'want','wants','wanted','need','needs','needed','going','gonna','try','tries','tried','trying',
 'have','has','had','like','likes','liked','love','loves','loved','hate','able','used','start','started',
 'begin','began','decide','decided','plan','plans','planned','hope','hoped','learn','learned','seem','seems','seemed','ought'}
SYNTAX={'ok':None}
TUNE=dict(to=40,pp=210,base=30,lw=12,lt=14,numnp=60)  # tuned on the editor's confirmed splits
DETS={'a','an','the','my','your','his','her','our','their','its','this','that','these','those'}
PARTICLES={'back','up','down','out','off','away','around','over'}

def syntax_costs(words):
 """Dependency-parse penalties for cutting before word j (spaCy, bundled model).

 Never split: inside a noun phrase or name (+150), a preposition from its
 object (+120), an auxiliary/particle/infinitive from its verb (+130..150).
 Verb from its object is a soft split (+50, allowed when space runs out).
 Boundaries between a verb's separate phrases (subject clause / time phrase /
 'and ...' / 'before ...' / 'on the table') are preferred (-15).
 """
 from bisect import bisect_right
 from ugc import caption_language
 raw=[str(w.get('raw',w['text'])) for w in words]
 starts=[];cursor=0
 for r in raw:starts.append(cursor);cursor+=len(r)+1
 with caption_language.LOCK:doc=caption_language.pipeline()(' '.join(raw))
 owner=lambda t:max(0,min(len(raw)-1,bisect_right(starts,t.idx)-1))
 content=[t for t in doc if not t.is_punct]
 last={};first={}
 for t in content:
  o=owner(t);last[o]=t;first.setdefault(o,t)
 def chain(t):
  out=[t]
  while out[-1].head.i!=out[-1].i:out.append(out[-1].head)
  return out
 NOUNY={'NOUN','PROPN','PRON','NUM'};CHAIN={'aux','auxpass','neg'}
 SEP={'prep','advcl','advmod','npadvmod','cc','conj','mark','relcl','ccomp','punct','intj','dep','parataxis'}
 OBJ={'dobj','attr','acomp','oprd','dative','pobj','iobj'}
 costs={}
 for j in range(1,len(raw)):
  a,b=last.get(j-1),first.get(j)
  if a is None or b is None:continue
  if a.pos_=='PROPN' and b.pos_=='PROPN':costs[j]=200;continue
  ca_path=chain(a);cb_path=chain(b);cb_ids={t.i for t in cb_path}
  L=next((t for t in ca_path if t.i in cb_ids),None)
  if L is None:costs[j]=-15;continue           # separate sentences
  ca=ca_path[[t.i for t in ca_path].index(L.i)-1] if a.i!=L.i else None
  cb=cb_path[[t.i for t in cb_path].index(L.i)-1] if b.i!=L.i else None
  if L.pos_ in NOUNY and ca is None and cb is not None and cb.dep_=='cc' and b.i==a.i+1:c=10   # "trapped fluid / and waste"
  elif L.pos_ in NOUNY and a.pos_=='NUM' and ca is not None and ca.i==a.i and b.pos_ in ('NOUN','PROPN'):c=TUNE['numnp']   # "stage 3 / kidney disease"
  elif L.pos_ in NOUNY:c=-5 if cb is not None and ca is None and cb.dep_ in ('relcl','acl') and min(x.i for x in cb.subtree)==b.i else 150
  elif L.pos_=='ADP':c=120
  elif L.pos_ in {'VERB','AUX'}:
   if cb is None:                              # dependent | verb
    c=150 if ca.dep_ in CHAIN else (-10 if ca.pos_ in ('NOUN','PROPN') and len(list(ca.subtree))>=2 else 40) if ca.dep_ in {'nsubj','nsubjpass','expl','csubj'} else -15 if ca.dep_ in SEP else 30
   elif ca is None:                            # verb | dependent
    c=150 if cb.dep_=='prt' else 45 if cb.dep_=='prep' and b.i==a.i+1 and len(list(cb.subtree))<=4 else 130 if cb.dep_ in {'xcomp'}|CHAIN else 50 if cb.dep_ in OBJ else -15 if cb.dep_ in SEP else 30
   else:                                       # dependent | dependent
    if cb.dep_ in CHAIN or ca.dep_ in CHAIN:c=100
    elif cb.dep_ in OBJ:c=50                   # "turn off / the lights"
    elif ca.dep_ in {'nsubj','nsubjpass','expl'} and cb.dep_ not in SEP:c=40
    else:c=-15
  else:c=20
  costs[j]=c
 # Prepositional phrases: (preposition word, object start, object end) so a
 # long "from + stage 3 kidney disease" can drop the preposition instead of
 # cutting through the noun phrase.
 pps=[]
 for t in doc:
  if t.dep_=='pobj' and t.head.pos_=='ADP':
   sub=list(t.subtree);pps.append((owner(t.head),owner(sub[0]),owner(sub[-1])+1))
 costs['_pp']=pps
 costs['_pos']={o:t.pos_ for o,t in last.items()}
 return costs

LEARN={'ok':None}
def _norm(t):
 import re
 return re.sub(r"[^a-z0-9%']","",str(t).lower().replace('\u2019',"'"))
def learned():
 """Editors' caption fixes (this Mac + optional shared team folder).
 Returns exact sentence memory and word-pair cut statistics."""
 import json
 from pathlib import Path
 base=(Path.home()/'Library'/'Application Support' if __import__('sys').platform=='darwin' else Path(__import__('os').environ.get('LOCALAPPDATA') or Path.home()))/'KandyForScaleCaptions'/'learned'
 files=[base/'seed.jsonl',base/'corrections.jsonl']
 try:team=json.loads((base/'config.json').read_text(encoding='utf-8')).get('team')
 except Exception:team=None
 if team and Path(team).is_dir():files+=sorted(Path(team).glob('corrections-*.jsonl'))
 latest={}
 for f in files:
  try:lines=f.read_text(encoding='utf-8',errors='ignore').splitlines() if f.is_file() else []
  except Exception:lines=[]
  for line in lines:
   try:
    e=json.loads(line);w=[str(x) for x in e['words']];cuts=sorted({int(c) for c in e['cuts'] if 0<int(c)<len(w)})
    latest[(e.get('user',''),' '.join(w))]=(w,cuts)
   except Exception:continue
 mem={};pair={}
 for w,cuts in latest.values():
  if len(w)>=3:mem.setdefault(w[0],[]).append((tuple(w),set(cuts)))
  for j in range(1,len(w)):
   k=(w[j-1],w[j]);a,b=pair.get(k,(0,0));pair[k]=(a+(j in cuts),b+(j not in cuts))
 LEARN.update(ok=True,sentences=len(latest))
 return mem,pair

def char_limit(p,groups,limit=MAX_CHARS,manual=False):
 """Re-phrase the timed word stream into readable captions.

 Each line holds at most `limit` characters; a caption uses one or two lines
 (panel setting). Cuts never split a verb phrase, noun phrase or name when
 any alternative exists (the engine's spaCy parse marks those). Cuts prefer
 real pauses, sentence/clause ends and phrase openers (and, before, after,
 on, for...). When a phrase is longer than the limit it is chunked into
 short 1-3 word pieces at the least harmful points.
 """
 from ugc.caption_timeline import caption_text
 from ugc.caption_phrases import token,terminal,language_edges
 from ugc.caption_numbers import boundaries as numbers
 two=int(p.get('caption_max_lines',2))!=1
 try:mem,pair=learned()
 except Exception as exc:mem,pair={},{};LEARN['ok']=repr(exc)
 blocks=[]
 for g in groups:
  ws=[dict(w,_g=id(g)) for w in g.get('words') or []]
  if not ws:blocks.append(('raw',g));continue
  prev=blocks[-1] if blocks and blocks[-1][0]=='words' else None
  joined=prev and not manual and not ws[0].get('caption_break_before') and float(ws[0]['start'])-float(prev[1][-1]['end'])<BLOCK_PAUSE
  if joined:prev[1].extend(ws);prev[2][id(g)]=g
  else:blocks.append(('words',ws,{id(g):g}))
 out=[]
 for b in blocks:
  if b[0]=='raw':out.append(b[1]);continue
  words,owners=b[1],b[2];n=len(words)
  try:
   hard,_,hints,safe=language_edges(words);SYNTAX['ok']=True
  except Exception as exc:
   hard,hints,safe=set(),{},set(range(n+1));SYNTAX['ok']=repr(exc)
  try:syn=syntax_costs(words);SYNTAX['parse']=True
  except Exception as exc:syn={};SYNTAX['parse']=repr(exc)
  try:numeric=numbers([w.get('raw',w['text']) for w in words])
  except Exception:numeric=set()
  L=lambda i,j:len(caption_text(p,words[i:j]))
  if manual and len(owners)==1 and L(0,n)<=(SOFT_MAX*2 if two else SOFT_MAX+8):out.append(next(iter(owners.values())));continue
  punct=lambda w:str(w.get('raw',w['text'])).rstrip('"\'”').endswith((',',';',':','—','-'))
  toks=[_norm(w.get('raw',w['text'])) for w in words];forced={}
  for o in range(n):
   for seq,cuts in mem.get(toks[o],()):
    if tuple(toks[o:o+len(seq)])==seq:
     for q in range(1,len(seq)):forced[o+q]=q in cuts
  memo={}
  def cut_cost(j):
   if j in memo:return memo[j]
   if j in (0,n):return 0.
   a,b=words[j-1],words[j];ta,tb=token(a),token(b)
   gap=max(0.,float(b['start'])-float(a['end']))
   c=-min(gap,.6)*45+max(-20.,min(20.,hints.get(j,0)))
   if terminal(a):c-=40
   elif punct(a):c-=18
   if j in hard:c-=8
   if tb in CLAUSE_OPENERS and not terminal(a):c-=32
   elif tb in PREPS and not terminal(a):c-=10
   if tb=='to' and ta in TO_VERBS:c+=TUNE['to']          # "wants / to learn"
   if not syn and j>=2 and token(words[j-2]) in CLAUSE_OPENERS and not terminal(a) and not punct(a):c+=30  # fallback only
   # never-split rules
   if j not in safe and not (punct(a) and gap>=.25):c+=120   # engine: inside NP / VP / name / PP (a spoken comma pause overrides it)
   if ta in GLUE or ta.endswith("'s") and str(b['text'])[:1].islower():c+=90
   if ta in CLAUSE_OPENERS or ta in PREPS:c+=150  # never end on and/before/on...
   if ta in SUBJECTS:c+=60                       # "it / changed"
   la,lb=str(a['text']),str(b['text'])
   if la[:1].isupper() and lb[:1].isupper() and ta not in SUBJECTS and not terminal(a):c+=150  # names
   if gap<.08 and not terminal(a) and not punct(a):c+=6
   c+=syn.get(j,0)
   pos=syn.get('_pos',{})
   if j>=2 and token(words[j-2]) in DETS and pos.get(j-1) in ('ADJ','NUM'):c+=100   # "your lower / back"
   if pos.get(j-1)=='VERB' and tb in PARTICLES:c+=200
   if pos.get(j-1) in ('VERB','AUX') and tb in ('them','him','me','us','it','her') and not terminal(a) and not punct(a):c+=120   # "causing / them"
   if ta in ('it','there','this','he','she','they','we','you','i') and pos.get(j) in ('AUX','VERB') and not terminal(a) and not punct(a):c+=80   # "But it / keeps"
   if ta in DETS and not terminal(a):c+=150                                         # never end on a/the/your
   if ta in ('very','so','too','really','super','extremely','pretty'):c+=80                # "very / different"                            # "coming / back"
   for pp,s0,e0 in syn.get('_pp',()):
    if s0==j and pp==j-1 and L(pp,e0)>SOFT_MAX and L(s0,e0)<=SOFT_MAX:c-=TUNE['pp']   # keep the noun phrase whole
   if j in numeric:c+=1000
   if b.get('caption_break_before'):c-=1000
   if j in forced:c+=-400 if forced[j] else 400       # an editor fixed this exact sentence
   else:
    k=pair.get((toks[j-1],toks[j]))
    if k:c+=max(-90.,min(90.,35*math.log((k[1]+1)/(k[0]+1))))   # editors' habits for this word pair
   memo[j]=c;return c
  def stranded(i,j):
   """Cost of showing words[i:j] (one word) alone: fine for a full phrase like
   'yesterday' or 'Spanish', bad for a leftover piece of a phrase."""
   bad=token(words[i]) in GLUE or token(words[i]) in CLAUSE_OPENERS or token(words[i]) in PREPS
   for edge in (i,j):
    if 0<edge<n and (edge not in safe or syn.get(edge,0)>=100):bad=True
   return 48 if bad else 8
  def layout(i,j):
   if L(i,j)<=limit or j-i==1:return (0.,0)
   if not two:return (80+OVER_COST*(L(i,j)-limit),0) if L(i,j)<=SOFT_MAX else None
   best=None
   for k in range(i+1,j):
    x,y=L(i,k),L(k,j)
    if x>limit or y>limit:continue
    c=8+abs(x-y)*.25+cut_cost(k)
    if j-i>=3 and (k-i==1 or j-k==1):c+=stranded(i,k) if k-i==1 else stranded(k,j)
    if best is None or c<best[0]:best=(c,k-i)
   return best
  cost={0:0.};back={}
  for j in range(1,n+1):
   for i in range(j-1,-1,-1):
    if i+1<j and (words[i+1].get('caption_break_before') or float(words[i+1]['start'])-float(words[i]['end'])>=BLOCK_PAUSE):break
    if L(i,j)>(2*limit+1 if two else SOFT_MAX) and j-i>1:break
    if i not in cost:continue
    lay=layout(i,j)
    if lay is None:continue
    span=float(words[j-1]['end'])-float(words[i]['start'])
    c=cost[i]+TUNE['base']+lay[0]+cut_cost(j)+TUNE['lw']*max(0,L(i,j)-TUNE['lt'])
    c+=120*sum(1 for x in range(i,j-1) if terminal(words[x]))  # keep sentences in their own captions
    if span<MIN_SHOW:c+=(MIN_SHOW-span)*25
    shown=(float(words[j]['start']) if j<n else float(words[-1]['end'])+HOLD)-float(words[i]['start'])
    if shown<.3:c+=220  # a flash, not a phrase
    if j-i==1 and n>1:c+=stranded(i,j)
    if j not in cost or c<cost[j]:cost[j]=c;back[j]=(i,lay[1])
  if n not in back:
   out.extend(owners.values());continue
  pieces=[];j=n
  while j:i,k=back[j];pieces.append((i,j,k));j=i
  pieces.reverse()
  for i,j,k in pieces:
   r=copy.deepcopy(owners[words[i]['_g']])
   for key in ('line_break','scene_continuation'):r.pop(key,None)
   r['words']=[{x:v for x,v in w.items() if x!='_g'} for w in words[i:j]]
   r['text']=caption_text(p,r['words'])
   if k:r['line_break']=len(caption_text(p,r['words'][:k]).split())
   r['start']=float(words[i]['start']);r['end']=float(words[j]['start']) if j<n else float(words[-1]['end'])
   out.append(r)
 return out
