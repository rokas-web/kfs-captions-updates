"""Shows how the patched engine splits example sentences (no project is touched)."""
import sys
from pathlib import Path
engine=Path(sys.argv[1]);bundle=Path(sys.argv[2])
sys.path.insert(0,str(engine))
from ugc import captions,caption_language
captions.BASE=bundle;caption_language.BASE=bundle
from speech_follow import char_limit,SYNTAX
EXAMPLES=["I went to the store yesterday and bought some groceries for dinner.",
"When the rain stopped, the children ran outside to play.",
"She wants to learn Spanish before her trip to Mexico.",
"Please turn off the lights before you leave.",
"I left the keys on the kitchen counter.",
"She bought a powerful new computer for her design work.",
"Dr. Elena Ramirez will speak after lunch."]
for lines in (2,1):
 print(f"\n=== {lines} line(s) per caption, max 22 characters per line ===")
 for text in EXAMPLES:
  words=[];t=0.
  for raw in text.split():
   words.append(dict(start=round(t,2),end=round(t+.28,2),text=raw.strip('.,!?'),raw=raw));t+=.32
  p=dict(duration=t+1,caption_max_lines=lines,caption_punctuation=False)
  rows=char_limit(p,[dict(start=0,end=t,words=words,text=text,sentence_id=0)])
  shown=[]
  for r in rows:
   ws=r['text'].split();k=r.get('line_break',0)
   shown.append(' / '.join([' '.join(ws[:k]),' '.join(ws[k:])]) if k else r['text'])
  print('  '+'  |  '.join(shown))
# Splits the editor confirmed (real speech timing). Every update must keep them.
CONFIRMED=[
 ([["3",0.0,0.28],["warning",0.28,0.64],["signs",0.64,1.04],["you",1.04,1.36],["are",1.36,1.42],["going",1.42,1.58],["to",1.58,1.76],["die",1.76,2.0],["early",2.0,2.38],["from",2.38,2.82],["stage",2.82,3.12],["3",3.12,3.56],["kidney",3.56,3.92],["disease.",3.92,4.5]],
  "3 warning signs | you are going | to die early | from stage 3 | kidney disease"),
 ([["Dandelion",151.94,152.36],["root,",152.36,152.66],["flushes",153.0,153.38],["trapped",153.38,153.8],["fluid",153.8,154.16],["and",154.16,154.48],["waste",154.48,154.74],["from",154.74,155.0],["your",155.0,155.18],["kidney",155.18,155.48],["tissue",155.48,155.88]],
  "Dandelion root | flushes trapped fluid | and waste | from your kidney tissue"),
]
print("\n=== Your confirmed splits ===")
for raw,want in CONFIRMED:
 words=[dict(start=a,end=b,text=t.strip('.,!?'),raw=t) for t,a,b in raw]
 p=dict(duration=raw[-1][2]+1,caption_max_lines=1,caption_punctuation=False)
 got=' | '.join(r['text'] for r in char_limit(p,[dict(start=words[0]['start'],end=words[-1]['end'],words=words,text=' '.join(t for t,_,_ in raw),sentence_id=0)]))
 print(('  OK    ' if got==want else '  CHANGED  ')+got+('' if got==want else '   (expected: '+want+')'))
print('\nSyntax engine:', 'loaded' if SYNTAX['ok'] is True else f'NOT loaded ({SYNTAX["ok"]})')
