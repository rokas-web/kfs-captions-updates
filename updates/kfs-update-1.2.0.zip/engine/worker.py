"""Standalone Premiere companion worker; desktop app entrypoints stay separate."""
import sys,os,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))

def setup(bundle):
 bundle=Path(bundle).resolve();os.environ['PATH']=str(bundle)+os.pathsep+os.environ.get('PATH','')
 if (bundle/'fonts.conf').is_file():os.environ.setdefault('FONTCONFIG_FILE',str(bundle/'fonts.conf'))
 from ugc import captions,caption_language,media
 captions.BASE=bundle;caption_language.BASE=bundle;media.BASE=bundle
 from ugc import speech
 speech.worker_command=lambda folder:[sys.executable,str(ROOT/'worker.py'),'--speech-worker',str(bundle),str(folder)]
 return bundle

if __name__=='__main__':
 try:
  bundle=setup(sys.argv[2])
  if sys.argv[1]=='--speech-worker':
   from ugc.speech import worker_main
   worker_main(sys.argv[3])
  else:
   import importlib.util
   spec=importlib.util.spec_from_file_location('kandy_bridge',ROOT/'bridge.py');bridge=importlib.util.module_from_spec(spec);spec.loader.exec_module(bridge)
   request=Path(sys.argv[3]).resolve()
   bridge.process(json.loads(request.read_text(encoding='utf-8')),bundle,request.parent)
 except Exception as e:
  print(json.dumps({'message':'Error: '+str(e),'progress':0}),flush=True);sys.exit(1)
