/* Caption imports target the captured sequence. QE adds one video-only top track. */
var KandyForScaleCaptions = (function () {
 function serialize(value){
  if(typeof JSON!=='undefined'&&JSON.stringify)return JSON.stringify(value);
  function quote(text){return '"'+String(text).replace(/[\\"\x00-\x1f\u2028\u2029]/g,function(c){var hex=c.charCodeAt(0).toString(16);return c==='"'?'\\"':c==='\\'?'\\\\':'\\u'+('0000'+hex).slice(-4);})+'"';}
  function encode(v){if(v===null||typeof v==='undefined')return 'null';if(typeof v==='string')return quote(v);if(typeof v==='number')return isFinite(v)?String(v):'null';if(typeof v==='boolean')return String(v);var rows=[];if(v instanceof Array){for(var i=0;i<v.length;i++)rows.push(encode(v[i]));return '['+rows.join(',')+']';}for(var key in v)if(Object.prototype.hasOwnProperty.call(v,key)&&typeof v[key]!=='function'&&typeof v[key]!=='undefined')rows.push(quote(key)+':'+encode(v[key]));return '{'+rows.join(',')+'}';}
  return encode(value);
 }
 function fileFilter(extensions){return $.os.indexOf('Windows')>=0?'*.'+extensions.join(';*.'):function(f){return f instanceof Folder||new RegExp('\\.('+extensions.join('|')+')$','i').test(f.name);};}
 function result(value){return serialize(value);}
 function protect(fn){try{return result(fn());}catch(e){return result({error:e.message});}}
 function seq(id){var s=app.project.activeSequence;if(!s)throw Error('Open a sequence first.');if(id && s.sequenceID!==id)throw Error('The active sequence changed. Return to the original sequence before adding captions.');return s;}
 function find(item,path){if(item.getMediaPath && item.getMediaPath()===path)return item;if(item.children)for(var i=0;i<item.children.numItems;i++){var x=find(item.children[i],path);if(x)return x;}return null;}
 function sceneEvidence(s,duration){
  var clips=[],points=[0,duration],cuts=[],sources=[];
  for(var t=0;t<s.videoTracks.numTracks;t++){
   var track=s.videoTracks[t];if(track.isMuted&&track.isMuted())continue;
   for(var i=0;i<track.clips.numItems;i++){
    var c=track.clips[i],path=c.projectItem.getMediaPath?c.projectItem.getMediaPath():'';
    // Escape literal slashes explicitly for ExtendScript's older regexp parser.
    if(c.disabled||/Kandy For Scale Captions\/|caption_\d+\.png$/i.test(path.replace(/\\/g,'/')))continue;
    if(c.isAdjustmentLayer&&c.isAdjustmentLayer())continue;
    var a=Math.max(0,c.start.seconds),b=Math.min(duration,c.end.seconds);if(!(b>a))continue;
    clips.push({clip:c,path:path,track:t,key:t+':'+i,start:a,end:b});points.push(a);points.push(b);
   }
  }
  points.sort(function(a,b){return a-b;});var unique=[];for(var p=0;p<points.length;p++)if(!p||points[p]-points[p-1]>.00001)unique.push(points[p]);
  var previous=null,lastSourceKey='';
  for(var j=0;j+1<unique.length;j++){
   var start=unique[j],end=unique[j+1],middle=(start+end)/2,visible=null;
   for(var k=0;k<clips.length;k++)if(clips[k].start<=middle&&middle<clips[k].end&&(!visible||clips[k].track>visible.track))visible=clips[k];
   if(j&&((visible&&visible.key)!==(previous&&previous.key)))cuts.push(start);
   if(visible&&visible.path&&/\.(mp4|mov|mxf|avi|mkv|webm|m4v)$/i.test(visible.path)){
    var v=visible.clip;
    if(v.getSpeed&&v.isSpeedReversed&&v.getSpeed()===1&&!v.isSpeedReversed()){
     var last=sources.length?sources[sources.length-1]:null;
     if(last&&lastSourceKey===visible.key&&Math.abs(last.end-start)<.00001)last.end=end;
     else sources.push({path:visible.path,start:start,end:end,sourceStart:v.inPoint.seconds+start-v.start.seconds});
     lastSourceKey=visible.key;
    }
   }
   previous=visible;
  }
  return {cuts:cuts,sources:sources};
 }
 function info(){var s=seq(),settings=s.getSettings(),duration=Number(s.end)/254016000000,evidence=sceneEvidence(s,duration);return {id:s.sequenceID,name:s.name,duration:duration,width:settings.videoFrameWidth,height:settings.videoFrameHeight,fps:1/settings.videoFrameRate.seconds,tracks:s.videoTracks.numTracks,sceneCuts:evidence.cuts,sceneSources:evidence.sources,appPath:app.path};}
 function trackSignature(track){var rows=[];for(var i=0;i<track.clips.numItems;i++){var c=track.clips[i];rows.push([c.projectItem.getMediaPath(),c.start.ticks,c.end.ticks]);}return serialize(rows);}
 function newCaptionTrack(id){
  var s=seq(id),before=s.videoTracks.numTracks,audio=s.audioTracks.numTracks,ids=[],audioBefore=[];
  for(var i=0;i<before;i++)ids.push(trackSignature(s.videoTracks[i]));
  for(var a=0;a<audio;a++)audioBefore.push(trackSignature(s.audioTracks[a]));
  app.enableQE();var q=qe.project.getActiveSequence();
  if(!q||!q.addTracks)throw Error('This Premiere version cannot create a caption video track automatically.');
  q.addTracks(1,before-1,0);
  s=seq(id);
  if(s.videoTracks.numTracks!==before+1||s.audioTracks.numTracks!==audio)throw Error('Premiere did not create exactly one video-only track. No captions were placed.');
  for(var j=0;j<before;j++)if(trackSignature(s.videoTracks[j])!==ids[j])throw Error('Premiere inserted the new track in an unexpected position. No captions were placed.');
  for(var k=0;k<audio;k++)if(trackSignature(s.audioTracks[k])!==audioBefore[k])throw Error('Premiere changed an audio track unexpectedly. No captions were placed.');
  var target=s.videoTracks[before];if(target.clips.numItems)throw Error('The new caption track is not empty. No existing clips were changed.');
  try{target.name='Kandy For Scale Captions';}catch(ignore){}
  return {track:target,index:before};
 }
 return {
  info:function(){return protect(info);},
  srt:function(){return protect(function(){var f=File.openDialog('Choose subtitle file',fileFilter(['srt']));return {path:f?f.fsName:''};});},
  audio:function(){return protect(function(){var f=File.openDialog('Choose full sequence audio or video',fileFilter(['wav','mp3','m4a','mp4','mov']));return {path:f?f.fsName:''};});},
  exportAudio:function(id,path,preset){return protect(function(){var s=seq(id);if(!(new File(preset)).exists)throw Error('WAV export preset not found.');var ok=s.exportAsMediaDirect((new File(path)).fsName,(new File(preset)).fsName,0);if(!(new File(path)).exists || (new File(path)).length<44)throw Error('Premiere audio export failed: '+ok+'. You can also import an exported sequence WAV.');return {path:path,sequence:info()};});},
  addNative:function(id,path){return protect(function(){var s=seq(id);if(!(new File(path)).exists)throw Error('Caption file is missing.');var bin=app.project.rootItem.createBin('Kandy Captions '+(new Date()).getTime());if(!app.project.importFiles([path],true,bin,false))throw Error('Premiere could not import SRT.');var item=find(bin,path);if(!item)throw Error('Imported caption item not found.');if(!s.createCaptionTrack(item,0))throw Error('Premiere could not create a caption track.');return {message:'Editable caption track added. Apply a Proxima Nova Track Style in Premiere.'};});},
  replaceStyled:function(id,path,name){return protect(function(){
   var s=seq(id);if(!(new File(path)).exists)throw Error('Styled overlay file is missing. Click Apply text or style edits & rebuild first.');
   function isCaption(clip){var mp='';try{mp=clip.projectItem&&clip.projectItem.getMediaPath?clip.projectItem.getMediaPath():'';}catch(e){}return mp.indexOf('Kandy For Scale Captions')>=0&&/caption_\d+\.png$/i.test(mp);}
   var target=null,ti=-1;
   for(var t=s.videoTracks.numTracks-1;t>=0&&!target;t--){var tr=s.videoTracks[t];if(!tr.clips.numItems)continue;var all=true;for(var c=0;c<tr.clips.numItems;c++){if(!isCaption(tr.clips[c])){all=false;break;}}if(all){target=tr;ti=t;}}
   if(!target)throw Error('No existing styled caption track found in this sequence. Use Add styled captions instead.');
   if(!app.project.importFiles([path],true,kandyJobBin(name),false))throw Error('Could not import overlay sequence.');
   var overlay=null;for(var i=0;i<app.project.sequences.numSequences;i++){var x=app.project.sequences[i];if(x.name===name)overlay=x;}
   if(!overlay||!overlay.videoTracks.numTracks||!overlay.videoTracks[0].clips.numItems)throw Error('Caption overlay sequence is empty or missing.');
   for(var m=0;m<overlay.videoTracks[0].clips.numItems;m++){var media=overlay.videoTracks[0].clips[m].projectItem;if(media.isOffline&&media.isOffline())throw Error('A caption image is offline. Regenerate captions and keep the output folder in place.');}
   app.project.openSequence(id);s=seq(id);target=s.videoTracks[ti];
   var removed=target.clips.numItems;
   for(var r=target.clips.numItems-1;r>=0;r--)target.clips[r].remove(false,false);
   if(target.clips.numItems)throw Error('Could not clear the old caption clips on V'+(ti+1)+'.');
   var clips=overlay.videoTracks[0].clips;
   kandyPlace(target,clips);
   if(target.clips.numItems!==clips.numItems)throw Error('Some caption clips could not be placed. Review track V'+(ti+1)+'.');
   try{app.project.deleteSequence(overlay);}catch(ignore){}
   var cleaned=kandyCleanup();
   return {message:'Replaced '+removed+' old captions with '+clips.numItems+' new ones on V'+(ti+1)+'.'+(cleaned?' Removed '+cleaned+' unused old caption sets from the project.':''),track:ti+1};
  });},
  replaceSelected:function(id,path,name){return protect(function(){
   var s=seq(id);if(!(new File(path)).exists)throw Error('Styled overlay file is missing. Click Update preview first.');
   function isCaption(clip){var mp='';try{mp=clip.projectItem&&clip.projectItem.getMediaPath?clip.projectItem.getMediaPath():'';}catch(e){}return mp.indexOf('Kandy For Scale Captions')>=0&&/caption_\d+\.png$/i.test(mp);}
   var plan={},count=0;
   for(var t=0;t<s.videoTracks.numTracks;t++){var tr=s.videoTracks[t],rows=[],any=false;
    for(var c=0;c<tr.clips.numItems;c++){var k=tr.clips[c];var sel=false;try{sel=k.isSelected();}catch(e){}rows.push({item:k.projectItem,a:k.start.seconds,ticks:k.start.ticks,end:k.end,b:k.end.seconds,cap:isCaption(k),sel:sel&&isCaption(k)});if(sel&&isCaption(k)){any=true;count++;}}
    if(any)plan[t]=rows;}
   if(!count)throw Error('Select one or more caption clips on the timeline first.');
   if(!app.project.importFiles([path],true,kandyJobBin(name),false))throw Error('Could not import overlay sequence.');
   var overlay=null;for(var i=0;i<app.project.sequences.numSequences;i++){var x=app.project.sequences[i];if(x.name===name)overlay=x;}
   if(!overlay||!overlay.videoTracks.numTracks||!overlay.videoTracks[0].clips.numItems)throw Error('Caption overlay sequence is empty or missing.');
   var src=overlay.videoTracks[0].clips;
   for(var key in plan){var list=plan[key];for(var r=0;r<list.length;r++){if(!list[r].sel)continue;var best=null,score=0;for(var n=0;n<src.numItems;n++){var o=Math.min(list[r].b,src[n].end.seconds)-Math.max(list[r].a,src[n].start.seconds);if(o>score){score=o;best=src[n].projectItem;}}if(best)list[r].item=best;}}
   app.project.openSequence(id);s=seq(id);
   for(var key2 in plan){var rows2=plan[key2],tr2=s.videoTracks[Number(key2)];
    for(var d=0;d<rows2.length;d++){if(!rows2[d].cap)throw Error('Track V'+(Number(key2)+1)+' has other clips besides captions. Nothing was changed.');}
    for(var q=tr2.clips.numItems-1;q>=0;q--)tr2.clips[q].remove(false,false);
    rows2.sort(function(u,v){return u.a-v.a;});
    for(var w=0;w<rows2.length;w++){tr2.overwriteClip(rows2[w].item,rows2[w].ticks);
     for(var z=0;z<tr2.clips.numItems;z++){var nc=tr2.clips[z];if(Math.abs(nc.start.seconds-rows2[w].a)<0.002){nc.end=rows2[w].end;break;}}}
    if(tr2.clips.numItems!==rows2.length)throw Error('Track V'+(Number(key2)+1)+' now has '+tr2.clips.numItems+' clips instead of '+rows2.length+'. Press Cmd+Z to undo.');}
   try{app.project.deleteSequence(overlay);}catch(ignore){}
   kandyCleanup();
   return {message:'Replaced '+count+' selected caption'+(count===1?'':'s')+'. All other captions were kept.'};
  });},
  addStyled:function(id,path,name){return protect(function(){
   seq(id);if(!(new File(path)).exists)throw Error('Styled overlay file is missing.');
   if(!app.project.importFiles([path],true,kandyJobBin(name),false))throw Error('Could not import overlay sequence.');
   var overlay=null;for(var i=0;i<app.project.sequences.numSequences;i++){var x=app.project.sequences[i];if(x.name===name)overlay=x;}
   if(!overlay||!overlay.videoTracks.numTracks||!overlay.videoTracks[0].clips.numItems)throw Error('Caption overlay sequence is empty or missing.');
   for(var m=0;m<overlay.videoTracks[0].clips.numItems;m++){var media=overlay.videoTracks[0].clips[m].projectItem;if(media.isOffline&&media.isOffline())throw Error('A caption image is offline. Regenerate captions and keep the output folder in place.');}
   app.project.openSequence(id);var created=newCaptionTrack(id),target=created.track;
   var clips=overlay.videoTracks[0].clips;
   kandyPlace(target,clips);
   if(target.clips.numItems!==clips.numItems)throw Error('Some caption clips could not be placed. Review the new caption track.');
   return {message:'Styled captions added to new top track V'+(created.index+1)+'. Keep the output folder with your project.',track:created.index+1,created_track:true};
  });}

 };
}());

function kandyAt(track,t){for(var z=track.clips.numItems-1;z>=0;z--){var c=track.clips[z];if(Math.abs(c.start.seconds-t)<0.02)return c;}return null;}
function kandyPlace(target,clips){
 for(var pass=0;pass<3;pass++){var missing=0;
  for(var n=0;n<clips.numItems;n++){var source=clips[n],have=kandyAt(target,source.start.seconds);
   if(have&&Math.abs(have.end.seconds-source.end.seconds)<0.02)continue;
   if(!have){target.overwriteClip(source.projectItem,source.start.ticks);have=kandyAt(target,source.start.seconds);}
   if(have){try{have.end=source.end;}catch(e){}}else missing++;}
  if(!missing)break;}
}
function kandyJobBin(name){var root=kandyCaptionBin();for(var i=0;i<root.children.numItems;i++){var c=root.children[i];if(c&&c.type===2&&c.name===name)return c;}return root.createBin(name)||root;}
function kandyCleanup(){return kandyCleanupIn(kandyCaptionBin());}
function kandyCleanupIn(root){try{var used={},re=/Kandy For Scale Captions[\/\\]([^\/\\]+)[\/\\]caption_\d+\.png$/i;
 for(var s=0;s<app.project.sequences.numSequences;s++){var sq=app.project.sequences[s];for(var t=0;t<sq.videoTracks.numTracks;t++){var tr=sq.videoTracks[t];for(var c=0;c<tr.clips.numItems;c++){var mp='';try{mp=tr.clips[c].projectItem.getMediaPath();}catch(e){}var m=re.exec(mp);if(m)used[m[1]]=1;}}}
 var trash=null,moved=0,removed=0;
 for(var i=root.children.numItems-1;i>=0;i--){var it=root.children[i];if(!it)continue;
  if(it.type===2){if(it.name==='_old'){continue;}var job=it.name.replace(/^Kandy Captions /,'');if(!used[job]){try{it.deleteBin();removed++;}catch(e){}}}
  else{var mp2='';try{mp2=it.getMediaPath();}catch(e){}var m2=re.exec(mp2);if(m2&&!used[m2[1]]){if(!trash)trash=root.createBin('_old');try{it.moveBin(trash);moved++;}catch(e){}}}}
 if(trash){try{trash.deleteBin();}catch(e){}}
 return removed+moved;}catch(e){return 0;}}
function kandyCaptionBin(){var root=app.project.rootItem;for(var b=0;b<root.children.numItems;b++){var ch=root.children[b];if(ch&&ch.name==='Kandy For Scale Caption Files'&&ch.type===2)return ch;}return root.createBin('Kandy For Scale Caption Files')||root;}
