/* Native launch paths; no shell interpolation and no Windows feed on Mac. */
(function(root){
 'use strict';
 var api={
  cache:function(path,os,env,platform){
   if(platform==='darwin')return path.join(os.homedir(),'Library','Application Support','KandyForScaleCaptions');
   if(platform==='win32'&&env.LOCALAPPDATA)return path.join(env.LOCALAPPDATA,'KandyForScaleCaptions');
   throw Error('This extension supports Windows and macOS.');
  },
  python:function(path,cache,platform){return platform==='darwin'?path.join(cache,'bundle','runtime','bin','python3'):path.join(cache,'bundle','runtime','python.exe');},
  environment:function(path,original,cache,platform){
   var env=Object.assign({},original,{PYTHONNOUSERSITE:'1',PYTHONUTF8:'1'});
   delete env.PYTHONPATH;
   if(platform==='darwin'){
    delete env.PYTHONHOME;
    env.PATH=[path.join(cache,'bundle'),path.join(cache,'bundle','runtime','bin'),'/usr/bin','/bin',env.PATH||''].join(':');
   }else env.PYTHONHOME=path.dirname(api.python(path,cache,platform));
   return env;
  },
  fileURL:function(path,url,file){return url.pathToFileURL(path.resolve(file)).href;},
  openFolder:function(cp,folder,platform){return cp.spawn(platform==='darwin'?'/usr/bin/open':'explorer.exe',[folder],{windowsHide:true,shell:false});},
  wavPreset:function(fs,path,appPath,platform){
   var roots=[appPath,path.dirname(appPath)],candidates=[],leaf='Waveform Audio 48kHz 16-bit.epr';
   if(platform==='darwin')roots=roots.concat([path.join(appPath,'Contents'),path.join(appPath,'Contents','Resources'),path.join(appPath,'Contents','SharedSupport')]);
   roots.forEach(function(root){candidates.push(path.join(root,'MediaIO','systempresets','3F3F3F3F_57415645',leaf));});
   var exact=candidates.find(function(p){return fs.existsSync(p);});if(exact)return exact;
   // Search only Adobe's WAV preset directory; app layouts vary by release.
   for(var i=0;i<roots.length;i++){
    var directory=path.join(roots[i],'MediaIO','systempresets','3F3F3F3F_57415645');
    try{var found=fs.readdirSync(directory).find(function(n){return /48.*16.*\.epr$/i.test(n)&&/wave|wav/i.test(n);});if(found)return path.join(directory,found);}catch(ignore){}
   }
   return null;
  }
 };
 if(typeof module!=='undefined'&&module.exports)module.exports=api;
 root.KandyPlatform=api;
}(typeof window!=='undefined'?window:this));
