"""Kandy For Scale Captions - automatic updates.
Checks a signed manifest on GitHub, downloads the new engine + panel (a few MB),
verifies the publisher signature and checksum, installs it next to the current
version and switches over. Any problem keeps the current version working."""
import base64, hashlib, json, os, re, shutil, ssl, sys, time, urllib.request, uuid, zipfile
from pathlib import Path
from urllib.parse import urlsplit

PUBLIC_KEY = 't2q+1RhyP8+RxPO3cb+8G75cKja/R3vqNMmlhjSvBTs='
HOSTS = {'github.com', 'raw.githubusercontent.com', 'objects.githubusercontent.com', 'release-assets.githubusercontent.com', 'codeload.github.com'}
VERSION = re.compile(r'\d+\.\d+\.\d+\Z')
RUNTIME = 2

def vt(v): return tuple(int(x) for x in v.split('.'))

def write(path, value):
    path = Path(path); tmp = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    tmp.write_text(json.dumps(value, indent=2), encoding='utf-8'); os.replace(tmp, path)

def check_url(url):
    p = urlsplit(url)
    if p.scheme != 'https' or p.hostname not in HOSTS or p.username or p.password or p.port not in (None, 443):
        raise ValueError('Update address is not an approved GitHub address.')
    return url

class Redirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        check_url(newurl); return super().redirect_request(req, fp, code, msg, headers, newurl)

def context():
    try:
        import certifi; return ssl.create_default_context(cafile=certifi.where())
    except Exception: return ssl.create_default_context()

def fetch(url, limit, cancel, timeout=20):
    opener = urllib.request.build_opener(Redirect(), urllib.request.HTTPSHandler(context=context()))
    sep = '&' if '?' in url else '?'
    req = urllib.request.Request(check_url(url + sep + 't=' + str(int(time.time() // 60))),
                                 headers={'User-Agent': 'KandyForScaleCaptions', 'Cache-Control': 'no-cache'})
    data = bytearray(); born = time.monotonic()
    with opener.open(req, timeout=timeout) as r:
        while True:
            if cancel.exists(): raise InterruptedError('Panel closed during the update.')
            if time.monotonic() - born > 40: raise TimeoutError('Update download timed out.')
            chunk = r.read(65536)
            if not chunk: break
            data += chunk
            if len(data) > limit: raise ValueError('Update file is larger than allowed.')
    return bytes(data)

def verify(envelope):
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    from cryptography.exceptions import InvalidSignature
    if not isinstance(envelope, dict) or not isinstance(envelope.get('payload'), str) or not isinstance(envelope.get('signature'), str):
        raise ValueError('Update manifest is damaged.')
    key = Ed25519PublicKey.from_public_bytes(base64.b64decode(PUBLIC_KEY))
    try: key.verify(base64.b64decode(envelope['signature'], validate=True), envelope['payload'].encode('utf-8'))
    except (InvalidSignature, ValueError): raise ValueError('Update was not signed by Kandy For Scale. It was ignored.')
    m = json.loads(envelope['payload'])
    if m.get('schema') != 1 or not VERSION.fullmatch(str(m.get('version', ''))) or not re.fullmatch('[a-f0-9]{64}', str(m.get('sha256', ''))):
        raise ValueError('Update manifest is not supported.')
    check_url(m['url']); return m

def install(cache, extension, m, blob):
    version = m['version']; releases = cache / 'releases'; final = releases / version
    stage = releases / (version + '.partial-' + uuid.uuid4().hex[:8]); stage.mkdir(parents=True)
    tmpzip = stage / 'update.zip'; tmpzip.write_bytes(blob)
    with zipfile.ZipFile(tmpzip) as z:
        for info in z.infolist():
            name = info.filename
            if name.startswith('/') or '..' in Path(name).parts or ':' in name: raise ValueError('Unsafe file in update.')
            if not (name.startswith('engine/') or name.startswith('panel/')): continue
            z.extract(info, stage)
    tmpzip.unlink()
    if not (stage / 'engine' / 'worker.py').is_file() or not (stage / 'panel' / 'index.html').is_file(): raise ValueError('Update is incomplete.')
    if final.exists(): shutil.rmtree(final, ignore_errors=True)
    os.replace(stage, final)
    # Panel files: overwrite in place (keep this computer's channel.json), then the panel reloads.
    panel = final / 'panel'
    for src in panel.rglob('*'):
        if src.is_dir() or src.name == 'channel.json': continue
        dst = extension / src.relative_to(panel); dst.parent.mkdir(parents=True, exist_ok=True)
        tmp = dst.with_name(dst.name + '.kfs-new'); shutil.copy2(src, tmp); os.replace(tmp, dst)
    active = json.loads((cache / 'active.json').read_text(encoding='utf-8-sig'))
    active.update(version=version, revision=int(active.get('revision', 1)) + 1)
    write(cache / 'active.json', active)
    # Keep the two newest releases, remove older ones.
    old = sorted([p for p in releases.iterdir() if p.is_dir() and VERSION.fullmatch(p.name)], key=lambda p: vt(p.name))
    for p in old[:-2]: shutil.rmtree(p, ignore_errors=True)
    for p in releases.glob('*.partial-*'): shutil.rmtree(p, ignore_errors=True)
    return final / 'engine'

def main(request_path):
    request_path = Path(request_path).resolve(); job = request_path.parent; cancel = job / 'cancel'
    def status(msg): write(job / 'status.json', dict(message=msg))
    try:
        req = json.loads(request_path.read_text(encoding='utf-8'))
        cache = Path(req['cache']); extension = Path(req['extension']); cfg = req.get('config') or {}
        active = json.loads((cache / 'active.json').read_text(encoding='utf-8-sig'))
        current = active['version']; root = cache / 'releases' / current / 'engine'
        if not (root / 'worker.py').is_file(): raise ValueError('Run the Kandy For Scale Captions installer again to repair the caption engine.')
        state = dict(root=str(root), version=current, offline=True, message='Ready · version ' + current)
        url = str(cfg.get('manifestURL') or '')
        if url:
            try:
                status('Checking for updates…')
                m = verify(json.loads(fetch(url, 65536, cancel).decode('utf-8')))
                if vt(m['version']) > vt(current):
                    if int(m.get('runtime', RUNTIME)) > RUNTIME:
                        state['detail'] = 'Version ' + m['version'] + ' is available. Run the newest installer to get it.'
                    else:
                        status('Downloading update ' + m['version'] + '…')
                        blob = fetch(m['url'], int(m.get('size', 50_000_000)) + 1024, cancel, timeout=30)
                        if hashlib.sha256(blob).hexdigest() != m['sha256']: raise ValueError('Update download was damaged. It will retry next time.')
                        status('Installing update ' + m['version'] + '…')
                        new_root = install(cache, extension, m, blob)
                        state = dict(root=str(new_root), version=m['version'], offline=False, updated=True,
                                     message='Updated to version ' + m['version'], detail=str(m.get('notes', '')))
                else:
                    state.update(offline=False, message='Ready · version ' + current + ' (up to date)')
            except InterruptedError: raise
            except Exception as e:
                state['detail'] = 'Update check skipped: ' + str(e)[:300]
        out = dict(state=state)
    except Exception as error: out = dict(error=str(error))
    write(job / 'result.json', out)

if __name__ == '__main__': main(sys.argv[1])
