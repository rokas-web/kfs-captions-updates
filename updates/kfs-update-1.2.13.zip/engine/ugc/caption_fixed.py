"""Keep the selected font size: reflow timed phrases, never shrink captions."""
import copy
MAX_WORDS=24  # far above what fits on two caption lines

def lines(words,measure,width,style):
 if not words:return []
 forced=int(style.get('line_break',0))
 if not style.get('_strict_one') and 0<forced<len(words) and max(measure(' '.join(words[:forced])),measure(' '.join(words[forced:])))<=width:return [words[:forced],words[forced:]]
 if measure(' '.join(words))<=width:return [words]
 if style.get('_strict_one'):return None
 from .caption_phrases import WEAK,STARTERS,token
 from .caption_language import boundaries
 from .caption_numbers import boundaries as numbers
 protected,_=boundaries([{'text':w} for w in words]);numeric=numbers(words)
 choices=[]
 for cut in range(1,len(words)):
  left,right=words[:cut],words[cut:];a,b=measure(' '.join(left)),measure(' '.join(right))
  if max(a,b)>width:continue
  tail,head=token({'text':left[-1]}),token({'text':right[0]})
  cost=abs(a-b)/width
  if cut in protected:cost+=20
  if cut in numeric:cost+=1000
  if tail in WEAK:cost+=60
  if head in STARTERS:cost-=1
  if len(words)>3 and (len(left)==1 or len(right)==1):cost+=25
  choices.append((cost,cut))
 if forced and any(cut==forced for _,cut in choices):return [words[:forced],words[forced:]]
 if not choices:return None
 cut=min(choices)[1];return [words[:cut],words[cut:]]

def coalesce(groups):
 """Fit each phrase before reapplying its scene-cut display continuations."""
 out=[]
 clock=lambda row:[(w['text'],w['start'],w['end']) for w in row['words']]
 for row in copy.deepcopy(groups):
  if out and row.get('scene_continuation') and abs(out[-1]['end']-row['start'])<1e-7 and clock(out[-1])==clock(row):out[-1]['end']=row['end']
  else:row.pop('scene_continuation',None);out.append(row)
 return out

def fit(p,groups,style,size,cw,ch,stop=None,update=None):
 from .captions import layout,clean_text
 from .caption_phrases import language_edges,token,WEAK
 from .caption_numbers import boundaries as numbers
 from .caption_phrases import terminal
 from .caption_timeline import audio_context_edges
 out=[];prefer_one=style.get('max_lines',2)==1;queue=coalesce(groups);index=0;hard=audio_context_edges(p)
 while index<len(queue):
  group=queue[index]
  if stop is not None and stop.is_set():raise InterruptedError('Cancelled')
  if update and index%10==0:update('Fitting captions at the selected size',100*index/max(1,len(groups)))
  words=group['words'];n=len(words);cache={}
  def edge(i):return group['start'] if i==0 else group['end'] if i==n else max(group['start'],min(group['end'],round(words[i]['start']*30)/30))
  def count(a,b,strict=False):
   key=(a,b,strict)
   if key not in cache:cache[key]=layout(' '.join(w['text'] for w in words[a:b]),{**style,'line_break':0,'_strict_one':strict},size,ch/2,width=cw-200,canvas=(cw,ch),_line_count=True)
   return cache[key]
  if count(0,n) and (not prefer_one or count(0,n,True)):
   out.append(group);index+=1;continue
  _,_,hints,safe=language_edges(words);numeric=numbers([w.get('raw',w['text']) for w in words])
  result=None
  for relaxed in (False,True):
   edges=sorted(safe if not relaxed else set(range(n+1))-numeric);cost={0:0.};paths={}
   for i in edges:
    if i not in cost:continue
    for j in edges:
     if j<=i:continue
     if j-i>MAX_WORDS:break   # a caption never holds this many words; skip hopeless spans
     a,b=edge(i),edge(j)
     if b-a<.4-1e-8 and not (i==0 and j==n):continue
     line_count=count(i,j)
     if not line_count:continue
     k=j-i;score=3+(k-4)**2*.3
     if prefer_one and line_count==2:score+=15
     if k==1 and n>1:score+=60
     if j<n:
      score+=hints.get(j,0)
      if j not in safe:score+=60
      if token(words[j-1]) in WEAK:score+=100
     value=cost[i]+score
     if j not in cost or value<cost[j]:cost[j]=value;paths[j]=i
   if n in paths:
    result=[];j=n
    while j:i=paths[j];result.append((i,j));j=i
    result.reverse();break
  if result is None:
   # A short imported group may have three long words, but its following
   # clause has room for the last word. Rebalance that measured phrase
   # instead of shrinking the text or flashing a single word.
   following=queue[index+1] if index+1<len(queue) else None
   if (following and not terminal(words[-1]) and not following['words'][0].get('caption_break_before')
       and len(words)+len(following['words'])<=24
       and not any(group['start']+1e-7<t<=following['start']+1e-7 for t in hard)):
    group['words']+=copy.deepcopy(following['words']);group['end']=following['end'];group.pop('line_break',None);queue.pop(index+1);continue
   sample=' '.join(w['text'] for w in words)
   raise ValueError(f'Caption "{sample[:90]}" cannot fit within two lines at size {size}. Choose a smaller caption size; text size was not changed automatically.')
  for i,j in result:
   row=copy.deepcopy(group);row.update(words=copy.deepcopy(words[i:j]),text=clean_text(' '.join(w['text'] for w in words[i:j]),punctuation=p.get('caption_punctuation',False)),start=edge(i),end=edge(j))
   if i or j<n:row.pop('line_break',None)
   out.append(row)
  index+=1
 return out
