"""Captions use the script's words (spelling, brand names, numbers); speech recognition only supplies the timing."""
import difflib, re

def _norm(t):
    return re.sub(r"[^a-z0-9%]", "", str(t).lower().replace('’', "'"))

def _spread(tokens, a, b):
    """Times for script tokens inside [a, b], shared by character length."""
    a, b = float(a), max(float(a) + .05 * len(tokens), float(b))
    weights = [max(2, len(_norm(t))) for t in tokens]; total = float(sum(weights)); out = []; t = a
    for tok, w in zip(tokens, weights):
        e = t + (b - a) * w / total; out.append(dict(text=tok, start=round(t, 3), end=round(e, 3), script=True)); t = e
    return out

def use_script(cues, script, keep_unscripted=4):
    words = [dict(w) for c in cues for w in (c.get('words') or [])]
    tokens = [t for t in re.split(r'\s+', str(script or '').strip()) if _norm(t)]
    if not words or len(tokens) < 3: return cues
    a = [_norm(w.get('text', '')) for w in words]; b = [_norm(t) for t in tokens]
    sm = difflib.SequenceMatcher(None, a, b, autojunk=False)
    if sm.ratio() < .35: return cues            # this audio is not this script: keep what was heard
    ops = sm.get_opcodes(); out = []
    for k, (op, i1, i2, j1, j2) in enumerate(ops):
        if op == 'equal':
            for i, j in zip(range(i1, i2), range(j1, j2)): out.append(dict(words[i], text=tokens[j]))
        elif op == 'replace':
            out += _spread(tokens[j1:j2], words[i1]['start'], words[i2 - 1]['end'])
        elif op == 'delete':                       # heard but not in the script
            edge = k == 0 or k == len(ops) - 1
            if edge or i2 - i1 >= keep_unscripted: out += words[i1:i2]
        elif op == 'insert':                       # in the script but not heard clearly
            if out:
                prev = out[-1]; nxt = words[i1]['start'] if i1 < len(words) else prev['end'] + .3 * (j2 - j1)
                if float(nxt) - float(prev['end']) >= .08 * (j2 - j1): s, e = prev['end'], nxt
                else:
                    mid = (float(prev['start']) + float(prev['end'])) / 2; s, e = mid, prev['end']; prev['end'] = round(mid, 3)
            else:
                e = words[0]['start']; s = max(0.0, float(e) - .3 * (j2 - j1))
            out += _spread(tokens[j1:j2], s, e)
    # back into the original cues by time
    new = [dict(c, words=[]) for c in cues]; ci = 0
    for w in out:
        while ci + 1 < len(new) and float(w['start']) >= float(new[ci + 1]['start']) - 1e-6: ci += 1
        new[ci]['words'].append(w)
    res = []
    for c in new:
        if not c['words']: continue
        c['start'] = min(float(c['start']), float(c['words'][0]['start'])); c['end'] = max(float(c['end']), float(c['words'][-1]['end']))
        c['text'] = ' '.join(w['text'] for w in c['words']); res.append(c)
    for x, y in zip(res, res[1:]):
        if y['start'] < x['end']: x['end'] = y['start']
    return res


def range_scripts(request):
    """Scripts an In-Out range can come from: each hook followed by the body, the body, or the plain script."""
    sections = request.get('brief_sections') or {}
    hooks = [str(v) for k, v in sections.items() if re.fullmatch(r'H\d+', str(k))]
    body = str(sections.get('BODY', ''))
    out = [(h + ' ' + body).strip() for h in hooks] + [body, str(sections.get('SINGLE', '')), str(request.get('script', ''))]
    return [x for x in out if x.strip()]

def script_window(cues, candidates):
    """The stretch of script that was spoken in a partial recording, or '' when none matches well enough."""
    heard = [_norm(w.get('text', '')) for c in cues for w in (c.get('words') or [])]
    heard = [x for x in heard if x]
    best = (0, 0.0, '')
    for script in candidates:
        tokens = [t for t in re.split(r'\s+', str(script or '').strip()) if _norm(t)]
        if not heard or len(tokens) < 3: continue
        b = [_norm(t) for t in tokens]
        blocks = [m for m in difflib.SequenceMatcher(None, heard, b, autojunk=False).get_matching_blocks() if m.size]
        # a lone short match far away from the rest is a common word, not where the range is
        while len(blocks) > 1 and blocks[0].size <= 2 and blocks[1].b - blocks[0].b - blocks[0].size > blocks[1].a - blocks[0].a - blocks[0].size + 4: blocks.pop(0)
        while len(blocks) > 1 and blocks[-1].size <= 2 and blocks[-1].b - blocks[-2].b - blocks[-2].size > blocks[-1].a - blocks[-2].a - blocks[-2].size + 4: blocks.pop()
        if not blocks: continue
        lo, hi = blocks[0].b, blocks[-1].b + blocks[-1].size
        matched = sum(m.size for m in blocks); ratio = 2.0 * matched / (len(heard) + hi - lo)
        # words cut by the In/Out points are often misheard: let the script words next to the match replace them
        lo = max(0, lo - min(3, blocks[0].a)); hi = min(len(tokens), hi + min(3, len(heard) - blocks[-1].a - blocks[-1].size))
        if matched >= 2 and ratio >= .35 and (matched, ratio) > best[:2]: best = (matched, ratio, ' '.join(tokens[lo:hi]))
    return best[2]
