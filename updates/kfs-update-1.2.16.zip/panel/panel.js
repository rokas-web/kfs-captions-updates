(function(){
 'use strict';
 var $=function(id){return document.getElementById(id);},cep=window.__adobe_cep__,busy=false,dirty=false,sequence=null,result=null,job=null,worker=null,engineRoot=null,updateBusy=false,updateWorker=null,updateJob=null,updateTimer=null;
 var req=typeof window.cep_node!=='undefined'?window.cep_node.require:typeof require==='function'?require:null;
 var fs=req&&req('fs'),path=req&&req('path'),cp=req&&req('child_process'),os=req&&req('os'),extension=cep&&systemPath('extension'),platform=req&&req('process').platform,cache=path&&KandyPlatform.cache(path,os,req('process').env,platform);
 var styleColors=JSON.parse(localStorage.getItem('kandyStyleColors')||'{}'),progressValue=0,progressBorn=0,progressTimer=null;
 var colorDefaults={tiktok_native_white:{text:'#000000',background:'#FFFFFF'},tiktok_native_stroke:{text:'#FFFFFF',outline:'#000000'},client_box:{text:'#000000',background:'#FFFFFF'},tiktok:{text:'#FFFFFF',outline:'#000000'},reference:{text:'#FFFFFF',outline:'#000000'},classic:{text:'#FFFFFF',outline:'#000000'},box:{text:'#FFFFFF',background:'#000000'},word_box:{text:'#FFFFFF',background:'#000000',outline:'#000000'},grey:{text:'#FFFFFF',background:'#777777'},yellow:{text:'#FFE800',outline:'#000000'},yellow_box:{text:'#000000',background:'#FFE800'},orange_box:{text:'#FFFFFF',background:'#FF6A00',outline:'#000000'},karaoke:{text:'#FFFFFF',outline:'#000000',highlight:'#FFE800'}};
 function kandySwatches(id){var inp=document.getElementById(id);if(!inp||document.getElementById(id+"Swatches"))return;var box=document.createElement("div");box.id=id+"Swatches";box.style.cssText="display:flex;flex-wrap:wrap;gap:4px;margin-top:6px";["#FFFFFF","#000000","#FFE800","#FFCC00","#FF9500","#FF6A00","#FF3B30","#FF2D95","#AF52DE","#5856D6","#007AFF","#00C7BE","#34C759","#8E8E93","#777777","#3A3A3C"].forEach(function(c){var b=document.createElement("button");b.type="button";b.title=c;b.style.cssText="width:22px;height:22px;min-width:0;max-width:22px;flex:none;padding:0;margin:0;border:1px solid #666;border-radius:4px;cursor:pointer;background:"+c;b.onclick=function(e){e.preventDefault();e.stopPropagation();inp.value=c;if(inp.oninput)inp.oninput();};box.appendChild(b);});inp.parentNode.appendChild(box);}function kandyPicker(id){var inp=document.getElementById(id);if(!inp||inp.dataset.kandyPicker)return;inp.dataset.kandyPicker="1";inp.readOnly=false;function h2r(h,s,v){var f=function(n){var k=(n+h/60)%6;return v-v*s*Math.max(0,Math.min(k,4-k,1));};return [f(5),f(3),f(1)].map(function(x){return Math.round(x*255);});}function hex(r){return "#"+r.map(function(x){return ("0"+x.toString(16)).slice(-2);}).join("").toUpperCase();}function fromHex(t){var m=/^#?([0-9a-f]{6})$/i.exec(t||"");if(!m)return [0,0,1];var n=parseInt(m[1],16),r=(n>>16&255)/255,g=(n>>8&255)/255,b=(n&255)/255,mx=Math.max(r,g,b),mn=Math.min(r,g,b),d=mx-mn,h=0;if(d){if(mx===r)h=((g-b)/d)%6;else if(mx===g)h=(b-r)/d+2;else h=(r-g)/d+4;h*=60;if(h<0)h+=360;}return [h,mx?d/mx:0,mx];}inp.addEventListener("click",function(ev){ev.preventDefault();var old=document.getElementById("kandyPickerPop");if(old){old.remove();if(old.dataset.for===id)return;}var hsv=fromHex(inp.value),W=200,H=150;var pop=document.createElement("div");pop.id="kandyPickerPop";pop.dataset.for=id;pop.style.cssText="position:fixed;z-index:9999;background:#f4f4f4;border:1px solid #888;border-radius:6px;padding:10px;box-shadow:0 6px 18px rgba(0,0,0,.5);display:flex;gap:10px;align-items:flex-start";var sq=document.createElement("div");sq.style.cssText="position:relative;width:"+W+"px;height:"+H+"px;border:1px solid #999;cursor:crosshair;background-image:linear-gradient(to top,#000,rgba(0,0,0,0)),linear-gradient(to right,#fff,rgba(255,255,255,0))";var dot=document.createElement("div");dot.style.cssText="position:absolute;width:10px;height:10px;margin:-6px 0 0 -6px;border:2px solid #fff;border-radius:50%;box-shadow:0 0 2px #000;pointer-events:none";sq.appendChild(dot);var bar=document.createElement("div");bar.style.cssText="position:relative;width:18px;height:"+H+"px;border:1px solid #999;cursor:pointer;background:linear-gradient(to bottom,#f00,#f0f,#00f,#0ff,#0f0,#ff0,#f00)";var knob=document.createElement("div");knob.style.cssText="position:absolute;left:-3px;width:22px;height:4px;margin-top:-3px;border:1px solid #000;background:#fff;pointer-events:none";bar.appendChild(knob);var side=document.createElement("div");side.style.cssText="display:flex;flex-direction:column;gap:6px;width:70px";var sw=document.createElement("div");sw.style.cssText="height:40px;border:1px solid #999;border-radius:4px";var lab=document.createElement("div");lab.style.cssText="font:12px monospace;color:#222;text-align:center";var ok=document.createElement("button");ok.type="button";ok.textContent="Done";ok.style.cssText="padding:4px 6px;margin:0;font-size:12px;background:#303541;color:#fff;border-radius:4px;min-width:0";side.appendChild(sw);side.appendChild(lab);side.appendChild(ok);function paint(push){sq.style.backgroundColor="hsl("+hsv[0]+",100%,50%)";dot.style.left=(hsv[1]*W)+"px";dot.style.top=((1-hsv[2])*H)+"px";knob.style.top=((360-hsv[0])/360*H)+"px";var c=hex(h2r(hsv[0],hsv[1],hsv[2]));sw.style.background=c;lab.textContent=c;if(push){inp.value=c;if(inp.oninput)inp.oninput();}}function drag(el,fn){el.addEventListener("mousedown",function(e){e.preventDefault();fn(e);var mv=function(e2){fn(e2);},up=function(){document.removeEventListener("mousemove",mv);document.removeEventListener("mouseup",up);};document.addEventListener("mousemove",mv);document.addEventListener("mouseup",up);});}drag(sq,function(e){var r=sq.getBoundingClientRect();hsv[1]=Math.max(0,Math.min(1,(e.clientX-r.left)/W));hsv[2]=Math.max(0,Math.min(1,1-(e.clientY-r.top)/H));paint(true);});drag(bar,function(e){var r=bar.getBoundingClientRect();hsv[0]=Math.max(0,Math.min(359.9,360-(e.clientY-r.top)/H*360));paint(true);});ok.onclick=function(){pop.remove();};pop.appendChild(sq);pop.appendChild(bar);pop.appendChild(side);document.body.appendChild(pop);var r=inp.getBoundingClientRect(),pw=pop.offsetWidth,ph=pop.offsetHeight,x=Math.max(4,Math.min(r.left,window.innerWidth-pw-4)),y=r.bottom+4;if(y+ph>window.innerHeight-4)y=Math.max(4,r.top-ph-4);pop.style.left=x+"px";pop.style.top=y+"px";paint(false);});}var styleEffects=(function(){try{return JSON.parse(localStorage.getItem("kandyStyleEffects")||"{}");}catch(e){return {};}})();var effectDefaults={tiktok_native_white:{stroke:0},tiktok_native_stroke:{stroke:5}};function paintEffects(key){var d=Object.assign({stroke:0,shadow:0,blur:0,shadow_opacity:60,shadow_color:"#000000"},effectDefaults[key]||{}),s=styleEffects[key]||{};function save(k,v){styleEffects[key]=styleEffects[key]||{};styleEffects[key][k]=v;try{localStorage.setItem("kandyStyleEffects",JSON.stringify(styleEffects));}catch(e){}if(result){dirty=true;lock(false);say("Stroke or shadow changed. Captions rebuild automatically when you add or replace them.");}}["stroke","shadow","blur","shadow_opacity"].forEach(function(k){var el=document.getElementById("fx_"+k),out=document.getElementById("fx_"+k+"_v");if(!el)return;el.value=(s[k]!=null?s[k]:d[k]);out.textContent=el.value+(k==="shadow_opacity"?"%":"");el.oninput=function(){out.textContent=el.value+(k==="shadow_opacity"?"%":"");save(k,Number(el.value));};});var c=document.getElementById("shadowColor");if(c){c.value=s.shadow_color||d.shadow_color;c.style.borderLeft="22px solid "+c.value;if(typeof kandySwatches==="function")kandySwatches("shadowColor");if(typeof kandyPicker==="function")kandyPicker("shadowColor");c.oninput=function(){var v=c.value.trim();if(v.charAt(0)!=="#")v="#"+v;if(!/^#[0-9a-fA-F]{6}$/.test(v))return;c.style.borderLeft="22px solid "+v;save("shadow_color",v.toUpperCase());};}var ol=document.getElementById("outlineColorLabel");if(ol)ol.hidden=false;}function kandyPaintBox(box,key,lines,fsOverride,height){
  var c=Object.assign({},colorDefaults[key]||{},styleColors[key]||{});
  var f=Object.assign({stroke:0,shadow:0,blur:0,shadow_opacity:60,shadow_color:"#000000"},(typeof effectDefaults!=="undefined"&&effectDefaults[key])||{},styleEffects[key]||{});
  var base=key==="tiktok_native_stroke"?66:72,size=(key===document.getElementById("style").value?Number(document.getElementById("size").value):base)||base;
  var fs=fsOverride?fsOverride*size/72:Math.min(30,Math.max(8,15*size/72)),k=fs/size;
  var shadows=[],st=Number(f.stroke)*k*1.25,oc=c.outline||"#000000";
  if(st>0){var steps=Math.max(16,Math.ceil(st*8));for(var a=0;a<steps;a++){var t=2*Math.PI*a/steps;shadows.push((Math.cos(t)*st).toFixed(2)+"px "+(Math.sin(t)*st).toFixed(2)+"px 0 "+oc);}}
  var op=Number(f.shadow_opacity)/100;
  if(op>0&&(Number(f.shadow)>0||Number(f.blur)>0)){var d=Number(f.shadow)*.7*k,bl=Number(f.blur)*k*1.5,h=(f.shadow_color||"#000000").replace("#",""),n=parseInt(h,16);
   var rgba="rgba("+(n>>16&255)+","+(n>>8&255)+","+(n&255)+","+op+")";
   shadows.push(d.toFixed(2)+"px "+d.toFixed(2)+"px "+bl.toFixed(2)+"px "+rgba);if(st>0)shadows.push((d+st*.6).toFixed(2)+"px "+(d+st*.6).toFixed(2)+"px "+bl.toFixed(2)+"px "+rgba);}
  var lineCss="display:inline-block;white-space:nowrap;color:"+(c.text||"#FFFFFF")+";text-shadow:"+(shadows.join(",")||"none")+";";
  if(c.background)lineCss+="background:"+c.background+";padding:"+(fs*.18).toFixed(1)+"px "+(fs*.38).toFixed(1)+"px;border-radius:"+(fs*.3).toFixed(1)+"px;";
  var wmap={Thin:100,Light:300,Regular:400,Medium:500,Semibold:600,Bold:700,Extrabold:800,Black:900},fw=wmap[f.weight||"Semibold"]||600;
  box.style.cssText="width:100%;max-width:100%;height:"+(height||96)+"px;box-sizing:border-box;border-radius:5px;background:#344044;display:flex;flex-direction:column;align-items:center;justify-content:center;overflow:hidden;font-family:'KFS Proxima','Proxima Nova','ProximaNova-Bold',Montserrat,'Helvetica Neue',Arial,sans-serif;font-weight:"+fw+";line-height:1.05;font-size:"+fs.toFixed(1)+"px;text-align:center";
 box.innerHTML="";lines.forEach(function(line,j){var s=document.createElement("span");s.textContent=line;s.style.cssText=lineCss+(c.background&&j?"margin-top:-1px;":"");box.appendChild(s);});
}
function kandyProximaFaces(){
 if(kandyProximaFaces.done)return;kandyProximaFaces.done=true;
 try{
  var home=os.homedir(),env=req("process").env||{},roots=platform==="win32"?[[path.join(env.APPDATA||path.join(home,"AppData","Roaming"),"Adobe","CoreSync","plugins","livetype"),false],[path.join(env.LOCALAPPDATA||path.join(home,"AppData","Local"),"Microsoft","Windows","Fonts"),true],[path.join(env.WINDIR||"C:\\Windows","Fonts"),true]]:[[path.join(home,"Library","Application Support","Adobe","CoreSync","plugins","livetype"),false],[path.join(home,"Library","Fonts"),true],["/Library/Fonts",true]],found={},rules=[];
  function rd(fd,pos,len){var b=Buffer.alloc(len);var n=fs.readSync(fd,b,0,len,pos);return b.slice(0,n);}
  function inspect(file){
   var fd=fs.openSync(file,"r");try{
    var h=rd(fd,0,12);if(h.length<12)return;var mg=h.readUInt32BE(0);if(mg!==0x4F54544F&&mg!==0x00010000&&mg!==0x74727565)return;var n=h.readUInt16BE(4),dir=rd(fd,12,16*n),t={};
    for(var i=0;i<n;i++){var o=i*16;t[dir.toString("latin1",o,o+4)]={off:dir.readUInt32BE(o+8),len:dir.readUInt32BE(o+12)};}
    if(!t.name||!t["OS/2"])return;
    var nm=rd(fd,t.name.off,Math.min(t.name.len,65536)),cnt=nm.readUInt16BE(2),so=nm.readUInt16BE(4),names={};
    for(var j=0;j<cnt;j++){var r=6+j*12,pl=nm.readUInt16BE(r),id=nm.readUInt16BE(r+6),ln=nm.readUInt16BE(r+8),of=so+nm.readUInt16BE(r+10);
     if((id!==1&&id!==4&&id!==16)||names[id]||of+ln>nm.length)continue;
     if(pl===3||pl===0){var s="";for(var k=0;k<ln;k+=2)s+=String.fromCharCode(nm.readUInt16BE(of+k));names[id]=s;}else if(pl===1)names[id]=nm.toString("latin1",of,of+ln);}
    var fam=String(names[16]||names[1]||""),full=String(names[4]||"");
    if(!/^proxima nova\b/i.test(fam)||/cond|wide|alt|scosf/i.test(fam+" "+full))return;
    var os2=rd(fd,t["OS/2"].off,64),w=os2.readUInt16BE(4),it=(os2.readUInt16BE(62)&1)||/italic|\bit\b/i.test(full);
    if(it||found[w])return;found[w]=1;
    rules.push("@font-face{font-family:'KFS Proxima';font-weight:"+w+";font-style:normal;src:url('"+encodeURI("file://"+(file.charAt(0)==="/"?"":"/")+file.replace(/\\/g,"/")).replace(/'/g,"%27").replace(/#/g,"%23")+"')}");
   }finally{fs.closeSync(fd);}
  }
  function walk(dir,needName,depth){
   var list;try{list=fs.readdirSync(dir);}catch(e){return;}
   list.forEach(function(f){var p=path.join(dir,f),st;try{st=fs.statSync(p);}catch(e){return;}
    if(st.isDirectory()){if(depth<5)walk(p,needName,depth+1);}
    else if((/\.(otf|ttf)$/i.test(f)||(!needName&&!/\.[a-z]{2,4}$/i.test(f)))&&(!needName||/proxima/i.test(f))){try{inspect(p);}catch(e){}}});
  }
  roots.forEach(function(r){walk(r[0],r[1],0);});
  if(rules.length){var el=document.createElement("style");el.id="kandyProximaFaces";el.textContent=rules.join("\n");document.head.appendChild(el);kandyLivePreview.last="";}
 }catch(e){}
}
function kandyLivePreview(){
 kandyProximaFaces();
 var cards=document.querySelectorAll("[data-style]");if(!cards.length)return;if(!document.getElementById("kandyLiveCss")){var css=document.createElement("style");css.id="kandyLiveCss";css.textContent=".style-grid{grid-template-columns:minmax(0,1fr) minmax(0,1fr)!important}.style-card{min-width:0;overflow:hidden}";document.head.appendChild(css);}
 var big=document.getElementById("kandyBigPreview"),ri=document.querySelectorAll("#review .phrase input"),txt=kandyLivePreview.focusText||(ri[0]&&ri[0].value)||"";
 var sig=JSON.stringify([styleColors,styleEffects,document.getElementById("size").value,document.getElementById("style").value,txt,ri.length]);
 if(sig===kandyLivePreview.last)return;kandyLivePreview.last=sig;
 if(big){big.hidden=!ri.length;if(ri.length){var bw=Math.max(200,(big.parentNode.clientWidth||360)-40);kandyPaintBox(big,document.getElementById("style").value,[txt],Math.min(34,bw/(Math.max(8,txt.length)*0.6)),130);}}
 for(var i=0;i<cards.length;i++){
  var card=cards[i],key=card.dataset.style,img=card.querySelector("img"),box=card.querySelector(".kandy-live");
  if(!box){box=document.createElement("div");box.className="kandy-live";card.insertBefore(box,card.firstChild);}
  if(img)img.style.display="none";
  kandyPaintBox(box,key,["Enter your","text here and here"]);
 }
}
var kandyLiveTimer=setInterval(function(){try{kandyLivePreview();}catch(e){}},150);
function kandyWeight(key){var el=document.getElementById("fx_weight");if(!el)return;var s=styleEffects[key]||{};el.value=s.weight||"Semibold";el.onchange=function(){styleEffects[key]=styleEffects[key]||{};styleEffects[key].weight=el.value;try{localStorage.setItem("kandyStyleEffects",JSON.stringify(styleEffects));}catch(e){}if(result){dirty=true;lock(false);say("Font weight changed. Captions are redrawn when you add or replace them.");}};}
document.addEventListener("focusin",function(e){var t=e.target;if(t&&t.closest&&t.closest("#review .phrase")){kandyLivePreview.focusText=t.value;}});
document.addEventListener("input",function(e){var t=e.target;if(t&&t.closest&&t.closest("#review .phrase")){kandyLivePreview.focusText=t.value;}});
var kandyLearn=(function(){
 var dir="";try{dir=path.join(cache,"learned");}catch(e){}
 function cfg(){try{return JSON.parse(fs.readFileSync(path.join(dir,"config.json"),"utf8"));}catch(e){return {};}}
 function setCfg(c){try{fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(path.join(dir,"config.json"),JSON.stringify(c,null,2));}catch(e){}}
 function norm(t){return String(t||"").toLowerCase().replace(/’/g,"'").replace(/[^a-z0-9%']/g,"");}
 function user(){try{return (os.userInfo().username||"editor").replace(/[^\w.-]/g,"_");}catch(e){return "editor";}}
 function save(entry){try{fs.mkdirSync(dir,{recursive:true});var line=JSON.stringify(entry)+"\n";fs.appendFileSync(path.join(dir,"corrections.jsonl"),line);var team=cfg().team;if(team&&fs.existsSync(team))fs.appendFileSync(path.join(team,"corrections-"+user()+".jsonl"),line);}catch(e){}}
 function count(){var n=0,files=[],team=cfg().team;try{files.push(path.join(dir,"corrections.jsonl"));}catch(e){return 0;}try{if(team&&fs.existsSync(team))fs.readdirSync(team).forEach(function(f){if(/^corrections-.*\.jsonl$/.test(f))files.push(path.join(team,f));});}catch(e){}
  files.forEach(function(f){try{n+=fs.readFileSync(f,"utf8").split("\n").filter(Boolean).length;}catch(e){}});return n;}
 return {dir:dir,cfg:cfg,setCfg:setCfg,norm:norm,user:user,save:save,count:count};
})();
function kandyGroupAt(t){var g=result.groups,k=0;for(var i=0;i<g.length;i++){if(g[i].start<=t+0.06)k=i;else break;}return k;}
function kandyWordsIn(a,b){var out=[];(result.cues||[]).forEach(function(c){(c.words||[]).forEach(function(w){var m=(w.start+w.end)/2;if(m>=a-0.06&&m<b-0.01)out.push(w);});});return out;}
function kandyRecord(t0,t1){if(!result||!result.cues)return;
 result.cues.forEach(function(cue){if(cue.end<t0-0.01||cue.start>t1+0.01)return;var ws=cue.words||[];if(ws.length<2)return;var cuts=[];
  for(var i=1;i<ws.length;i++){if(kandyGroupAt((ws[i].start+ws[i].end)/2)!==kandyGroupAt((ws[i-1].start+ws[i-1].end)/2))cuts.push(i);}
  kandyLearn.save({words:ws.map(function(w){return kandyLearn.norm(w.raw||w.text);}),cuts:cuts,user:kandyLearn.user(),time:new Date().toISOString(),sequence:result.sequence&&result.sequence.name||""});});
 kandyLearnInfo();}
function kandyChanged(a,b,focusIdx,caret){dirty=true;result.manually_edited=true;lock(false);renderReview();kandyRecord(a,b);
 var ins=document.querySelectorAll("#review .phrase input"),f=ins[Math.max(0,Math.min(ins.length-1,focusIdx))];
 if(f){f.focus();var c=caret||0;try{f.setSelectionRange(c,c);}catch(e){}}
 say("Caption break changed and saved as a lesson. New captions will split like this.");}
function kandyEnhance(){var inputs=document.querySelectorAll("#review .phrase input");
 Array.prototype.forEach.call(inputs,function(inp,k){inp.addEventListener("keydown",function(ev){if(busy||!result)return;var g=result.groups,row=g[k];if(!row)return;
  if(ev.key==="Enter"){ev.preventDefault();var pos=inp.selectionStart,txt=inp.value,left=txt.slice(0,pos).trim(),right=txt.slice(pos).trim();if(!left||!right)return;
   var lw=left.split(/\s+/).length,tw=txt.trim().split(/\s+/).length,ws=kandyWordsIn(row.start,row.end);
   var ts=ws.length===tw?ws[lw].start:row.start+(row.end-row.start)*lw/tw;ts=Math.max(row.start+0.05,Math.min(row.end-0.05,ts));
   g.splice(k,1,{start:row.start,end:ts,text:left},{start:ts,end:row.end,text:right});kandyChanged(row.start,row.end,k+1,0);}
  else if(ev.key==="Backspace"&&inp.selectionStart===0&&inp.selectionEnd===0&&k>0){ev.preventDefault();var prev=g[k-1],caret=prev.text.length+1;
   g.splice(k-1,2,{start:prev.start,end:row.end,text:(prev.text+" "+row.text).trim()});kandyChanged(prev.start,row.end,k-1,caret);}
 });});}
function kandyLearnInfo(){var el=document.getElementById("kandyLearnInfo");if(el){var n=kandyLearn.count();el.textContent=n?"Learned from "+n+" caption fix"+(n===1?"":"es")+(kandyLearn.cfg().team?" (shared with the team)":" (this Mac only)")+".":"No caption fixes learned yet.";}}
setTimeout(function(){var t=document.getElementById("kandyTeam");if(t){t.value=kandyLearn.cfg().team||"";t.onchange=function(){var c=kandyLearn.cfg(),v=t.value.trim();if(v&&!fs.existsSync(v)){say("That team folder does not exist on this Mac.");return;}c.team=v;kandyLearn.setCfg(c);kandyLearnInfo();say(v?"Team learning folder saved. Fixes are now shared.":"Team learning folder removed.");};}kandyLearnInfo();},300);
function paintColors(key){var defaults=colorDefaults[key],saved=styleColors[key]||{};Object.keys({text:1,background:1,outline:1,highlight:1}).forEach(function(part){var id=part+'Color';$(id+'Label').hidden=!defaults[part];$(id).value=saved[part]||defaults[part]||'#000000';kandySwatches(id);kandyPicker(id);$(id).style.borderLeft="22px solid "+$(id).value;$(id).oninput=function(){var v=$(id).value.trim();if(v.charAt(0)!=="#")v="#"+v;if(!/^#[0-9a-fA-F]{6}$/.test(v))return;$(id).style.borderLeft="22px solid "+v;styleColors[key]=styleColors[key]||{};styleColors[key][part]=v;localStorage.setItem('kandyStyleColors',JSON.stringify(styleColors));if(result){dirty=true;lock(false);say('Colors changed. Captions rebuild automatically when you add or replace them.');}};});}
 function startProgress(){if(progressBorn)return;progressBorn=Date.now();progressValue=0;$('progressDialog').hidden=false;progress(0,true);progressTimer=window.setInterval(function(){$('progressElapsed').textContent=Math.floor((Date.now()-progressBorn)/1000)+'s elapsed';$('progressCancel').disabled=!worker;},500);}
 function progress(value,indeterminate){progressValue=Math.max(progressValue,Math.min(100,Number(value)||0));$('progressTrack').classList.toggle('indeterminate',!!indeterminate);$('progressFill').style.width=(indeterminate?35:progressValue)+'%';$('progressPercent').textContent=indeterminate?'':Math.round(progressValue)+'%';if(indeterminate){$('progressTrack').removeAttribute('aria-valuenow');}else{$('progressTrack').setAttribute('aria-valuenow',Math.round(progressValue));$('progressNote').textContent='Local speech analysis and rendering. Caption timing follows the recorded voice.';}}
 function endProgress(){if(progressTimer)window.clearInterval(progressTimer);progressTimer=null;progressBorn=0;$('progressDialog').hidden=true;}
 var looks={tiktok_native_white:'White background',tiktok_native_stroke:'Black stroke'};
 function systemPath(which){var value=cep.getSystemPath(which);return /^file:/i.test(value)?req('url').fileURLToPath(value):decodeURI(value);}
 function say(s){$('status').textContent=s;if(!$('progressDialog').hidden)$('progressMessage').textContent=s;}
 function host(method,args){return new Promise(function(resolve,reject){
  var timeout=method==='exportAudio'?Math.min(1800000,Math.max(120000,((sequence&&sequence.duration)||0)*3000)):/^(addStyled|replaceStyled|replaceSelected|addNative)$/.test(method)?120000:8000;
  var timer=setTimeout(function(){reject(Error('Premiere did not respond. Reopen the panel and refresh the sequence.'));},timeout);
  if(!cep){clearTimeout(timer);return reject(Error('Open this panel in Premiere: Window > Extensions > Kandy For Scale Captions.'));}
  cep.evalScript('KandyForScaleCaptions.'+method+'('+args.map(JSON.stringify).join(',')+')',function(raw){clearTimeout(timer);try{if(raw==='EvalScript error.')throw Error('Premiere could not run the caption connection. Restart Premiere and reopen Kandy For Scale Captions.');var r=JSON.parse(raw);if(r.error)throw Error(r.error);resolve(r);}catch(e){reject(Error(e.message));}});
 });}
 function needsScriptReview(){return result&&(result.hook_choice&&result.hook_choice.needs_review||result.script_review&&result.script_review.needs_review)&&!result.script_review_acknowledged;}
 function lock(on){busy=on;if(!on)endProgress();['generate','audio','srt','refresh','save','native','styled','replace','replaceSel','checkUpdates','useDetected'].forEach(function(id){$(id).disabled=on||updateBusy||(!engineRoot&&['generate','audio','srt','save','native','styled','replace','replaceSel'].indexOf(id)>=0)||(['save','native','styled','replace','replaceSel'].indexOf(id)>=0&&!result);});$('cancel').hidden=!on||!worker;['script','inputMode','hook','cutPolicy','maxLines','punctuation','size','position','textColor','backgroundColor','outlineColor','highlightColor'].forEach(function(id){$(id).disabled=on||updateBusy;});}
 function protect(fn){return function(){if(busy)return;lock(true);Promise.resolve().then(fn).catch(function(e){say(e.message);}).then(function(){lock(false);});};}
 function appFolder(){if(!engineRoot)throw Error('Caption engine is not ready. Run the editor installer.');return engineRoot;}
 function python(){return KandyPlatform.python(path,cache,platform);}
 function workerEnvironment(){return KandyPlatform.environment(path,req('process').env,cache,platform);}
 function inputSettings(){var parsed=KandyBrief.parse($('script').value,$('inputMode').value);return {script:KandyBrief.select(parsed,$('hook').value),input_mode:$('inputMode').value,hook:$('hook').value||'auto',brief_sections:parsed.sections,brief_text:$('script').value};}
 function saveSequenceInput(){if(sequence)localStorage.setItem('kandySequence:'+sequence.id,JSON.stringify({text:$('script').value,mode:$('inputMode').value,hook:$('hook').value,cut_policy:$('cutPolicy').value,max_lines:Number($('maxLines').value),punctuation:$('punctuation').value==='true'}));}
 function updateBrief(savedHook){
  try{var parsed=KandyBrief.parse($('script').value,$('inputMode').value),selected=savedHook||$('hook').value;
   $('hookLabel').hidden=!parsed.hooks.length;$('hook').textContent='';var empty=document.createElement('option');empty.value='auto';empty.textContent='Automatic hook choice (standard)';$('hook').appendChild(empty);
   parsed.hooks.forEach(function(h){var o=document.createElement('option');o.value=h;o.textContent=h+' + BODY';$('hook').appendChild(o);});
   $('hook').value=parsed.hooks.indexOf(selected)>=0?selected:'auto';
   $('scriptInfo').textContent=parsed.hooks.length?'REF, IDEA and visual directions are excluded. The recorded opening automatically selects the matching hook. A manual override is available.':$('script').value.trim()?'Spoken text selected. Audio still controls the caption words and timing.':'The recorded voice sets the words and timing.';
  }catch(e){$('scriptInfo').textContent=e.message;}
 }
 function paintStyles(){
  var node=$('styles');node.textContent='';$('style').textContent='';Object.keys(looks).forEach(function(key){var option=document.createElement('option');option.value=key;option.textContent=looks[key];$('style').appendChild(option);var button=document.createElement('button'),img=document.createElement('img'),label=document.createElement('small');button.className='style-card';button.dataset.style=key;img.src='preview_'+key+'.png';img.alt=looks[key]+' rendered sample';label.textContent=looks[key];button.appendChild(img);button.appendChild(label);button.onclick=function(){if(busy||updateBusy)return;chooseStyle(key);};node.appendChild(button);});chooseStyle('tiktok_native_white');
 }
 function chooseStyle(key){$('style').value=key;if(key==='tiktok_native_white')$('size').value=72;else if(key==='tiktok_native_stroke')$('size').value=66;paintColors(key);paintEffects(key);kandyWeight(key);document.querySelectorAll('[data-style]').forEach(function(b){b.classList.toggle('selected',b.dataset.style===key);});$('styleInfo').textContent=looks[key];if(result){dirty=true;lock(false);say('Style changed. Captions rebuild automatically when you add or replace them.');}}
 function updates(quiet){var tell=function(m){if(!quiet)say(m);};
  if(busy||updateBusy)return Promise.resolve();updateBusy=true;lock(false);
  return new Promise(function(resolve,reject){
   var settled=false,born=Date.now(),local;
   function complete(error,state){if(settled)return;settled=true;if(updateTimer)window.clearInterval(updateTimer);updateTimer=null;updateWorker=null;if(error)reject(error);else resolve(state);}
   function fallback(message){if(updateJob)try{fs.writeFileSync(path.join(updateJob,'cancel'),'cancel');}catch(ignore){}if(local)complete(null,{root:local.root,offline:true,message:'Ready · using cached version '+local.version,detail:message});else complete(Error(message));}
   try{
    var active=JSON.parse(fs.readFileSync(path.join(cache,'active.json'),'utf8').replace(/^\uFEFF/,''));if(!/^\d+\.\d+\.\d+$/.test(active.version))throw Error('Run the editor installer to repair the caption engine.');
    local={version:active.version,root:path.join(cache,'releases',active.version,'engine')};if(!fs.existsSync(path.join(local.root,'worker.py'))||!fs.existsSync(python())){local=null;throw Error('Run the editor installer once to prepare the local caption engine.');}
    var config=JSON.parse(fs.readFileSync(path.join(extension,'channel.json'),'utf8').replace(/^\uFEFF/,''));
    updateJob=path.join(cache,'update-checks',Date.now().toString(36)+'-'+Math.random().toString(36).slice(2));fs.mkdirSync(updateJob,{recursive:true});
    fs.writeFileSync(path.join(updateJob,'request.json'),JSON.stringify({cache:cache,extension:extension,config:config}));tell('Checking for updates…');
    updateWorker=cp.spawn(python(),[path.join(extension,'update_worker.py'),path.join(updateJob,'request.json')],{windowsHide:true,cwd:extension,env:workerEnvironment(),stdio:['ignore','ignore','ignore']});
    updateWorker.on('error',function(e){fallback(e.message);});
    updateTimer=window.setInterval(function(){
     if(settled)return;
     try{var value=JSON.parse(fs.readFileSync(path.join(updateJob,'result.json'),'utf8'));if(value.error){fallback(value.error);return;}if(value.state&&value.state.root){complete(null,value.state);return;}}catch(ignore){}
     try{var status=JSON.parse(fs.readFileSync(path.join(updateJob,'status.json'),'utf8'));if(status.message)tell(status.message);}catch(ignore){}
     if(Date.now()-born>45000)fallback('Update check timed out. The last verified release is available.');
    },250);
   }catch(e){fallback(e.message);}
  }).then(function(state){try{fs.writeFileSync(path.join(cache,'panel-update-status.json'),JSON.stringify({time:new Date().toISOString(),message:state.message,detail:state.detail||'',offline:!!state.offline}));}catch(ignore){}engineRoot=state.root;$('updateDetails').textContent=state.detail||state.message;if(!quiet||state.updated)say(state.message);try{$('kfsVersion').textContent='Version '+(state.version||'');}catch(ignore){}if(state.updated){say('Updated to version '+state.version+'. Reopening captions…');var reload=function(){setTimeout(function(){location.reload();},400);};try{cep.evalScript('$.evalFile(new File('+JSON.stringify(path.join(extension,'host.jsx'))+'))',reload);}catch(ignore){reload();}}return state;}).catch(function(e){tell(e.message);$('updateDetails').textContent=e.message;}).then(function(){updateBusy=false;lock(false);});
 }
 function newJob(){var root=path.join(os.homedir(),'Documents','Kandy For Scale Captions');fs.mkdirSync(root,{recursive:true});job=path.join(root,new Date().toISOString().replace(/[:.]/g,'-'));fs.mkdirSync(job);return job;}
 function settings(){saveSequenceInput();return Object.assign({sequence:sequence,style:$('style').value,size:Number($('size').value),position:Number($('position').value),cut_policy:$('cutPolicy').value,caption_fill_gap:Number($('fillGap').value)||0,caption_numbers:$('numbers').value||'digits',caption_max_lines:Number($('maxLines').value),caption_punctuation:$('punctuation').value==='true',caption_style_colors:styleColors,caption_style_effects:styleEffects},inputSettings());}
 function showScriptReview(){
  var report=result.script_review,node=$('scriptDifferences');node.textContent='';$('scriptReview').hidden=!needsScriptReview();$('scriptReviewDecision').textContent='';
  if(!report)return;
  $('scriptReviewSummary').textContent=(result.hook_choice&&result.hook_choice.needs_review?'The opening is ambiguous. Verify the hook or confirm detected words. ':'')+report.unmatched_script_words+' script words unmatched · '+report.total_differences+' passage differences.';
  report.differences.forEach(function(row){var div=document.createElement('div'),when=document.createElement('strong'),expected=document.createElement('p'),detected=document.createElement('p');when.textContent=row.near===null?'No matching audio time':'Near '+row.near.toFixed(2)+'s';expected.textContent='Script: '+(row.expected||'(no words here)');detected.textContent='Detected: '+(row.detected||'(not detected)');div.appendChild(when);div.appendChild(expected);div.appendChild(detected);if(row.before||row.after){var context=document.createElement('small');context.textContent='Script context: '+row.before+' ['+(row.expected||'…')+'] '+row.after;div.appendChild(context);}node.appendChild(div);});
  if(report.total_differences>report.differences.length){var more=document.createElement('p');more.textContent='Showing the first '+report.differences.length+' differences. Check that you selected the matching hook and recording.';node.appendChild(more);}
  $('useDetected').textContent=result.manually_edited?'Use reviewed captions':'Use detected words';
 }
 function renderReview(){showScriptReview();schedulePreview();$('replace').textContent=result.range?'Replace captions in range':'Replace all on track';$('replace').title=result.range?'Replaces captions between '+clock(result.range[0])+' and '+clock(result.range[1])+' on the caption track and keeps the rest.':'';var evidence=result.scene_analysis;$('sceneInfo').textContent=result.cut_policy==='continuous'?'Following speech naturally across scene changes, with continuous caption coverage.':evidence?'Scene-aware: '+evidence.used_cuts.length+' scene boundaries enforced; no caption gaps. '+(evidence.ignored_cuts.length?'Caption boundaries follow '+evidence.ignored_cuts.length+' incompatible cuts. ':'')+(evidence.notes||[]).join(' '):'';var node=$('review');node.textContent='';result.groups.forEach(function(row){var div=document.createElement('div'),span=document.createElement('span'),input=document.createElement('input');div.className='phrase';span.textContent=row.start.toFixed(2)+' – '+row.end.toFixed(2)+'s';input.value=row.text;input.oninput=function(){dirty=true;result.manually_edited=true;row.text=input.value;say('Text changed. It will be rebuilt automatically when you add or replace captions.');};div.appendChild(span);div.appendChild(input);node.appendChild(div);});kandyEnhance();$('folder').disabled=false;if(result.preview){$('actualPreview').src=KandyPlatform.fileURL(path,req('url'),result.preview);$('actualPreview').hidden=false;}}
 function run(request){startProgress();var root=appFolder(),exe=python(root),extension=systemPath('extension');fs.writeFileSync(path.join(job,'request.json'),JSON.stringify(request,null,2));
  return new Promise(function(resolve,reject){
   var workFolder=job,args=[path.join(root,'worker.py'),'--request',path.join(cache,'bundle'),path.join(workFolder,'request.json')],finished=false,timer,lastProgress=Date.now();
   progress(5,false);worker=cp.spawn(exe,args,{windowsHide:true,cwd:root,env:workerEnvironment(),stdio:['ignore','pipe','pipe']});var child=worker;$('cancel').hidden=false;var pending='',errors='';
   function finish(error,answer){if(finished)return;finished=true;if(timer)window.clearInterval(timer);worker=null;$('cancel').hidden=true;if(error){reject(error);return;}try{result=answer;var hc=result.hook_choice;$('hookChoiceInfo').textContent=hc?(hc.automatic?'Automatically detected '+hc.hook+(hc.needs_review?' · uncertain; check the hook selector or confirm detected words.':' · matched to this recording.'):'Manual hook: '+hc.hook):'';result.manually_edited=!!request.manually_edited;try{localStorage.setItem('kandyLastJob:'+result.sequence.id,JSON.stringify({job:workFolder,manually_edited:result.manually_edited}));}catch(ignore){}dirty=false;renderReview();say(result.groups.length+' captions ready · '+result.font);resolve(result);}catch(e){reject(e);}}
   function completed(){try{var answer=JSON.parse(fs.readFileSync(path.join(workFolder,'result.json'),'utf8'));if(!answer.sequence||answer.sequence.id!==request.sequence.id||!Array.isArray(answer.groups)||!answer.groups.length)return false;if(fs.existsSync(path.join(workFolder,'cancel'))){finish(Error('Caption processing cancelled.'));return true;}finish(null,answer);return true;}catch(ignore){return false;}}
   timer=window.setInterval(function(){if(finished||completed())return;if(child.exitCode!==null&&child.exitCode!==undefined&&child.exitCode!==0)finish(Error($('status').textContent+'\n'+errors));else if(Date.now()-lastProgress>180000){try{fs.writeFileSync(path.join(workFolder,'cancel'),'cancel');child.kill();}catch(ignore){}finish(Error('The caption worker stopped responding. Retry processing; existing output files were kept.'));}},250);
   child.stdout.on('data',function(data){lastProgress=Date.now();pending+=data.toString();var lines=pending.split('\n');pending=lines.pop();lines.forEach(function(line){try{var item=JSON.parse(line);say(item.message);progress(item.progress,false);}catch(ignore){}});});
   child.stderr.on('data',function(data){errors=(errors+data.toString()).slice(-2000);});
   child.on('error',function(e){finish(e);});
   child.on('close',function(code){if(finished)return;if(!completed())finish(Error(code===0?'The caption result was not written. Retry processing.':$('status').textContent+'\n'+errors));});
  });
 }
 function restoreResult(s){try{var info=null;try{info=JSON.parse(localStorage.getItem('kandyLastJob:'+s.id)||'null');}catch(e){}var folder=info&&info.job&&fs.existsSync(path.join(info.job,'result.json'))?info.job:null;if(!folder){var root=path.join(os.homedir(),'Documents','Kandy For Scale Captions'),dirs=[];try{dirs=fs.readdirSync(root).sort().reverse();}catch(e){}for(var i=0;i<dirs.length&&!folder;i++){try{var r=JSON.parse(fs.readFileSync(path.join(root,dirs[i],'result.json'),'utf8'));if(r.sequence&&r.sequence.id===s.id&&Array.isArray(r.groups)&&r.groups.length)folder=path.join(root,dirs[i]);}catch(e){}}}if(!folder)return;var answer=JSON.parse(fs.readFileSync(path.join(folder,'result.json'),'utf8'));if(!answer.sequence||answer.sequence.id!==s.id||!Array.isArray(answer.groups)||!answer.groups.length)return;result=answer;result.manually_edited=!!(info&&info.job===folder&&info.manually_edited);job=folder;dirty=false;renderReview();lock(busy);say('Restored your last captions for this sequence ('+result.groups.length+' captions).');}catch(ignore){}}
 function clock(t){var m=Math.floor(t/60),x=t-m*60;return m+':'+(x<10?'0':'')+x.toFixed(1);}
 // In and Out points that mark part of the sequence, or null.
 function rangeOf(s){var a=Number(s&&s.inPoint),b=Number(s&&s.outPoint),d=Number(s&&s.duration);return isFinite(a)&&isFinite(b)&&isFinite(d)&&a>=0&&b-a>=.5&&a<d&&(a>.05||b<d-.05)?[a,Math.min(b,d)]:null;}
 function showRange(s){var r=rangeOf(s);$('rangeRow').hidden=!r;if(!r)$('rangeOnly').checked=false;$('rangeText').textContent=r?clock(r[0])+' – '+clock(r[1]):'';}
 function refresh(){return host('info',[]).then(function(s){var changed=!sequence||sequence.id!==s.id;sequence=s;if(changed){result=null;kandyGen++;undoStack=[];redoStack=[];undoBase=null;dirty=false;var saved=JSON.parse(localStorage.getItem('kandySequence:'+s.id)||'null');$('script').value=saved?saved.text:'';$('inputMode').value='brief';$('cutPolicy').value=saved&&saved.cut_policy||'shot';$('maxLines').value=1;$('punctuation').value=String(!!(saved&&saved.punctuation));updateBrief(saved?saved.hook:'');restoreResult(s);}$('sequence').textContent=s.name+' · '+s.width+'×'+s.height+' · '+s.fps.toFixed(3)+' fps';showRange(s);schedulePreview();return s;});}
 $('refresh').onclick=protect(refresh);
 $('generate').onclick=protect(function(){var range=null;appFolder();inputSettings();result=null;kandyGen++;return refresh().then(function(s){newJob();var preset=KandyPlatform.wavPreset(fs,path,s.appPath,platform);if(!preset)throw Error('Premiere WAV preset not found. Use Reflow an existing SRT, or reinstall the Premiere export presets.');startProgress();progress(0,true);$('progressNote').textContent='Premiere is exporting audio. Cancellation becomes available when transcription starts.';range=$('rangeOnly').checked?rangeOf(s):null;say(range?'Exporting the In–Out range audio…':'Exporting the full sequence audio…');return host('exportAudio',[s.id,path.join(job,'sequence.wav'),preset,range?1:0]);}).then(function(r){return run(Object.assign(settings(),{audio:r.path},range?{range:range}:{}));});});
 $('audio').onclick=protect(function(){appFolder();inputSettings();return refresh().then(function(){return host('audio',[]);}).then(function(r){if(!r.path)return;result=null;kandyGen++;newJob();return run(Object.assign(settings(),{audio:r.path}));});});
 $('srt').onclick=protect(function(){appFolder();inputSettings();return refresh().then(function(){return host('srt',[]);}).then(function(r){if(!r.path)return;result=null;kandyGen++;newJob();return run(Object.assign(settings(),{srt:r.path}));});});
 function kandyRebuild(styleOnly){if(regenTiming)styleOnly=false;regenTiming=false;var previous=result;return host('info',[]).then(function(current){if(current.id!==previous.sequence.id)throw Error('Return to the original sequence before rebuilding.');sequence=current;newJob();var inputs=styleOnly===true?{edit_groups:previous.groups,manually_edited:!!previous.manually_edited}:previous.manually_edited?{edit_groups:previous.groups,reflow_policy:previous.cut_policy!==$('cutPolicy').value||previous.caption_max_lines!==Number($('maxLines').value)||previous.caption_punctuation!==($('punctuation').value==='true'),manually_edited:true}:previous.cues?{cues:previous.cues}:{edit_groups:previous.groups};if(previous.speech_words&&previous.speech_words.length)inputs.speech_words=previous.speech_words;if(previous.range)inputs.range=previous.range;return run(Object.assign(settings(),inputs));});}function kandyReady(){return dirty?kandyRebuild(true):Promise.resolve();}$('save').onclick=protect(function(){return kandyRebuild(true);});
 function verifyReview(){if(dirty)throw Error('Apply edits and rebuild before adding.');if(needsScriptReview())throw Error('Review script/audio differences and choose whether to use these captions first.');}
 $('native').onclick=protect(function(){return kandyReady().then(function(){return host('addNative',[result.sequence.id,result.srt]);}).then(function(r){say(r.message);});});
 $('replace').onclick=protect(function(){return kandyReady().then(function(){return host('replaceStyled',[result.sequence.id,result.xml,result.overlay_name,result.range||null]);}).then(function(r){say(r.message);});});$('replaceSel').onclick=protect(function(){return kandyReady().then(function(){return host('replaceSelected',[result.sequence.id,result.xml,result.overlay_name]);}).then(function(r){say(r.message);});});$('styled').onclick=protect(function(){return kandyReady().then(function(){return host('addStyled',[result.sequence.id,result.xml,result.overlay_name]);}).then(function(r){say(r.message);});});
 $('useDetected').onclick=function(){if(busy||updateBusy||!result)return;if(dirty){say('Apply your text edits and rebuild before confirming the review.');return;}result.script_review_acknowledged=true;try{fs.writeFileSync(path.join(result.folder,'script-review-decision.json'),JSON.stringify({decision:result.manually_edited?'use_reviewed_captions':'use_detected_words',time:new Date().toISOString(),script_review:result.script_review},null,2));}catch(e){result.script_review_acknowledged=false;say('Could not save the review decision: '+e.message);return;}$('scriptReviewDecision').textContent='Confirmed. '+(result.manually_edited?'Reviewed captions':'Detected words')+' will be used. Your pasted script is unchanged.';say('Review confirmed. Ready to add captions.');lock(false);};
 $('progressCancel').onclick=function(){if(worker)$('cancel').onclick();};
 $('cancel').onclick=function(){if(job&&worker){fs.writeFileSync(path.join(job,'cancel'),'cancel');say('Cancelling processing…');}};
 $('folder').onclick=function(){if(result)KandyPlatform.openFolder(cp,result.folder,platform);};
 ['style','size','position','maxLines','punctuation'].forEach(function(id){$(id).onchange=function(){if(result){dirty=true;$('native').disabled=true;$('styled').disabled=true;$('replace').disabled=true;say('Style changed. Apply text edits & rebuild to preview the new style.');}};});
 function scriptChanged(){saveSequenceInput();if(result){dirty=true;result.script_review_acknowledged=false;lock(busy);say('Script selection changed. Apply edits & rebuild to check it against these captions.');}}
 $('script').oninput=function(){updateBrief();scriptChanged();};$('inputMode').onchange=function(){updateBrief();scriptChanged();};$('hook').onchange=scriptChanged;
 $('cutPolicy').onchange=function(){saveSequenceInput();if(result){dirty=true;lock(busy);say('Scene mode changed. Apply edits & rebuild to reflow captions.');}};
 $('checkUpdates').onclick=function(){updates();};paintStyles();
 window.addEventListener('beforeunload',function(){if(updateJob&&updateWorker)try{fs.writeFileSync(path.join(updateJob,'cancel'),'cancel');}catch(ignore){}if(updateTimer)window.clearInterval(updateTimer);});
 if(!cep||!req){say('Open inside Premiere Pro 2023–2026 to connect.');return;}
 var extension=systemPath('extension').replace(/\\/g,'/');
 cep.evalScript('$.evalFile(new File('+JSON.stringify(extension+'/host.jsx')+')); "ready";',function(reply){if(reply==='EvalScript error.'){$('sequence').textContent='Premiere could not load the caption connection. Restart Premiere and reopen Kandy For Scale Captions.';return;}refresh().catch(function(e){$('sequence').textContent=e.message;});});
 updates();
 // Live preview: the engine draws one caption exactly as it will be added, over the frame at the playhead.
 var previewTimer=null,previewChild=null,previewAgain=false,previewLast='';
 // Safe zones: the Kandy 9x16-to-4x5 overlay, on or off at one click, remembered between sessions. It only fits 9:16 frames.
 var safeOn=false,safeFits=true;try{safeOn=localStorage.getItem('kandySafeZones')==='1';}catch(e){}
 function paintSafe(){var b=$('safeToggle');$('safeZones').hidden=!(safeOn&&safeFits);b.disabled=!safeFits;b.setAttribute('aria-pressed',safeOn&&safeFits?'true':'false');
  b.textContent=!safeFits?'Safe zones are for 9:16 sequences':safeOn?'Hide safe zones':'Show safe zones';}
 $('safeToggle').onclick=function(){safeOn=!safeOn;try{localStorage.setItem('kandySafeZones',safeOn?'1':'0');}catch(e){}paintSafe();};paintSafe();
 // Undo / redo (Cmd/Ctrl+Z, Cmd/Ctrl+Shift+Z, Ctrl+Y) for every panel setting, the script text and caption edits.
 // Each user edit becomes one step (typing and slider drags are grouped). Undo restores the values and fires the same
 // input/change events a manual edit fires, so saving, preview and rebuild behave exactly as if the editor changed it back.
 var kandyGen=0,undoStack=[],redoStack=[],undoBase=null,undoTimer=null,undoTarget=null,undoQuiet=false;
 var undoIds=['script','inputMode','hook','style','rangeOnly','fx_weight','textColor','backgroundColor','outlineColor','highlightColor','fx_stroke','fx_shadow','fx_blur','fx_shadow_opacity','shadowColor','size','position','punctuation','cutPolicy','fillGap','numbers','maxLines'];
 var undoNames={script:'script text',inputMode:'input type',hook:'hook',style:'style',rangeOnly:'In-Out range',fx_weight:'font weight',textColor:'text colour',backgroundColor:'background colour',outlineColor:'stroke colour',highlightColor:'highlight colour',fx_stroke:'stroke',fx_shadow:'shadow',fx_blur:'blur',fx_shadow_opacity:'shadow opacity',shadowColor:'shadow colour',size:'size',position:'position',punctuation:'punctuation',cutPolicy:'caption breaks setting',fillGap:'gaps between captions',numbers:'numbers',maxLines:'lines per caption',groups:'caption text and breaks'};
 function undoSnap(){var v={gen:kandyGen,groups:result&&result.groups?JSON.stringify(result.groups):null};undoIds.forEach(function(id){var e=$(id);if(e)v[id]=e.type==='checkbox'?!!e.checked:String(e.value);});return v;}
 function undoDiff(a,b){return undoIds.filter(function(k){return a[k]!==b[k];}).concat(a.gen===b.gen&&a.groups&&b.groups&&a.groups!==b.groups?['groups']:[]);}
 function undoCommit(){if(undoTimer){window.clearTimeout(undoTimer);undoTimer=null;}undoTarget=null;if(!undoBase)return;var now=undoSnap();if(undoDiff(undoBase,now).length){undoStack.push(undoBase);if(undoStack.length>200)undoStack.shift();redoStack=[];}undoBase=now;}
 function undoTouch(ev){if(undoQuiet||(ev.type==='keydown'&&(ev.ctrlKey||ev.metaKey)))return;if(undoTimer&&ev.target===undoTarget)return;if(undoTimer)undoCommit();else undoBase=undoSnap();}
 function undoLater(ev){if(undoQuiet)return;if(!undoBase)undoBase=undoSnap();undoTarget=ev.target;if(undoTimer)window.clearTimeout(undoTimer);undoTimer=window.setTimeout(undoCommit,400);}
 function undoApply(to){undoQuiet=true;try{
   if(to.style&&to.style!==$('style').value)chooseStyle(to.style);
   undoIds.forEach(function(id){var e=$(id);if(!e||id==='style'||!(id in to))return;var cur=e.type==='checkbox'?!!e.checked:String(e.value);if(cur===to[id])return;
    if(e.type==='checkbox')e.checked=to[id];else e.value=to[id];
    ['input','change'].forEach(function(t){try{e.dispatchEvent(new Event(t,{bubbles:true}));}catch(x){}});});
   if(result&&to.gen===kandyGen&&to.groups&&JSON.stringify(result.groups)!==to.groups){result.groups=JSON.parse(to.groups);result.manually_edited=true;dirty=true;lock(false);renderReview();}
  }finally{undoQuiet=false;}schedulePreview();}
 function undoKey(ev){var k=String(ev.key||'').toLowerCase();if(!(ev.ctrlKey||ev.metaKey)||ev.altKey||(k!=='z'&&k!=='y'))return;
  ev.preventDefault();ev.stopPropagation();var redo=k==='y'||ev.shiftKey;
  if(busy){say('Wait until the current job finishes, then undo.');return;}
  undoCommit();var from=redo?redoStack:undoStack,to=redo?undoStack:redoStack;
  if(!from.length){say(redo?'Nothing to redo in this panel.':'Nothing to undo in this panel. To undo on the timeline, click the timeline first, then press '+(typeof navigator!=='undefined'&&/Mac/i.test(navigator.platform||'')?'Cmd':'Ctrl')+'+Z.');return;}
  var cur=undoSnap(),target=from.pop(),changed=undoDiff(cur,target);to.push(cur);undoApply(target);undoBase=undoSnap();
  say((redo?'Redone: ':'Undone: ')+(changed.map(function(x){return undoNames[x]||x;}).join(', ')||'no visible change')+'.');}
 document.addEventListener('keydown',undoKey,true);
 ['focusin','mousedown','keydown'].forEach(function(t){document.addEventListener(t,undoTouch,true);});
 ['input','change','click','keyup'].forEach(function(t){document.addEventListener(t,undoLater,true);});
 function previewText(){var at=sequence&&sequence.playhead;if(result&&result.groups&&result.groups.length){var hit=result.groups.filter(function(r){return at!=null&&r.start<=at&&at<r.end;})[0];return (hit||result.groups[0]).text;}
  var words=String(inputSettings().script||'').replace(/\s+/g,' ').trim().split(' '),out='';for(var i=0;i<words.length&&(out+' '+words[i]).trim().length<=22;i++)out=(out+' '+words[i]).trim();return out||'Your caption looks like this';}
 function schedulePreview(){if(previewTimer)window.clearTimeout(previewTimer);previewTimer=window.setTimeout(livePreview,500);}
 function livePreview(){previewTimer=null;if(!sequence)return;if(!engineRoot||worker){previewTimer=window.setTimeout(livePreview,2000);return;}
  var ask=Object.assign(settings(),{preview_text:previewText(),at:sequence.playhead});var key=JSON.stringify(ask);if(key===previewLast)return;if(previewChild){previewAgain=true;return;}
  var folder=path.join(cache,'preview'),out='';try{fs.mkdirSync(folder,{recursive:true});try{fs.unlinkSync(path.join(folder,'preview.json'));}catch(e){}fs.writeFileSync(path.join(folder,'request.json'),key);}catch(e){return;}
  previewLast=key;$('livePreviewNote').textContent='Updating preview…';
  try{previewChild=cp.spawn(python(),[path.join(engineRoot,'worker.py'),'--preview',path.join(cache,'bundle'),path.join(folder,'request.json')],{windowsHide:true,cwd:engineRoot,env:workerEnvironment(),stdio:['ignore','pipe','ignore']});}catch(e){previewLast='';$('livePreviewNote').textContent='Preview unavailable: '+e.message;return;}
  var child=previewChild;child.stdout.on('data',function(d){out=(out+d.toString()).slice(-2000);});
  function done(code){if(previewChild!==child)return;previewChild=null;var info=null;try{info=JSON.parse(fs.readFileSync(path.join(folder,'preview.json'),'utf8'));}catch(e){}
   if(code===0&&info){safeFits=Math.abs(info.width/info.height-9/16)<0.01;paintSafe();$('livePreview').src=KandyPlatform.fileURL(path,req('url'),info.path)+'?v='+Date.now();$('livePreviewBox').hidden=false;
    $('livePreviewNote').textContent=(info.frame?'Frame at '+clock(info.at):'No video frame found, shown on grey')+' · '+info.width+'×'+info.height+' · exact size and position. Move the playhead and click Refresh for another frame.';}
   else{previewLast='';var m='';try{m=JSON.parse(out.trim().split('\n').pop()).message;}catch(e){}$('livePreviewNote').textContent='Preview unavailable. '+(m||'');$('livePreviewBox').hidden=false;}
   if(previewAgain){previewAgain=false;livePreview();}}
  child.on('close',done);child.on('error',function(){done(1);});}
 (function(){var look=$('styles').parentNode;['input','change','click'].forEach(function(ev){look.addEventListener(ev,schedulePreview);});$('script').addEventListener('input',schedulePreview);}());
 // Gaps between captions: an editor preference kept across sequences.
 var regenTiming=false;try{var savedGap=localStorage.getItem('kandyFillGap');if(savedGap!==null)$('fillGap').value=savedGap;}catch(e){}
 $('fillGap').onchange=function(){try{localStorage.setItem('kandyFillGap',$('fillGap').value);}catch(e){}if(result){dirty=true;regenTiming=true;lock(false);say('Gap setting changed. Captions rebuild automatically when you add or replace them.');}};
 // Numbers: digits or as written, an editor preference kept across sequences. A change re-applies to the heard words.
 try{var savedNumbers=localStorage.getItem('kandyNumbers');if(savedNumbers==='digits'||savedNumbers==='words')$('numbers').value=savedNumbers;}catch(e){}
 $('numbers').onchange=function(){try{localStorage.setItem('kandyNumbers',$('numbers').value);}catch(e){}if(result){dirty=true;regenTiming=true;lock(false);say('Number setting changed. Captions rebuild automatically when you add or replace them.');}};
 // Caption list: drag its bottom-right corner to make it taller, like the script box. The height is remembered.
 (function(){var box=$('review'),saved=0;try{saved=Number(localStorage.getItem('kandyReviewHeight'))||0;}catch(e){}
  function free(h){box.style.maxHeight='none';box.style.height=Math.max(60,Math.round(h))+'px';}
  if(saved>=60)free(saved);
  box.addEventListener('mousedown',function(ev){var r=box.getBoundingClientRect();if(box.style.maxHeight!=='none'&&ev.clientX>=r.right-20&&ev.clientY>=r.bottom-20)free(r.height);});
  document.addEventListener('mouseup',function(){if(box.style.maxHeight!=='none')return;var h=Math.round(box.getBoundingClientRect().height);if(h>=60){try{localStorage.setItem('kandyReviewHeight',String(h));}catch(e){}}});
 }());
 // Premiere often stays open all day: check again every 30 minutes while idle with no unsaved edits.
 window.setInterval(function(){if(!busy&&!updateBusy&&!dirty)updates(true);},30*60*1000);
}());
